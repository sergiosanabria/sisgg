-- MySQL dump 10.13  Distrib 5.5.32, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: SisGG
-- ------------------------------------------------------
-- Server version	5.5.32-0ubuntu0.13.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AdicionalEmpleado`
--

DROP TABLE IF EXISTS `AdicionalEmpleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AdicionalEmpleado` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_2A72E716BF396750` FOREIGN KEY (`id`) REFERENCES `mov_empleado` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AdicionalEmpleado`
--

LOCK TABLES `AdicionalEmpleado` WRITE;
/*!40000 ALTER TABLE `AdicionalEmpleado` DISABLE KEYS */;
/*!40000 ALTER TABLE `AdicionalEmpleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Agenda`
--

DROP TABLE IF EXISTS `Agenda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Agenda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `etiqueta` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `asunto` longtext COLLATE utf8_unicode_ci NOT NULL,
  `lugar` longtext COLLATE utf8_unicode_ci,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `todos` tinyint(1) DEFAULT NULL,
  `inicioFec` date DEFAULT NULL,
  `finFec` date DEFAULT NULL,
  `inicioHora` time DEFAULT NULL,
  `finHora` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_2B41CD416D5CA63A` (`etiqueta`),
  KEY `IDX_2B41CD41DB38439E` (`usuario_id`),
  CONSTRAINT `FK_2B41CD41DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`),
  CONSTRAINT `FK_2B41CD416D5CA63A` FOREIGN KEY (`etiqueta`) REFERENCES `EtiquetaAgenda` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Agenda`
--

LOCK TABLES `Agenda` WRITE;
/*!40000 ALTER TABLE `Agenda` DISABLE KEYS */;
/*!40000 ALTER TABLE `Agenda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Apertura`
--

DROP TABLE IF EXISTS `Apertura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Apertura` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `caja_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_268D37BDDB38439E` (`usuario_id`),
  KEY `IDX_268D37BD2D82B651` (`caja_id`),
  CONSTRAINT `FK_268D37BDBF396750` FOREIGN KEY (`id`) REFERENCES `Movimiento` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_268D37BD2D82B651` FOREIGN KEY (`caja_id`) REFERENCES `Caja` (`id`),
  CONSTRAINT `FK_268D37BDDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Apertura`
--

LOCK TABLES `Apertura` WRITE;
/*!40000 ALTER TABLE `Apertura` DISABLE KEYS */;
/*!40000 ALTER TABLE `Apertura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Backup`
--

DROP TABLE IF EXISTS `Backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `carpeta` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `archivo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_385CD49ADB38439E` (`usuario_id`),
  CONSTRAINT `FK_385CD49ADB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Backup`
--

LOCK TABLES `Backup` WRITE;
/*!40000 ALTER TABLE `Backup` DISABLE KEYS */;
INSERT INTO `Backup` VALUES (1,1,'/var/backups/','backup_mysql_sisgg_2013_12_02_09_36_25.sql','2013-12-02 09:36:26'),(2,1,'/var/backups/','backup_mysql_sisgg_2013_12_02_09_52_25.sql','2013-12-02 09:52:25');
/*!40000 ALTER TABLE `Backup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Caja`
--

DROP TABLE IF EXISTS `Caja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Caja` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa_id` int(11) DEFAULT NULL,
  `puntoVentaA` int(11) DEFAULT NULL,
  `ultimaFacturaA` int(11) DEFAULT NULL,
  `puntoVentaB` int(11) DEFAULT NULL,
  `ultimaFacturaB` int(11) DEFAULT NULL,
  `puntoVentaC` int(11) DEFAULT NULL,
  `ultimaFacturaC` int(11) DEFAULT NULL,
  `serieNotaCreditoA` int(11) DEFAULT NULL,
  `ultimoNumeroNotaCreditoA` int(11) DEFAULT NULL,
  `serieNotaCreditoB` int(11) DEFAULT NULL,
  `ultimoNumeroNotaCreditoB` int(11) DEFAULT NULL,
  `serieNotaCreditoC` int(11) DEFAULT NULL,
  `ultimoNumeroNotaCreditoC` int(11) DEFAULT NULL,
  `serieRecibo` int(11) DEFAULT NULL,
  `ultimoNumeroRecibo` int(11) DEFAULT NULL,
  `minimoApertura` decimal(10,2) DEFAULT NULL,
  `abierta` tinyint(1) DEFAULT NULL,
  `saldo` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_44575B3B521E1991` (`empresa_id`),
  CONSTRAINT `FK_44575B3B521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Caja`
--

LOCK TABLES `Caja` WRITE;
/*!40000 ALTER TABLE `Caja` DISABLE KEYS */;
INSERT INTO `Caja` VALUES (1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL);
/*!40000 ALTER TABLE `Caja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Campo`
--

DROP TABLE IF EXISTS `Campo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Campo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `requerido` tinyint(1) DEFAULT NULL,
  `unico` tinyint(1) DEFAULT NULL,
  `tipoDato` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `patron` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ejemplo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipoCobro_id` int(11) DEFAULT NULL,
  `discr` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_E8D618AEE414003F` (`tipoCobro_id`),
  CONSTRAINT `FK_E8D618AEE414003F` FOREIGN KEY (`tipoCobro_id`) REFERENCES `TipoCobro` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Campo`
--

LOCK TABLES `Campo` WRITE;
/*!40000 ALTER TABLE `Campo` DISABLE KEYS */;
INSERT INTO `Campo` VALUES (1,'Numero de Comprobante',1,NULL,'text','[0-9]{4}','0001',3,'campo');
/*!40000 ALTER TABLE `Campo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CancelarEmpleado`
--

DROP TABLE IF EXISTS `CancelarEmpleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CancelarEmpleado` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_AB7562F8BF396750` FOREIGN KEY (`id`) REFERENCES `mov_empleado` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CancelarEmpleado`
--

LOCK TABLES `CancelarEmpleado` WRITE;
/*!40000 ALTER TABLE `CancelarEmpleado` DISABLE KEYS */;
/*!40000 ALTER TABLE `CancelarEmpleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cargo`
--

DROP TABLE IF EXISTS `Cargo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cargo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `tipo` int(11) NOT NULL,
  `porDia` int(11) DEFAULT NULL,
  `porFecha` int(11) DEFAULT NULL,
  `porDiaSemana` int(11) DEFAULT NULL,
  `monto` decimal(10,2) DEFAULT NULL,
  `negativo` decimal(10,2) DEFAULT NULL,
  `discr` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cargo`
--

LOCK TABLES `Cargo` WRITE;
/*!40000 ALTER TABLE `Cargo` DISABLE KEYS */;
/*!40000 ALTER TABLE `Cargo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CargoEmpleado`
--

DROP TABLE IF EXISTS `CargoEmpleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CargoEmpleado` (
  `id` int(11) NOT NULL,
  `empleado` int(11) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  `cargoSistema` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_EFE623A3B5257733` (`cargoSistema`),
  KEY `IDX_EFE623A3D9D9BF52` (`empleado`),
  CONSTRAINT `FK_EFE623A3BF396750` FOREIGN KEY (`id`) REFERENCES `Cargo` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_EFE623A3B5257733` FOREIGN KEY (`cargoSistema`) REFERENCES `CargoSistema` (`id`),
  CONSTRAINT `FK_EFE623A3D9D9BF52` FOREIGN KEY (`empleado`) REFERENCES `persona_empleado` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CargoEmpleado`
--

LOCK TABLES `CargoEmpleado` WRITE;
/*!40000 ALTER TABLE `CargoEmpleado` DISABLE KEYS */;
/*!40000 ALTER TABLE `CargoEmpleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CargoSistema`
--

DROP TABLE IF EXISTS `CargoSistema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CargoSistema` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_AD14ACCB521E1991` (`empresa_id`),
  CONSTRAINT `FK_AD14ACCBBF396750` FOREIGN KEY (`id`) REFERENCES `Cargo` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_AD14ACCB521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CargoSistema`
--

LOCK TABLES `CargoSistema` WRITE;
/*!40000 ALTER TABLE `CargoSistema` DISABLE KEYS */;
/*!40000 ALTER TABLE `CargoSistema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CategoriaProductoProduccion`
--

DROP TABLE IF EXISTS `CategoriaProductoProduccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CategoriaProductoProduccion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `padre_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_A7F3044C3A909126` (`nombre`),
  KEY `IDX_A7F3044C613CEC58` (`padre_id`),
  KEY `IDX_A7F3044C521E1991` (`empresa_id`),
  CONSTRAINT `FK_A7F3044C521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_A7F3044C613CEC58` FOREIGN KEY (`padre_id`) REFERENCES `CategoriaProductoProduccion` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CategoriaProductoProduccion`
--

LOCK TABLES `CategoriaProductoProduccion` WRITE;
/*!40000 ALTER TABLE `CategoriaProductoProduccion` DISABLE KEYS */;
INSERT INTO `CategoriaProductoProduccion` VALUES (1,NULL,1,'Congelados','Todos los productos que requieren de equipo de frio',1),(2,NULL,1,'Verduras','Todas las verduras',1),(3,NULL,1,'Condimentos','Condimentos secos',1),(4,NULL,1,'Quesos y fiambres',NULL,1),(5,1,1,'Carnes',NULL,1),(6,NULL,1,'Panificados',NULL,1),(7,NULL,1,'Carnes elaboradas','Carnes que sufren algun proceso de elaboracion',1),(8,NULL,1,'Adheresos Elaborados','Son todos los distintos insumos adheresos a los platos elaborados en la cocina',1),(9,NULL,1,'Enlatados',NULL,1),(10,NULL,1,'Harinas y pastas',NULL,1),(11,1,1,'Otros',NULL,1);
/*!40000 ALTER TABLE `CategoriaProductoProduccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CategoriaProductoVenta`
--

DROP TABLE IF EXISTS `CategoriaProductoVenta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CategoriaProductoVenta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `padre_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_EA15CFA63A909126` (`nombre`),
  KEY `IDX_EA15CFA6613CEC58` (`padre_id`),
  KEY `IDX_EA15CFA6521E1991` (`empresa_id`),
  CONSTRAINT `FK_EA15CFA6521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_EA15CFA6613CEC58` FOREIGN KEY (`padre_id`) REFERENCES `CategoriaProductoVenta` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CategoriaProductoVenta`
--

LOCK TABLES `CategoriaProductoVenta` WRITE;
/*!40000 ALTER TABLE `CategoriaProductoVenta` DISABLE KEYS */;
INSERT INTO `CategoriaProductoVenta` VALUES (1,NULL,1,'Bebidas','Todas las bebidas con o si alcohol',1),(2,1,1,'Gaseosa','Las distintas bebidas con gas',1),(3,1,1,'Cervezas','Las distintas cervezas',1),(4,1,1,'Vinos','Los distintos vinos y su varietales',1),(5,NULL,1,'Comidas rapidas','Las comidas que llevan menos tiempo de elaboración',1),(6,NULL,1,'Platos elaborados','Todas las comidas al plato elaboradas',1),(7,NULL,1,'Guarniciones','Todos los platos complementario',1),(8,NULL,1,'Pizzas',NULL,1);
/*!40000 ALTER TABLE `CategoriaProductoVenta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ChatMensaje`
--

DROP TABLE IF EXISTS `ChatMensaje`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ChatMensaje` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `destino` int(11) DEFAULT NULL,
  `usuario` int(11) DEFAULT NULL,
  `mensaje` longtext COLLATE utf8_unicode_ci,
  `eliminar` int(11) DEFAULT NULL,
  `leido` tinyint(1) DEFAULT NULL,
  `envio` tinyint(1) DEFAULT NULL,
  `fechaEnvio` datetime DEFAULT NULL,
  `fechaRecibo` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_4CAD7BE881F64EFA` (`destino`),
  KEY `IDX_4CAD7BE82265B05D` (`usuario`),
  CONSTRAINT `FK_4CAD7BE82265B05D` FOREIGN KEY (`usuario`) REFERENCES `Usuario` (`id`),
  CONSTRAINT `FK_4CAD7BE881F64EFA` FOREIGN KEY (`destino`) REFERENCES `Usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ChatMensaje`
--

LOCK TABLES `ChatMensaje` WRITE;
/*!40000 ALTER TABLE `ChatMensaje` DISABLE KEYS */;
/*!40000 ALTER TABLE `ChatMensaje` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cierre`
--

DROP TABLE IF EXISTS `Cierre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cierre` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `caja_id` int(11) DEFAULT NULL,
  `conformidad` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `extraerTotal` tinyint(1) DEFAULT NULL,
  `numeroCierre` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D770F9F1DB38439E` (`usuario_id`),
  KEY `IDX_D770F9F12D82B651` (`caja_id`),
  CONSTRAINT `FK_D770F9F1BF396750` FOREIGN KEY (`id`) REFERENCES `Movimiento` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_D770F9F12D82B651` FOREIGN KEY (`caja_id`) REFERENCES `Caja` (`id`),
  CONSTRAINT `FK_D770F9F1DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cierre`
--

LOCK TABLES `Cierre` WRITE;
/*!40000 ALTER TABLE `Cierre` DISABLE KEYS */;
/*!40000 ALTER TABLE `Cierre` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Ciudad`
--

DROP TABLE IF EXISTS `Ciudad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Ciudad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provincia_id` int(11) DEFAULT NULL,
  `nombre` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `codigoPostal` int(11) NOT NULL,
  `porDefecto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_892A00A84E7121AF` (`provincia_id`),
  CONSTRAINT `FK_892A00A84E7121AF` FOREIGN KEY (`provincia_id`) REFERENCES `Provincia` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Ciudad`
--

LOCK TABLES `Ciudad` WRITE;
/*!40000 ALTER TABLE `Ciudad` DISABLE KEYS */;
INSERT INTO `Ciudad` VALUES (1,1,'Posadas',3300,1),(2,1,'Obera',3360,NULL),(3,1,'Eldorado',3380,NULL),(4,2,'Santo Tome',3212,NULL),(5,1,'Jardin America',3328,NULL);
/*!40000 ALTER TABLE `Ciudad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cliente`
--

DROP TABLE IF EXISTS `Cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cliente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `telefono_id` int(11) DEFAULT NULL,
  `direccion_id` int(11) DEFAULT NULL,
  `email` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `documento` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `apellido` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `cuit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `porDefecto` tinyint(1) DEFAULT NULL,
  `tipoDocumento_id` int(11) DEFAULT NULL,
  `condicionIva_id` int(11) DEFAULT NULL,
  `discr` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_3BA1A2B9FD6D75CD` (`telefono_id`),
  UNIQUE KEY `UNIQ_3BA1A2B9D0A7BD7` (`direccion_id`),
  KEY `IDX_3BA1A2B93668888B` (`tipoDocumento_id`),
  KEY `IDX_3BA1A2B9F60CF12A` (`condicionIva_id`),
  CONSTRAINT `FK_3BA1A2B9F60CF12A` FOREIGN KEY (`condicionIva_id`) REFERENCES `CondicionIva` (`id`),
  CONSTRAINT `FK_3BA1A2B93668888B` FOREIGN KEY (`tipoDocumento_id`) REFERENCES `TipoDocumento` (`id`),
  CONSTRAINT `FK_3BA1A2B9D0A7BD7` FOREIGN KEY (`direccion_id`) REFERENCES `Direccion` (`id`),
  CONSTRAINT `FK_3BA1A2B9FD6D75CD` FOREIGN KEY (`telefono_id`) REFERENCES `Telefono` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cliente`
--

LOCK TABLES `Cliente` WRITE;
/*!40000 ALTER TABLE `Cliente` DISABLE KEYS */;
/*!40000 ALTER TABLE `Cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cobro`
--

DROP TABLE IF EXISTS `Cobro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cobro` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `venta_id` int(11) DEFAULT NULL,
  `importe` decimal(10,2) DEFAULT NULL,
  `aclaracion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipoCobro_id` int(11) DEFAULT NULL,
  `unRecibo_id` int(11) DEFAULT NULL,
  `dtype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_31634A2263616B01` (`unRecibo_id`),
  KEY `IDX_31634A22F2A5805D` (`venta_id`),
  KEY `IDX_31634A22E414003F` (`tipoCobro_id`),
  CONSTRAINT `FK_31634A2263616B01` FOREIGN KEY (`unRecibo_id`) REFERENCES `Cobro` (`id`),
  CONSTRAINT `FK_31634A22E414003F` FOREIGN KEY (`tipoCobro_id`) REFERENCES `TipoCobro` (`id`),
  CONSTRAINT `FK_31634A22F2A5805D` FOREIGN KEY (`venta_id`) REFERENCES `Venta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cobro`
--

LOCK TABLES `Cobro` WRITE;
/*!40000 ALTER TABLE `Cobro` DISABLE KEYS */;
/*!40000 ALTER TABLE `Cobro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cocina`
--

DROP TABLE IF EXISTS `Cocina`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cocina` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `numeroTandas` int(11) NOT NULL,
  `tamanoMaximoEspera` int(11) DEFAULT NULL,
  `tamanoMaximoTandas` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cocina`
--

LOCK TABLES `Cocina` WRITE;
/*!40000 ALTER TABLE `Cocina` DISABLE KEYS */;
INSERT INTO `Cocina` VALUES (1,'Cocina Principal',1,NULL,NULL);
/*!40000 ALTER TABLE `Cocina` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Concepto`
--

DROP TABLE IF EXISTS `Concepto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Concepto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipo` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9DF5EA86521E1991` (`empresa_id`),
  CONSTRAINT `FK_9DF5EA86521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Concepto`
--

LOCK TABLES `Concepto` WRITE;
/*!40000 ALTER TABLE `Concepto` DISABLE KEYS */;
INSERT INTO `Concepto` VALUES (1,1,'Pago por compra','Pago de una compra a un proveedor.','activo',0),(2,1,'Cobro por venta','Cobro de una venta a un cliente.','activo',1),(3,1,'Pago a un empleado','Pago a un empleado por servicio.','activo',0),(4,NULL,'Cobro por Venta','Cobro por Venta','activo',1);
/*!40000 ALTER TABLE `Concepto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CondicionIva`
--

DROP TABLE IF EXISTS `CondicionIva`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CondicionIva` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `abreviatura` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CondicionIva`
--

LOCK TABLES `CondicionIva` WRITE;
/*!40000 ALTER TABLE `CondicionIva` DISABLE KEYS */;
INSERT INTO `CondicionIva` VALUES (1,'IVA RESPONSABLE INSCRIPTO','RI','activo'),(2,'RESPONSABLE MONOTRIBUTO','RM','activo'),(3,'CONSUMIDOR FINAL','NR','activo'),(4,'EXENTO',NULL,'activo');
/*!40000 ALTER TABLE `CondicionIva` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ContadoEmpleado`
--

DROP TABLE IF EXISTS `ContadoEmpleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ContadoEmpleado` (
  `id` int(11) NOT NULL,
  `pago_id` int(11) DEFAULT NULL,
  `liquido` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8A44E4B363FB8380` (`pago_id`),
  CONSTRAINT `FK_8A44E4B3BF396750` FOREIGN KEY (`id`) REFERENCES `mov_empleado` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_8A44E4B363FB8380` FOREIGN KEY (`pago_id`) REFERENCES `pago` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ContadoEmpleado`
--

LOCK TABLES `ContadoEmpleado` WRITE;
/*!40000 ALTER TABLE `ContadoEmpleado` DISABLE KEYS */;
/*!40000 ALTER TABLE `ContadoEmpleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CuentaCorriente`
--

DROP TABLE IF EXISTS `CuentaCorriente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CuentaCorriente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) DEFAULT NULL,
  `numeroCuenta` int(11) NOT NULL,
  `saldo` decimal(10,2) DEFAULT NULL,
  `maximo` decimal(10,2) DEFAULT NULL,
  `plazoGeneracionRecibos` int(11) DEFAULT NULL,
  `diasEntreAvisos` int(11) DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fechaCreacion` datetime NOT NULL,
  `fechaEliminacion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_BF296AB0DE734E51` (`cliente_id`),
  CONSTRAINT `FK_BF296AB0DE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Cliente` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CuentaCorriente`
--

LOCK TABLES `CuentaCorriente` WRITE;
/*!40000 ALTER TABLE `CuentaCorriente` DISABLE KEYS */;
/*!40000 ALTER TABLE `CuentaCorriente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Descuento`
--

DROP TABLE IF EXISTS `Descuento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Descuento` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `porcentaje` decimal(10,2) DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `discr` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Descuento`
--

LOCK TABLES `Descuento` WRITE;
/*!40000 ALTER TABLE `Descuento` DISABLE KEYS */;
/*!40000 ALTER TABLE `Descuento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DescuentoCliente`
--

DROP TABLE IF EXISTS `DescuentoCliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DescuentoCliente` (
  `id` int(11) NOT NULL,
  `venta_id` int(11) DEFAULT NULL,
  `importe` decimal(10,2) DEFAULT NULL,
  `tipoPorcentaje` tinyint(1) DEFAULT NULL,
  `tipoImporte` tinyint(1) DEFAULT NULL,
  `minimo` decimal(10,2) DEFAULT NULL,
  `maximo` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_12778F1AF2A5805D` (`venta_id`),
  CONSTRAINT `FK_12778F1ABF396750` FOREIGN KEY (`id`) REFERENCES `Descuento` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_12778F1AF2A5805D` FOREIGN KEY (`venta_id`) REFERENCES `Venta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DescuentoCliente`
--

LOCK TABLES `DescuentoCliente` WRITE;
/*!40000 ALTER TABLE `DescuentoCliente` DISABLE KEYS */;
/*!40000 ALTER TABLE `DescuentoCliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DescuentoProductoVenta`
--

DROP TABLE IF EXISTS `DescuentoProductoVenta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DescuentoProductoVenta` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_CA04E58ABF396750` FOREIGN KEY (`id`) REFERENCES `Descuento` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DescuentoProductoVenta`
--

LOCK TABLES `DescuentoProductoVenta` WRITE;
/*!40000 ALTER TABLE `DescuentoProductoVenta` DISABLE KEYS */;
/*!40000 ALTER TABLE `DescuentoProductoVenta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DetalleSolicitud`
--

DROP TABLE IF EXISTS `DetalleSolicitud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DetalleSolicitud` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `solicitud_id` int(11) DEFAULT NULL,
  `texto` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_F599354A1CB9D6E4` (`solicitud_id`),
  CONSTRAINT `FK_F599354A1CB9D6E4` FOREIGN KEY (`solicitud_id`) REFERENCES `Solicitud` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DetalleSolicitud`
--

LOCK TABLES `DetalleSolicitud` WRITE;
/*!40000 ALTER TABLE `DetalleSolicitud` DISABLE KEYS */;
/*!40000 ALTER TABLE `DetalleSolicitud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Direccion`
--

DROP TABLE IF EXISTS `Direccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Direccion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ciudad_id` int(11) NOT NULL,
  `calle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `numero` int(11) NOT NULL,
  `manzana` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edificio` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `escalera` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `piso` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `departamento` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_71753C36E8608214` (`ciudad_id`),
  CONSTRAINT `FK_71753C36E8608214` FOREIGN KEY (`ciudad_id`) REFERENCES `Ciudad` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Direccion`
--

LOCK TABLES `Direccion` WRITE;
/*!40000 ALTER TABLE `Direccion` DISABLE KEYS */;
INSERT INTO `Direccion` VALUES (1,1,'Av. Siempre Viva',123,NULL,NULL,NULL,NULL,NULL),(2,5,'Primeros Colonos',2013,NULL,NULL,NULL,NULL,NULL),(3,4,'Ciudadela',3520,NULL,NULL,NULL,NULL,NULL),(4,2,'Formosa',2381,NULL,NULL,NULL,NULL,NULL),(5,1,'Av. Lavalle',3526,NULL,NULL,NULL,NULL,NULL),(6,5,'Islas Malvinas',584,NULL,NULL,NULL,NULL,NULL),(7,4,'San Martin',1514,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `Direccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EgresoEmpleado`
--

DROP TABLE IF EXISTS `EgresoEmpleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EgresoEmpleado` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_55FA6BCFBF396750` FOREIGN KEY (`id`) REFERENCES `mov_empleado` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EgresoEmpleado`
--

LOCK TABLES `EgresoEmpleado` WRITE;
/*!40000 ALTER TABLE `EgresoEmpleado` DISABLE KEYS */;
/*!40000 ALTER TABLE `EgresoEmpleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Empresa`
--

DROP TABLE IF EXISTS `Empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Empresa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `direccion_id` int(11) DEFAULT NULL,
  `imagen_id` int(11) DEFAULT NULL,
  `nombre` varchar(70) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slogan` longtext COLLATE utf8_unicode_ci,
  `responsable` tinyint(1) DEFAULT NULL,
  `edad` int(11) DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contrasenia` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci NOT NULL,
  `cuit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `inicioAct` date DEFAULT NULL,
  `carpeta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `carpetaAuditoria` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `condicionIva_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_776A63CCD0A7BD7` (`direccion_id`),
  UNIQUE KEY `UNIQ_776A63CC763C8AA7` (`imagen_id`),
  KEY `IDX_776A63CCF60CF12A` (`condicionIva_id`),
  CONSTRAINT `FK_776A63CCF60CF12A` FOREIGN KEY (`condicionIva_id`) REFERENCES `CondicionIva` (`id`),
  CONSTRAINT `FK_776A63CC763C8AA7` FOREIGN KEY (`imagen_id`) REFERENCES `Image` (`id`),
  CONSTRAINT `FK_776A63CCD0A7BD7` FOREIGN KEY (`direccion_id`) REFERENCES `Direccion` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Empresa`
--

LOCK TABLES `Empresa` WRITE;
/*!40000 ALTER TABLE `Empresa` DISABLE KEYS */;
INSERT INTO `Empresa` VALUES (1,1,NULL,'Example','Tu alegria a la hora de comer es la sonrisa de un niño',NULL,NULL,NULL,NULL,'Empresa dedicada a la venta de comidas','20-20202020-2',NULL,NULL,'/var/backups/',NULL,2);
/*!40000 ALTER TABLE `Empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Entrada`
--

DROP TABLE IF EXISTS `Entrada`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Entrada` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `caja_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_6F49BE8DB38439E` (`usuario_id`),
  KEY `IDX_6F49BE82D82B651` (`caja_id`),
  CONSTRAINT `FK_6F49BE8BF396750` FOREIGN KEY (`id`) REFERENCES `Movimiento` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_6F49BE82D82B651` FOREIGN KEY (`caja_id`) REFERENCES `Caja` (`id`),
  CONSTRAINT `FK_6F49BE8DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Entrada`
--

LOCK TABLES `Entrada` WRITE;
/*!40000 ALTER TABLE `Entrada` DISABLE KEYS */;
/*!40000 ALTER TABLE `Entrada` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EspeciesEmpleado`
--

DROP TABLE IF EXISTS `EspeciesEmpleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EspeciesEmpleado` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_99362E68BF396750` FOREIGN KEY (`id`) REFERENCES `mov_empleado` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EspeciesEmpleado`
--

LOCK TABLES `EspeciesEmpleado` WRITE;
/*!40000 ALTER TABLE `EspeciesEmpleado` DISABLE KEYS */;
/*!40000 ALTER TABLE `EspeciesEmpleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EtiquetaAgenda`
--

DROP TABLE IF EXISTS `EtiquetaAgenda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EtiquetaAgenda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `etiqueta` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `color` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EtiquetaAgenda`
--

LOCK TABLES `EtiquetaAgenda` WRITE;
/*!40000 ALTER TABLE `EtiquetaAgenda` DISABLE KEYS */;
/*!40000 ALTER TABLE `EtiquetaAgenda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GrupoCliente`
--

DROP TABLE IF EXISTS `GrupoCliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GrupoCliente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GrupoCliente`
--

LOCK TABLES `GrupoCliente` WRITE;
/*!40000 ALTER TABLE `GrupoCliente` DISABLE KEYS */;
/*!40000 ALTER TABLE `GrupoCliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GrupoMesa`
--

DROP TABLE IF EXISTS `GrupoMesa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GrupoMesa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GrupoMesa`
--

LOCK TABLES `GrupoMesa` WRITE;
/*!40000 ALTER TABLE `GrupoMesa` DISABLE KEYS */;
/*!40000 ALTER TABLE `GrupoMesa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Image`
--

DROP TABLE IF EXISTS `Image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Image`
--

LOCK TABLES `Image` WRITE;
/*!40000 ALTER TABLE `Image` DISABLE KEYS */;
INSERT INTO `Image` VALUES (2,'c5f7a86a1a6514e5a033e78ffcea66641d3f9b92','c5f7a86a1a6514e5a033e78ffcea66641d3f9b92.jpeg'),(4,'1e80d89b18801d9885b933b0f54bb88623f5ff57','1e80d89b18801d9885b933b0f54bb88623f5ff57.jpeg'),(8,'29b234aa8fc749174a141de34ac5ea2d1d7fe564','29b234aa8fc749174a141de34ac5ea2d1d7fe564.jpeg'),(10,'590d90f62880f47ba809d0bf1c8ea62f712176e0','590d90f62880f47ba809d0bf1c8ea62f712176e0.png'),(12,'96c94fe08103c4f1019ba91639efbf8790d0a18a','96c94fe08103c4f1019ba91639efbf8790d0a18a.jpeg'),(14,'e27c1624058443c0a53127b9b8b8448fedbb0f25','e27c1624058443c0a53127b9b8b8448fedbb0f25.jpeg'),(16,'dc9e81641ecf8d3bf202758b0e27549fd24ddfd5','dc9e81641ecf8d3bf202758b0e27549fd24ddfd5.jpeg'),(18,'ed9498398dadbca4d3abebd179d6e6f1e47bdb99','ed9498398dadbca4d3abebd179d6e6f1e47bdb99.jpeg'),(20,'0f0b9dd697cf9f35fd56f4541f01706a173673b7','0f0b9dd697cf9f35fd56f4541f01706a173673b7.jpeg'),(22,'10e9951b1d09e9ae195d82e7ad902e98f02c5121','10e9951b1d09e9ae195d82e7ad902e98f02c5121.jpeg'),(24,'ec98bcd5fbe0831de2f91e5c6c8c6ea3f2aaf772','ec98bcd5fbe0831de2f91e5c6c8c6ea3f2aaf772.jpeg'),(26,'4752648fdb30e14db4ac2bf16f33dbc2b7048372','4752648fdb30e14db4ac2bf16f33dbc2b7048372.jpeg'),(28,'89da376f6940f4645ff55598654505fbb83bfffb','89da376f6940f4645ff55598654505fbb83bfffb.jpeg'),(30,'e1df4fa382acdfa2c33bab32ed12fe53474b2a46','e1df4fa382acdfa2c33bab32ed12fe53474b2a46.jpeg'),(34,'fd1d829b892c3566a6468c6715c883884f351a43','fd1d829b892c3566a6468c6715c883884f351a43.jpeg'),(36,'44221397dabb3875b2df325ca9b41642db7d10fe','44221397dabb3875b2df325ca9b41642db7d10fe.jpeg');
/*!40000 ALTER TABLE `Image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Ingrediente`
--

DROP TABLE IF EXISTS `Ingrediente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Ingrediente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tasa_id` int(11) DEFAULT NULL,
  `productoproduccion_id` int(11) NOT NULL,
  `plato_id` int(11) DEFAULT NULL,
  `cantidad` decimal(10,2) DEFAULT NULL,
  `precioCosto` decimal(10,2) DEFAULT NULL,
  `coeficiente` decimal(10,6) DEFAULT NULL,
  `obligatorio` tinyint(1) NOT NULL,
  `preElaborado_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_39282BC9E20BE1E2` (`tasa_id`),
  KEY `IDX_39282BC93F84EE79` (`productoproduccion_id`),
  KEY `IDX_39282BC9508F408D` (`preElaborado_id`),
  KEY `IDX_39282BC9B0DB09EF` (`plato_id`),
  CONSTRAINT `FK_39282BC9B0DB09EF` FOREIGN KEY (`plato_id`) REFERENCES `Plato` (`id`),
  CONSTRAINT `FK_39282BC93F84EE79` FOREIGN KEY (`productoproduccion_id`) REFERENCES `ProductoProduccion` (`id`),
  CONSTRAINT `FK_39282BC9508F408D` FOREIGN KEY (`preElaborado_id`) REFERENCES `PreElaborado` (`id`),
  CONSTRAINT `FK_39282BC9E20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Ingrediente`
--

LOCK TABLES `Ingrediente` WRITE;
/*!40000 ALTER TABLE `Ingrediente` DISABLE KEYS */;
/*!40000 ALTER TABLE `Ingrediente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IngresoEmpleado`
--

DROP TABLE IF EXISTS `IngresoEmpleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IngresoEmpleado` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_6D473EC8BF396750` FOREIGN KEY (`id`) REFERENCES `mov_empleado` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IngresoEmpleado`
--

LOCK TABLES `IngresoEmpleado` WRITE;
/*!40000 ALTER TABLE `IngresoEmpleado` DISABLE KEYS */;
/*!40000 ALTER TABLE `IngresoEmpleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ItemCierre`
--

DROP TABLE IF EXISTS `ItemCierre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ItemCierre` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cierre_id` int(11) DEFAULT NULL,
  `importeSistema` decimal(10,2) DEFAULT NULL,
  `importeReal` decimal(10,2) DEFAULT NULL,
  `tipoCobro_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_38B20D6DC5CD756B` (`cierre_id`),
  KEY `IDX_38B20D6DE414003F` (`tipoCobro_id`),
  CONSTRAINT `FK_38B20D6DE414003F` FOREIGN KEY (`tipoCobro_id`) REFERENCES `TipoCobro` (`id`),
  CONSTRAINT `FK_38B20D6DC5CD756B` FOREIGN KEY (`cierre_id`) REFERENCES `Cierre` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ItemCierre`
--

LOCK TABLES `ItemCierre` WRITE;
/*!40000 ALTER TABLE `ItemCierre` DISABLE KEYS */;
/*!40000 ALTER TABLE `ItemCierre` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ItemDescuentoVenta`
--

DROP TABLE IF EXISTS `ItemDescuentoVenta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ItemDescuentoVenta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descuento_id` int(11) DEFAULT NULL,
  `venta_id` int(11) DEFAULT NULL,
  `totalDescuento` decimal(10,2) DEFAULT NULL,
  `totalDescuentoSinIva` decimal(10,2) DEFAULT NULL,
  `porcentaje` decimal(10,2) DEFAULT NULL,
  `detalle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_B45EDCDDF045077C` (`descuento_id`),
  KEY `IDX_B45EDCDDF2A5805D` (`venta_id`),
  CONSTRAINT `FK_B45EDCDDF2A5805D` FOREIGN KEY (`venta_id`) REFERENCES `Venta` (`id`),
  CONSTRAINT `FK_B45EDCDDF045077C` FOREIGN KEY (`descuento_id`) REFERENCES `DescuentoCliente` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ItemDescuentoVenta`
--

LOCK TABLES `ItemDescuentoVenta` WRITE;
/*!40000 ALTER TABLE `ItemDescuentoVenta` DISABLE KEYS */;
/*!40000 ALTER TABLE `ItemDescuentoVenta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ItemIvaVenta`
--

DROP TABLE IF EXISTS `ItemIvaVenta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ItemIvaVenta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iva_id` int(11) DEFAULT NULL,
  `venta_id` int(11) DEFAULT NULL,
  `tasa` decimal(10,3) DEFAULT NULL,
  `total` decimal(10,3) DEFAULT NULL,
  `gravado` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_F0C015DCF231661A` (`iva_id`),
  KEY `IDX_F0C015DCF2A5805D` (`venta_id`),
  CONSTRAINT `FK_F0C015DCF2A5805D` FOREIGN KEY (`venta_id`) REFERENCES `Venta` (`id`),
  CONSTRAINT `FK_F0C015DCF231661A` FOREIGN KEY (`iva_id`) REFERENCES `iva` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ItemIvaVenta`
--

LOCK TABLES `ItemIvaVenta` WRITE;
/*!40000 ALTER TABLE `ItemIvaVenta` DISABLE KEYS */;
/*!40000 ALTER TABLE `ItemIvaVenta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ItemLIV`
--

DROP TABLE IF EXISTS `ItemLIV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ItemLIV` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `liv_id` int(11) DEFAULT NULL,
  `tasa` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `gravado` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9EE103C98D8298DC` (`liv_id`),
  CONSTRAINT `FK_9EE103C98D8298DC` FOREIGN KEY (`liv_id`) REFERENCES `LibroIvaVenta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ItemLIV`
--

LOCK TABLES `ItemLIV` WRITE;
/*!40000 ALTER TABLE `ItemLIV` DISABLE KEYS */;
/*!40000 ALTER TABLE `ItemLIV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ItemPedido`
--

DROP TABLE IF EXISTS `ItemPedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ItemPedido` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tasa_id` int(11) DEFAULT NULL,
  `productoventa_id` int(11) DEFAULT NULL,
  `pedido_id` int(11) DEFAULT NULL,
  `precioUnitario` decimal(10,2) DEFAULT NULL,
  `descuento` decimal(10,2) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `cantidad` double DEFAULT NULL,
  `consideraciones` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaHora` datetime DEFAULT NULL,
  `vinculado` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_2C82E764E20BE1E2` (`tasa_id`),
  KEY `IDX_2C82E76417242A18` (`productoventa_id`),
  KEY `IDX_2C82E7644854653A` (`pedido_id`),
  CONSTRAINT `FK_2C82E7644854653A` FOREIGN KEY (`pedido_id`) REFERENCES `Pedido` (`id`),
  CONSTRAINT `FK_2C82E76417242A18` FOREIGN KEY (`productoventa_id`) REFERENCES `ProductoVenta` (`id`),
  CONSTRAINT `FK_2C82E764E20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ItemPedido`
--

LOCK TABLES `ItemPedido` WRITE;
/*!40000 ALTER TABLE `ItemPedido` DISABLE KEYS */;
/*!40000 ALTER TABLE `ItemPedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ItemRecargoVenta`
--

DROP TABLE IF EXISTS `ItemRecargoVenta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ItemRecargoVenta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recargo_id` int(11) DEFAULT NULL,
  `iva_id` int(11) DEFAULT NULL,
  `venta_id` int(11) DEFAULT NULL,
  `tasaIva` decimal(10,2) NOT NULL,
  `totalRecargo` decimal(10,2) NOT NULL,
  `totalRecargoSinIva` decimal(10,2) NOT NULL,
  `detalle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `porcentaje` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_83F6ECE2E3DAE5D1` (`recargo_id`),
  KEY `IDX_83F6ECE2F231661A` (`iva_id`),
  KEY `IDX_83F6ECE2F2A5805D` (`venta_id`),
  CONSTRAINT `FK_83F6ECE2F2A5805D` FOREIGN KEY (`venta_id`) REFERENCES `Venta` (`id`),
  CONSTRAINT `FK_83F6ECE2E3DAE5D1` FOREIGN KEY (`recargo_id`) REFERENCES `Recargo` (`id`),
  CONSTRAINT `FK_83F6ECE2F231661A` FOREIGN KEY (`iva_id`) REFERENCES `iva` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ItemRecargoVenta`
--

LOCK TABLES `ItemRecargoVenta` WRITE;
/*!40000 ALTER TABLE `ItemRecargoVenta` DISABLE KEYS */;
/*!40000 ALTER TABLE `ItemRecargoVenta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LibroIvaVenta`
--

DROP TABLE IF EXISTS `LibroIvaVenta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LibroIvaVenta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) DEFAULT NULL,
  `venta_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `tipo` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `cuit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `razonSocial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `neto` decimal(10,3) DEFAULT NULL,
  `acrecent` decimal(10,3) DEFAULT NULL,
  `total` decimal(10,3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_16A0DA06F2A5805D` (`venta_id`),
  KEY `IDX_16A0DA06DE734E51` (`cliente_id`),
  KEY `IDX_16A0DA06521E1991` (`empresa_id`),
  CONSTRAINT `FK_16A0DA06521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_16A0DA06DE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Cliente` (`id`),
  CONSTRAINT `FK_16A0DA06F2A5805D` FOREIGN KEY (`venta_id`) REFERENCES `Venta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LibroIvaVenta`
--

LOCK TABLES `LibroIvaVenta` WRITE;
/*!40000 ALTER TABLE `LibroIvaVenta` DISABLE KEYS */;
/*!40000 ALTER TABLE `LibroIvaVenta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LineaTanda`
--

DROP TABLE IF EXISTS `LineaTanda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LineaTanda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tanda_id` int(11) DEFAULT NULL,
  `cantidad` double DEFAULT NULL,
  `cantidadElaborados` double DEFAULT NULL,
  `consideraciones` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `productoVenta_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_7FEF55B9EE52484E` (`productoVenta_id`),
  KEY `IDX_7FEF55B9242F34B1` (`tanda_id`),
  CONSTRAINT `FK_7FEF55B9242F34B1` FOREIGN KEY (`tanda_id`) REFERENCES `Tanda` (`id`),
  CONSTRAINT `FK_7FEF55B9EE52484E` FOREIGN KEY (`productoVenta_id`) REFERENCES `ProductoVenta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LineaTanda`
--

LOCK TABLES `LineaTanda` WRITE;
/*!40000 ALTER TABLE `LineaTanda` DISABLE KEYS */;
/*!40000 ALTER TABLE `LineaTanda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LineaVenta`
--

DROP TABLE IF EXISTS `LineaVenta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LineaVenta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tasa_id` int(11) DEFAULT NULL,
  `venta_id` int(11) DEFAULT NULL,
  `cantidad` decimal(10,2) DEFAULT NULL,
  `tasaIva` decimal(10,2) DEFAULT NULL,
  `precioUnitario` decimal(10,2) DEFAULT NULL,
  `precioUnitarioSinIva` decimal(10,2) DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bonificacion` decimal(10,2) DEFAULT NULL,
  `precioNeto` decimal(10,2) DEFAULT NULL,
  `precioNetoSinIva` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `productoVenta_id` int(11) DEFAULT NULL,
  `ivaProductoVenta_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_C08F83DFEE52484E` (`productoVenta_id`),
  KEY `IDX_C08F83DF49460268` (`ivaProductoVenta_id`),
  KEY `IDX_C08F83DFE20BE1E2` (`tasa_id`),
  KEY `IDX_C08F83DFF2A5805D` (`venta_id`),
  CONSTRAINT `FK_C08F83DFF2A5805D` FOREIGN KEY (`venta_id`) REFERENCES `Venta` (`id`),
  CONSTRAINT `FK_C08F83DF49460268` FOREIGN KEY (`ivaProductoVenta_id`) REFERENCES `iva` (`id`),
  CONSTRAINT `FK_C08F83DFE20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`),
  CONSTRAINT `FK_C08F83DFEE52484E` FOREIGN KEY (`productoVenta_id`) REFERENCES `ProductoVenta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LineaVenta`
--

LOCK TABLES `LineaVenta` WRITE;
/*!40000 ALTER TABLE `LineaVenta` DISABLE KEYS */;
/*!40000 ALTER TABLE `LineaVenta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Localidad`
--

DROP TABLE IF EXISTS `Localidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Localidad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provincia_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CD9962B34E7121AF` (`provincia_id`),
  CONSTRAINT `FK_CD9962B34E7121AF` FOREIGN KEY (`provincia_id`) REFERENCES `Provincia` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Localidad`
--

LOCK TABLES `Localidad` WRITE;
/*!40000 ALTER TABLE `Localidad` DISABLE KEYS */;
/*!40000 ALTER TABLE `Localidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Lote`
--

DROP TABLE IF EXISTS `Lote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Lote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `caja_id` int(11) DEFAULT NULL,
  `fechaApertura` datetime DEFAULT NULL,
  `fechaCierre` datetime DEFAULT NULL,
  `saldo` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_C5869DA1DB38439E` (`usuario_id`),
  KEY `IDX_C5869DA12D82B651` (`caja_id`),
  CONSTRAINT `FK_C5869DA12D82B651` FOREIGN KEY (`caja_id`) REFERENCES `Caja` (`id`),
  CONSTRAINT `FK_C5869DA1DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Lote`
--

LOCK TABLES `Lote` WRITE;
/*!40000 ALTER TABLE `Lote` DISABLE KEYS */;
/*!40000 ALTER TABLE `Lote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Mantenimiento`
--

DROP TABLE IF EXISTS `Mantenimiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Mantenimiento` (
  `id` int(11) NOT NULL,
  `tasa_id` int(11) DEFAULT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `iva_id` int(11) DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `precioCosto` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_8E3E5820E20BE1E2` (`tasa_id`),
  KEY `IDX_8E3E5820CB305D73` (`proveedor_id`),
  KEY `IDX_8E3E5820F231661A` (`iva_id`),
  CONSTRAINT `FK_8E3E5820BF396750` FOREIGN KEY (`id`) REFERENCES `Producto` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_8E3E5820CB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedor` (`id`),
  CONSTRAINT `FK_8E3E5820E20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`),
  CONSTRAINT `FK_8E3E5820F231661A` FOREIGN KEY (`iva_id`) REFERENCES `iva` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Mantenimiento`
--

LOCK TABLES `Mantenimiento` WRITE;
/*!40000 ALTER TABLE `Mantenimiento` DISABLE KEYS */;
/*!40000 ALTER TABLE `Mantenimiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Marca`
--

DROP TABLE IF EXISTS `Marca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Marca` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Marca`
--

LOCK TABLES `Marca` WRITE;
/*!40000 ALTER TABLE `Marca` DISABLE KEYS */;
/*!40000 ALTER TABLE `Marca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MarcaTemporal`
--

DROP TABLE IF EXISTS `MarcaTemporal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MarcaTemporal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cocina_id` int(11) DEFAULT NULL,
  `color` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `minutos` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D82C185D2311565A` (`cocina_id`),
  CONSTRAINT `FK_D82C185D2311565A` FOREIGN KEY (`cocina_id`) REFERENCES `Cocina` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MarcaTemporal`
--

LOCK TABLES `MarcaTemporal` WRITE;
/*!40000 ALTER TABLE `MarcaTemporal` DISABLE KEYS */;
/*!40000 ALTER TABLE `MarcaTemporal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MateriaPrima`
--

DROP TABLE IF EXISTS `MateriaPrima`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MateriaPrima` (
  `id` int(11) NOT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `tasa_id` int(11) DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `precioCosto` decimal(10,2) DEFAULT NULL,
  `cantidad` decimal(10,2) DEFAULT NULL,
  `superaMin` tinyint(1) DEFAULT NULL,
  `cantidadMinima` decimal(10,2) DEFAULT NULL,
  `iva_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CA2388F3CB305D73` (`proveedor_id`),
  KEY `IDX_CA2388F3E20BE1E2` (`tasa_id`),
  KEY `IDX_CA2388F3F231661A` (`iva_id`),
  CONSTRAINT `FK_CA2388F3BF396750` FOREIGN KEY (`id`) REFERENCES `Producto` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_CA2388F3CB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedor` (`id`),
  CONSTRAINT `FK_CA2388F3E20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`),
  CONSTRAINT `FK_CA2388F3F231661A` FOREIGN KEY (`iva_id`) REFERENCES `iva` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MateriaPrima`
--

LOCK TABLES `MateriaPrima` WRITE;
/*!40000 ALTER TABLE `MateriaPrima` DISABLE KEYS */;
INSERT INTO `MateriaPrima` VALUES (7,3,2,NULL,9.00,5.00,0,3.00,2),(8,4,5,NULL,48.00,8.00,0,2.00,1),(9,4,5,NULL,45.00,6.00,0,3.00,1),(10,3,5,NULL,18.00,3.00,0,2.00,2),(11,3,5,NULL,8.00,15.00,0,5.00,2),(12,2,5,NULL,3.50,5.00,0,2.00,1),(13,5,5,NULL,35.00,15.00,0,5.00,1),(14,3,5,NULL,7.50,10.00,0,5.00,1),(15,5,5,NULL,38.00,15.00,0,5.00,1),(16,2,5,NULL,16.00,15.00,0,5.00,1),(17,5,5,NULL,33.00,13.00,0,6.00,1),(18,2,5,'Polvo para hacer salsa demi galce',48.00,2.00,0,1.00,1),(20,2,6,NULL,9.00,3.00,0,2.00,1),(23,2,5,NULL,35.00,1.00,0,0.50,1),(24,2,5,NULL,40.00,2.00,0,0.50,1),(26,2,5,NULL,35.00,3.00,0,1.00,1),(27,6,2,'Pan redondo para la elaboracion de hamburguesa',28.00,5.00,0,2.00,1),(28,6,2,'Pan para elaborar los distintos sandwich',28.00,5.00,0,2.00,1),(29,2,5,NULL,28.00,3.00,0,0.50,1),(30,2,5,NULL,12.00,12.00,0,5.00,1),(34,2,5,NULL,33.00,10.00,0,1.00,1),(36,4,5,NULL,42.00,15.00,0,5.00,1),(41,2,7,NULL,27.00,8.00,0,5.00,1);
/*!40000 ALTER TABLE `MateriaPrima` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Mercaderia`
--

DROP TABLE IF EXISTS `Mercaderia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Mercaderia` (
  `id` int(11) NOT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `imagen_id` int(11) DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `precioVenta` decimal(10,2) DEFAULT NULL,
  `precioCosto` decimal(10,2) DEFAULT NULL,
  `cantidad` decimal(10,2) DEFAULT NULL,
  `margen` decimal(10,2) DEFAULT NULL,
  `margenMin` decimal(10,2) DEFAULT NULL,
  `supera` tinyint(1) NOT NULL,
  `cantidadMinima` decimal(10,2) DEFAULT NULL,
  `iva_id` int(11) DEFAULT NULL,
  `tasa_id` int(11) DEFAULT NULL,
  `superaMin` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_B00CD745763C8AA7` (`imagen_id`),
  KEY `IDX_B00CD745CB305D73` (`proveedor_id`),
  KEY `IDX_B00CD745F231661A` (`iva_id`),
  KEY `IDX_B00CD745E20BE1E2` (`tasa_id`),
  CONSTRAINT `FK_B00CD745E20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`),
  CONSTRAINT `FK_B00CD745763C8AA7` FOREIGN KEY (`imagen_id`) REFERENCES `Image` (`id`),
  CONSTRAINT `FK_B00CD745BF396750` FOREIGN KEY (`id`) REFERENCES `Producto` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_B00CD745CB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedor` (`id`),
  CONSTRAINT `FK_B00CD745F231661A` FOREIGN KEY (`iva_id`) REFERENCES `iva` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Mercaderia`
--

LOCK TABLES `Mercaderia` WRITE;
/*!40000 ALTER TABLE `Mercaderia` DISABLE KEYS */;
INSERT INTO `Mercaderia` VALUES (1,1,2,NULL,20.00,12.00,30.00,66.67,50.00,0,20.00,1,1,0),(2,1,4,NULL,30.00,17.00,25.00,76.47,50.00,0,15.00,1,1,0),(3,1,8,NULL,20.00,13.50,20.00,48.15,35.00,0,10.00,1,1,0),(4,1,10,NULL,20.00,13.50,15.00,48.15,0.00,0,10.00,1,1,0),(5,2,12,NULL,50.00,27.00,10.00,85.19,30.00,0,5.00,1,1,0),(6,2,14,NULL,207.00,115.00,6.00,80.00,70.00,0,4.00,1,1,0);
/*!40000 ALTER TABLE `Mercaderia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Mesa`
--

DROP TABLE IF EXISTS `Mesa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Mesa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sector_id` int(11) DEFAULT NULL,
  `numero` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_38812DCCDE95C867` (`sector_id`),
  CONSTRAINT `FK_38812DCCDE95C867` FOREIGN KEY (`sector_id`) REFERENCES `Sector` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Mesa`
--

LOCK TABLES `Mesa` WRITE;
/*!40000 ALTER TABLE `Mesa` DISABLE KEYS */;
/*!40000 ALTER TABLE `Mesa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Movimiento`
--

DROP TABLE IF EXISTS `Movimiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Movimiento` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lote_id` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `concepto_id` int(11) DEFAULT NULL,
  `importe` decimal(10,2) DEFAULT NULL,
  `aclaracion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `dtype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_87A213AAB172197C` (`lote_id`),
  KEY `IDX_87A213AAA9276E6C` (`tipo_id`),
  KEY `IDX_87A213AA6C2330BD` (`concepto_id`),
  CONSTRAINT `FK_87A213AA6C2330BD` FOREIGN KEY (`concepto_id`) REFERENCES `Concepto` (`id`),
  CONSTRAINT `FK_87A213AAA9276E6C` FOREIGN KEY (`tipo_id`) REFERENCES `TipoCobro` (`id`),
  CONSTRAINT `FK_87A213AAB172197C` FOREIGN KEY (`lote_id`) REFERENCES `Lote` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Movimiento`
--

LOCK TABLES `Movimiento` WRITE;
/*!40000 ALTER TABLE `Movimiento` DISABLE KEYS */;
/*!40000 ALTER TABLE `Movimiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MovimientoCuentaCorriente`
--

DROP TABLE IF EXISTS `MovimientoCuentaCorriente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MovimientoCuentaCorriente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cuenta_id` int(11) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `importe` decimal(10,2) NOT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dtype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_63A09DF29AEFF118` (`cuenta_id`),
  CONSTRAINT `FK_63A09DF29AEFF118` FOREIGN KEY (`cuenta_id`) REFERENCES `CuentaCorriente` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MovimientoCuentaCorriente`
--

LOCK TABLES `MovimientoCuentaCorriente` WRITE;
/*!40000 ALTER TABLE `MovimientoCuentaCorriente` DISABLE KEYS */;
/*!40000 ALTER TABLE `MovimientoCuentaCorriente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MovimientoCuentaCorrienteDebe`
--

DROP TABLE IF EXISTS `MovimientoCuentaCorrienteDebe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MovimientoCuentaCorrienteDebe` (
  `id` int(11) NOT NULL,
  `unaVenta_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_B225FCCBE35D31B` (`unaVenta_id`),
  CONSTRAINT `FK_B225FCCBBF396750` FOREIGN KEY (`id`) REFERENCES `MovimientoCuentaCorriente` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_B225FCCBE35D31B` FOREIGN KEY (`unaVenta_id`) REFERENCES `Venta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MovimientoCuentaCorrienteDebe`
--

LOCK TABLES `MovimientoCuentaCorrienteDebe` WRITE;
/*!40000 ALTER TABLE `MovimientoCuentaCorrienteDebe` DISABLE KEYS */;
/*!40000 ALTER TABLE `MovimientoCuentaCorrienteDebe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MovimientoCuentaCorrienteHaber`
--

DROP TABLE IF EXISTS `MovimientoCuentaCorrienteHaber`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MovimientoCuentaCorrienteHaber` (
  `id` int(11) NOT NULL,
  `unRecibo_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_2A9FBB0F63616B01` (`unRecibo_id`),
  CONSTRAINT `FK_2A9FBB0FBF396750` FOREIGN KEY (`id`) REFERENCES `MovimientoCuentaCorriente` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_2A9FBB0F63616B01` FOREIGN KEY (`unRecibo_id`) REFERENCES `Recibo` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MovimientoCuentaCorrienteHaber`
--

LOCK TABLES `MovimientoCuentaCorrienteHaber` WRITE;
/*!40000 ALTER TABLE `MovimientoCuentaCorrienteHaber` DISABLE KEYS */;
/*!40000 ALTER TABLE `MovimientoCuentaCorrienteHaber` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NotaCredito`
--

DROP TABLE IF EXISTS `NotaCredito`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `NotaCredito` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `factura_id` int(11) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cuit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serie` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `numero` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `condicionIva_id` int(11) DEFAULT NULL,
  `condicionIvaEmpresa_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_799C85D7F04F795F` (`factura_id`),
  KEY `IDX_799C85D7DB38439E` (`usuario_id`),
  KEY `IDX_799C85D7DE734E51` (`cliente_id`),
  KEY `IDX_799C85D7F60CF12A` (`condicionIva_id`),
  KEY `IDX_799C85D75C25E126` (`condicionIvaEmpresa_id`),
  CONSTRAINT `FK_799C85D7F04F795F` FOREIGN KEY (`factura_id`) REFERENCES `Venta` (`id`),
  CONSTRAINT `FK_799C85D75C25E126` FOREIGN KEY (`condicionIvaEmpresa_id`) REFERENCES `CondicionIva` (`id`),
  CONSTRAINT `FK_799C85D7DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`),
  CONSTRAINT `FK_799C85D7DE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Cliente` (`id`),
  CONSTRAINT `FK_799C85D7F60CF12A` FOREIGN KEY (`condicionIva_id`) REFERENCES `CondicionIva` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NotaCredito`
--

LOCK TABLES `NotaCredito` WRITE;
/*!40000 ALTER TABLE `NotaCredito` DISABLE KEYS */;
/*!40000 ALTER TABLE `NotaCredito` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Operacion`
--

DROP TABLE IF EXISTS `Operacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Operacion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `de_id` int(11) DEFAULT NULL,
  `a_id` int(11) DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipoOperacion_id` int(11) DEFAULT NULL,
  `tipoFactura_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_56BE4BE8957DD03D` (`tipoOperacion_id`),
  KEY `IDX_56BE4BE810E064DC` (`tipoFactura_id`),
  KEY `IDX_56BE4BE83F683D83` (`de_id`),
  KEY `IDX_56BE4BE83BDE5358` (`a_id`),
  CONSTRAINT `FK_56BE4BE83BDE5358` FOREIGN KEY (`a_id`) REFERENCES `CondicionIva` (`id`),
  CONSTRAINT `FK_56BE4BE810E064DC` FOREIGN KEY (`tipoFactura_id`) REFERENCES `TipoFactura` (`id`),
  CONSTRAINT `FK_56BE4BE83F683D83` FOREIGN KEY (`de_id`) REFERENCES `CondicionIva` (`id`),
  CONSTRAINT `FK_56BE4BE8957DD03D` FOREIGN KEY (`tipoOperacion_id`) REFERENCES `TipoOperacion` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Operacion`
--

LOCK TABLES `Operacion` WRITE;
/*!40000 ALTER TABLE `Operacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `Operacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Pais`
--

DROP TABLE IF EXISTS `Pais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Pais` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Pais`
--

LOCK TABLES `Pais` WRITE;
/*!40000 ALTER TABLE `Pais` DISABLE KEYS */;
/*!40000 ALTER TABLE `Pais` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Pedido`
--

DROP TABLE IF EXISTS `Pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Pedido` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `tanda_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `direccion_id` int(11) DEFAULT NULL,
  `mesa_id` int(11) DEFAULT NULL,
  `cocina_id` int(11) DEFAULT NULL,
  `fechapedido` datetime DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `solicitante` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `motivoCancelacion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registroEnvio_id` int(11) DEFAULT NULL,
  `tipoPedido_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_C34013F8D0A7BD7` (`direccion_id`),
  UNIQUE KEY `UNIQ_C34013F88BDC7AE9` (`mesa_id`),
  KEY `IDX_C34013F8DE734E51` (`cliente_id`),
  KEY `IDX_C34013F8521E1991` (`empresa_id`),
  KEY `IDX_C34013F8242F34B1` (`tanda_id`),
  KEY `IDX_C34013F8C013411B` (`registroEnvio_id`),
  KEY `IDX_C34013F8DB38439E` (`usuario_id`),
  KEY `IDX_C34013F82311565A` (`cocina_id`),
  KEY `IDX_C34013F832A0F830` (`tipoPedido_id`),
  CONSTRAINT `FK_C34013F832A0F830` FOREIGN KEY (`tipoPedido_id`) REFERENCES `TipoPedido` (`id`),
  CONSTRAINT `FK_C34013F82311565A` FOREIGN KEY (`cocina_id`) REFERENCES `Cocina` (`id`),
  CONSTRAINT `FK_C34013F8242F34B1` FOREIGN KEY (`tanda_id`) REFERENCES `Tanda` (`id`),
  CONSTRAINT `FK_C34013F8521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_C34013F88BDC7AE9` FOREIGN KEY (`mesa_id`) REFERENCES `Mesa` (`id`),
  CONSTRAINT `FK_C34013F8C013411B` FOREIGN KEY (`registroEnvio_id`) REFERENCES `RegistroEnvio` (`id`),
  CONSTRAINT `FK_C34013F8D0A7BD7` FOREIGN KEY (`direccion_id`) REFERENCES `Direccion` (`id`),
  CONSTRAINT `FK_C34013F8DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`),
  CONSTRAINT `FK_C34013F8DE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Cliente` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Pedido`
--

LOCK TABLES `Pedido` WRITE;
/*!40000 ALTER TABLE `Pedido` DISABLE KEYS */;
/*!40000 ALTER TABLE `Pedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PedidoDelivery`
--

DROP TABLE IF EXISTS `PedidoDelivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PedidoDelivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fechapedido` datetime DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `solicitante` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `motivoCancelacion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PedidoDelivery`
--

LOCK TABLES `PedidoDelivery` WRITE;
/*!40000 ALTER TABLE `PedidoDelivery` DISABLE KEYS */;
/*!40000 ALTER TABLE `PedidoDelivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PedidoMesa`
--

DROP TABLE IF EXISTS `PedidoMesa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PedidoMesa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fechapedido` datetime DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `solicitante` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `motivoCancelacion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PedidoMesa`
--

LOCK TABLES `PedidoMesa` WRITE;
/*!40000 ALTER TABLE `PedidoMesa` DISABLE KEYS */;
/*!40000 ALTER TABLE `PedidoMesa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PedidoMostrador`
--

DROP TABLE IF EXISTS `PedidoMostrador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PedidoMostrador` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fechapedido` datetime DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `solicitante` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `motivoCancelacion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PedidoMostrador`
--

LOCK TABLES `PedidoMostrador` WRITE;
/*!40000 ALTER TABLE `PedidoMostrador` DISABLE KEYS */;
/*!40000 ALTER TABLE `PedidoMostrador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Permiso`
--

DROP TABLE IF EXISTS `Permiso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Permiso` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `objeto` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `otorgado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_32C79202D60322AC` (`role_id`),
  CONSTRAINT `FK_32C79202D60322AC` FOREIGN KEY (`role_id`) REFERENCES `Rol` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=185 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Permiso`
--

LOCK TABLES `Permiso` WRITE;
/*!40000 ALTER TABLE `Permiso` DISABLE KEYS */;
INSERT INTO `Permiso` VALUES (1,1,'auditoria_listar',1),(2,1,'auditoria_elegir_carpeta',1),(3,1,'auditoria_descargar_archivo',1),(4,1,'auditoria_imprimir',1),(5,1,'agenda_gestionar_agenda',1),(6,1,'backup_listar',1),(7,1,'backup_registrar',1),(8,1,'backup_descargar',1),(9,1,'backup_elegir_carpeta',1),(10,1,'backup_imprimir',1),(11,1,'cargo_listar',1),(12,1,'cargo_nuevo',1),(13,1,'cargo_editar',1),(14,1,'cargo_activar',1),(15,1,'cargo_borrar',1),(16,1,'categoriaProductoProduccion_listar',1),(17,1,'categoriaProductoProduccion_nuevo',1),(18,1,'categoriaProductoProduccion_editar',1),(19,1,'categoriaProductoProduccion_borrar',1),(20,1,'categoriaProductoVenta_listar',1),(21,1,'categoriaProductoVenta_nuevo',1),(22,1,'categoriaProductoVenta_editar',1),(23,1,'categoriaProductoVenta_borrar',1),(24,1,'chat_gestionar_chat',1),(25,1,'ciudad_listar',1),(26,1,'ciudad_nuevo',1),(27,1,'ciudad_editar',1),(28,1,'ciudad_borrar',1),(29,1,'compra_listar',1),(30,1,'compra_pago_por_proveedor',1),(31,1,'compra_pago_por_factura',1),(32,1,'compra_nuevo',1),(33,1,'compra_imprimir',1),(34,1,'condiciones IVA_listar',1),(35,1,'condiciones IVA_nuevo',1),(36,1,'condiciones IVA_editar',1),(37,1,'condiciones IVA_activar',1),(38,1,'condiciones IVA_borrar',1),(39,1,'empleado_listar',1),(40,1,'empleado_nuevo',1),(41,1,'empleado_editar',1),(42,1,'empleado_detalles-Acciones_de_pago',1),(43,1,'empleado_Gestión_y_acciones_de_pago',1),(44,1,'empleado_activar',1),(45,1,'empleado_borrar',1),(46,1,'empleado-Imprimir_lista_de_empleados',1),(47,1,'empleado-Imprimir_comprobante_de_pago',1),(48,1,'empleado-Imprimir_detalles-Acciones_de_pago',1),(49,1,'empresa_editar',1),(50,1,'facturaServicio_listar',1),(51,1,'facturaServicio_nuevo',1),(52,1,'facturaServicio_imprimir',1),(53,1,'IVA_listar',1),(54,1,'IVA_nuevo',1),(55,1,'IVA_editar',1),(56,1,'IVA_borrar',1),(57,1,'IVA_activar',1),(58,1,'ingrediente_nuevo',1),(59,1,'ingrediente_editar',1),(60,1,'ingrediente_borrar',1),(61,1,'LibroIVACompra_listar',1),(62,1,'LibroIVACompra_imprimir',1),(63,1,'mantenimiento_listar',1),(64,1,'mantenimiento_nuevo',1),(65,1,'mantenimiento_editar',1),(66,1,'mantenimiento_borrar',1),(67,1,'materiaPrima_listar',1),(68,1,'materiaPrima_nuevo',1),(69,1,'materiaPrima_editar',1),(70,1,'materiaPrima_borrar',1),(71,1,'mercaderia_listar',1),(72,1,'mercaderia_nuevo',1),(73,1,'mercaderia_editar',1),(74,1,'mercaderia_borrar',1),(75,1,'notaPedido_listar',1),(76,1,'notaPedido_nuevo',1),(77,1,'notaPedido_editar',1),(78,1,'notaPedido_imprimir',1),(79,1,'operaciones_listar',1),(80,1,'operaciones_nuevo',1),(81,1,'operaciones_editar',1),(82,1,'operaciones_activar',1),(83,1,'operaciones_borrar',1),(84,1,'pago_listar',1),(85,1,'pago_registrar_salidad_de_caja',1),(86,1,'pago_imprimir',1),(87,1,'plato_listar',1),(88,1,'plato_nuevo',1),(89,1,'plato_editar',1),(90,1,'plato_borrar',1),(91,1,'pre-Elaborado_listar',1),(92,1,'pre-Elaborado_nuevo',1),(93,1,'pre-Elaborado_editar',1),(94,1,'pre-Elaborado_borrar',1),(95,1,'producto_listar_producto_venta',1),(96,1,'producto_listar_producto_prodccion',1),(97,1,'producto_Gestión de menu',1),(98,1,'producto_activar',1),(99,1,'producto_imprimir',1),(100,1,'proveedor_listar',1),(101,1,'proveedor_nuevo',1),(102,1,'proveedor_editar',1),(103,1,'proveedor_borrar',1),(104,1,'proveedor_activar',1),(105,1,'proveedor_imprimir',1),(106,1,'provincia_listar',1),(107,1,'provincia_nuevo',1),(108,1,'provincia_editar',1),(109,1,'provincia_borrar',1),(110,1,'registro_listar',1),(111,1,'registro_registro_producción_por_cantidad',1),(112,1,'registro_registro_producción_por_ingredientes',1),(113,1,'registro_registro_pérdida_de_producción',1),(114,1,'registro_imprimir',1),(115,1,'servicio_listar',1),(116,1,'servicio_nuevo',1),(117,1,'servicio_editar',1),(118,1,'servicio_borrar',1),(119,1,'servicio_activar',1),(120,1,'servicio_imprimir',1),(121,1,'unidad de medida y tasas_listar',1),(122,1,'unidad de medida y tasas_Gestion',1),(123,1,'notificaciones de sistema_Mostrar',1),(124,1,'caja_apertura_y_cierre',1),(125,1,'cliente_listar',1),(126,1,'cliente_nuevo',1),(127,1,'cliente_editar',1),(128,1,'cliente_borrar',1),(129,1,'cocina_gestionar',1),(130,1,'pedido_listar',1),(131,1,'pedido_nuevo',1),(132,1,'pedido_editar',1),(133,1,'pedido_borrar',1),(134,1,'rol_listar',1),(135,1,'rol_nuevo',1),(136,1,'rol_editar',1),(137,1,'rol_borrar',1),(138,1,'rol_activar',1),(139,1,'tipoCobro_listar',1),(140,1,'tipoCobro_nuevo',1),(141,1,'tipoCobro_editar',1),(142,1,'tipoCobro_activar',1),(143,1,'tipoCobro_borrar',1),(144,1,'tipoDocumento_listar',1),(145,1,'tipoDocumento_nuevo',1),(146,1,'tipoDocumento_editar',1),(147,1,'tipoDocumento_borrar',1),(148,1,'usuario_listar',1),(149,1,'usuario_nuevo',1),(150,1,'usuario_editar',1),(151,1,'usuario_borrar',1),(152,1,'usuario_activar',1),(153,1,'usuario_ver_Perfil',1),(154,1,'usuario_cambiar_Contrseña',1),(155,1,'usuario_recuperar_Contrseña',1),(156,1,'usuario_imprimir',1),(157,1,'venta_listar',1),(158,1,'venta_nuevo',1),(159,1,'venta_editar',1),(160,1,'venta_borrar',1),(161,1,'descuento_listar',1),(162,1,'descuento_nuevo',1),(163,1,'descuento_editar',1),(164,1,'descuento_borrar',1),(165,1,'recargo_listar',1),(166,1,'recargo_nuevo',1),(167,1,'recargo_editar',1),(168,1,'recargo_borrar',1),(169,1,'grupo_cliente_listar',1),(170,1,'grupo_cliente_nuevo',1),(171,1,'grupo_cliente_editar',1),(172,1,'grupo_cliente_borrar',1),(173,1,'envio_listar',1),(174,1,'envio_nuevo',1),(175,1,'envio_editar',1),(176,1,'envio_borrar',1),(177,1,'cuenta_corriente_listar',1),(178,1,'cuenta_corriente_nuevo',1),(179,1,'cuenta_corriente_editar',1),(180,1,'cuenta_corriente_borrar',1),(181,1,'sector_listar',1),(182,1,'sector_nuevo',1),(183,1,'sector_editar',1),(184,1,'sector_borrar',1);
/*!40000 ALTER TABLE `Permiso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Persona`
--

DROP TABLE IF EXISTS `Persona`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Persona` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `direccion_id` int(11) DEFAULT NULL,
  `dni` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `apellido` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activo` tinyint(1) NOT NULL,
  `discr` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_9E588F07D0A7BD7` (`direccion_id`),
  CONSTRAINT `FK_9E588F07D0A7BD7` FOREIGN KEY (`direccion_id`) REFERENCES `Direccion` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Persona`
--

LOCK TABLES `Persona` WRITE;
/*!40000 ALTER TABLE `Persona` DISABLE KEYS */;
/*!40000 ALTER TABLE `Persona` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Plato`
--

DROP TABLE IF EXISTS `Plato`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Plato` (
  `id` int(11) NOT NULL,
  `imagen_id` int(11) DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `precioCosto` decimal(10,2) DEFAULT NULL,
  `cantidad` decimal(10,2) DEFAULT NULL,
  `precioVenta` decimal(10,2) DEFAULT NULL,
  `cantidadMinima` decimal(10,2) DEFAULT NULL,
  `margen` decimal(10,2) DEFAULT NULL,
  `margenMin` decimal(10,2) DEFAULT NULL,
  `supera` tinyint(1) DEFAULT NULL,
  `superaMin` tinyint(1) DEFAULT NULL,
  `iva_id` int(11) DEFAULT NULL,
  `tasa_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_508A1141763C8AA7` (`imagen_id`),
  KEY `IDX_508A1141F231661A` (`iva_id`),
  KEY `IDX_508A1141E20BE1E2` (`tasa_id`),
  CONSTRAINT `FK_508A1141E20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`),
  CONSTRAINT `FK_508A1141763C8AA7` FOREIGN KEY (`imagen_id`) REFERENCES `Image` (`id`),
  CONSTRAINT `FK_508A1141BF396750` FOREIGN KEY (`id`) REFERENCES `Producto` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_508A1141F231661A` FOREIGN KEY (`iva_id`) REFERENCES `iva` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Plato`
--

LOCK TABLES `Plato` WRITE;
/*!40000 ALTER TABLE `Plato` DISABLE KEYS */;
INSERT INTO `Plato` VALUES (32,16,'Milanesa con dos huevos fritos',8.64,1.00,40.00,0.00,363.10,65.00,0,0,1,1),(33,18,NULL,12.80,1.00,30.00,0.00,134.31,70.00,0,0,1,1),(35,20,NULL,18.40,1.00,38.00,0.00,106.56,60.00,0,0,1,1),(37,22,NULL,18.57,1.00,43.00,0.00,131.54,72.00,0,0,1,1),(38,24,NULL,13.11,1.00,30.00,0.00,128.77,55.00,0,0,1,1),(39,26,NULL,0.00,1.00,43.00,0.00,429900.00,70.00,0,0,1,1),(40,28,NULL,2.80,1.00,20.00,0.00,614.29,60.00,0,0,1,1),(42,30,'Porcion de papa frita',2.27,1.00,20.00,0.00,782.90,75.00,0,0,1,1);
/*!40000 ALTER TABLE `Plato` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PreElaborado`
--

DROP TABLE IF EXISTS `PreElaborado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PreElaborado` (
  `id` int(11) NOT NULL,
  `tasa_id` int(11) DEFAULT NULL,
  `cantidad` decimal(10,2) DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `precioCosto` decimal(10,2) DEFAULT NULL,
  `superaMin` tinyint(1) NOT NULL,
  `cantidadMinima` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_E24F592FE20BE1E2` (`tasa_id`),
  CONSTRAINT `FK_E24F592FE20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`),
  CONSTRAINT `FK_E24F592FBF396750` FOREIGN KEY (`id`) REFERENCES `Producto` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PreElaborado`
--

LOCK TABLES `PreElaborado` WRITE;
/*!40000 ALTER TABLE `PreElaborado` DISABLE KEYS */;
INSERT INTO `PreElaborado` VALUES (19,5,NULL,'28.55',0.00,1,10.00),(21,1,0.00,'3.49',0.00,1,15.00),(22,5,0.00,'26.59',0.00,1,4.00),(25,5,NULL,'18.65',0.00,1,1.00),(31,1,NULL,'4.85',0.00,1,10.00);
/*!40000 ALTER TABLE `PreElaborado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Producto`
--

DROP TABLE IF EXISTS `Producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Producto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  `discr` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_5ECD6443521E1991` (`empresa_id`),
  CONSTRAINT `FK_5ECD6443521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Producto`
--

LOCK TABLES `Producto` WRITE;
/*!40000 ALTER TABLE `Producto` DISABLE KEYS */;
INSERT INTO `Producto` VALUES (1,1,'Cerveza Quilmes Cristal x 1L',1,'mercaderia'),(2,1,'Stella Artois x 1L',1,'mercaderia'),(3,1,'Pepsi x 2.25L',1,'mercaderia'),(4,1,'Paso de los toros pomelo x 2.25L',1,'mercaderia'),(5,1,'Vino Latitud 33° tinto',1,'mercaderia'),(6,1,'Rutini tinto x 750 cc',1,'mercaderia'),(7,1,'Huevo',1,'materiaprima'),(8,1,'Queso en barra',1,'materiaprima'),(9,1,'Jamon',1,'materiaprima'),(10,1,'Lechuga',1,'materiaprima'),(11,1,'Tomate redondo',1,'materiaprima'),(12,1,'Sal fina',1,'materiaprima'),(13,1,'Carne molida',1,'materiaprima'),(14,1,'Cebolla',1,'materiaprima'),(15,1,'Lomo',1,'materiaprima'),(16,1,'Revosador',1,'materiaprima'),(17,1,'Nalga',1,'materiaprima'),(18,1,'Demi glace',1,'materiaprima'),(19,1,'Milanesa',1,'preelaborado'),(20,1,'Maizena',1,'materiaprima'),(21,1,'Medallon de Hamburguesa',1,'preelaborado'),(22,1,'Picadillo de Carne',1,'preelaborado'),(23,1,'Condimento para carne',1,'materiaprima'),(24,1,'Oregano',1,'materiaprima'),(25,1,'Salsa para pizza',1,'preelaborado'),(26,1,'Salsa portuguesa',1,'materiaprima'),(27,1,'Pan de hamburguesa',1,'materiaprima'),(28,1,'Pan ternerita',1,'materiaprima'),(29,1,'Levadura',1,'materiaprima'),(30,1,'Harina 4 cero 0000',1,'materiaprima'),(31,1,'Pre pizza',1,'preelaborado'),(32,1,'Milanesa a caballo',1,'plato'),(33,1,'Sandwich de lomo simple SLS',1,'plato'),(34,1,'Aceituna',1,'materiaprima'),(35,1,'Pizza Mozzarella',1,'plato'),(36,1,'Queso Mozzarella',1,'materiaprima'),(37,1,'Pizza Napolitana',1,'plato'),(38,1,'Sandwich de Milanesa Compleata SMC',1,'plato'),(39,1,'Lomo encebollado',1,'plato'),(40,1,'Ensalada de lechuga y tomate',1,'plato'),(41,1,'Papa Frita Mc Cain',1,'materiaprima'),(42,1,'Papa frita',1,'plato');
/*!40000 ALTER TABLE `Producto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ProductoProduccion`
--

DROP TABLE IF EXISTS `ProductoProduccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ProductoProduccion` (
  `id` int(11) NOT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_B73571113397707A` (`categoria_id`),
  CONSTRAINT `FK_B73571113397707A` FOREIGN KEY (`categoria_id`) REFERENCES `CategoriaProductoProduccion` (`id`),
  CONSTRAINT `FK_B7357111BF396750` FOREIGN KEY (`id`) REFERENCES `Producto` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProductoProduccion`
--

LOCK TABLES `ProductoProduccion` WRITE;
/*!40000 ALTER TABLE `ProductoProduccion` DISABLE KEYS */;
INSERT INTO `ProductoProduccion` VALUES (7,2),(10,2),(11,2),(14,2),(12,3),(18,3),(20,3),(23,3),(24,3),(29,3),(8,4),(9,4),(36,4),(13,5),(15,5),(17,5),(16,6),(27,6),(28,6),(31,6),(19,7),(21,7),(22,7),(25,8),(26,9),(34,9),(30,10),(41,11);
/*!40000 ALTER TABLE `ProductoProduccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ProductoVenta`
--

DROP TABLE IF EXISTS `ProductoVenta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ProductoVenta` (
  `id` int(11) NOT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_587EF6553397707A` (`categoria_id`),
  CONSTRAINT `FK_587EF6553397707A` FOREIGN KEY (`categoria_id`) REFERENCES `CategoriaProductoVenta` (`id`),
  CONSTRAINT `FK_587EF655BF396750` FOREIGN KEY (`id`) REFERENCES `Producto` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProductoVenta`
--

LOCK TABLES `ProductoVenta` WRITE;
/*!40000 ALTER TABLE `ProductoVenta` DISABLE KEYS */;
INSERT INTO `ProductoVenta` VALUES (3,2),(4,2),(1,3),(2,3),(5,4),(6,4),(33,5),(38,5),(32,6),(39,6),(40,7),(42,7),(35,8),(37,8);
/*!40000 ALTER TABLE `ProductoVenta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Provincia`
--

DROP TABLE IF EXISTS `Provincia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Provincia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa_id` int(11) DEFAULT NULL,
  `nombre` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `porDefecto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_516B70B03A909126` (`nombre`),
  KEY `IDX_516B70B0521E1991` (`empresa_id`),
  CONSTRAINT `FK_516B70B0521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Provincia`
--

LOCK TABLES `Provincia` WRITE;
/*!40000 ALTER TABLE `Provincia` DISABLE KEYS */;
INSERT INTO `Provincia` VALUES (1,1,'Misiones','activo',NULL),(2,1,'Corrientes','activo',NULL);
/*!40000 ALTER TABLE `Provincia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Recargo`
--

DROP TABLE IF EXISTS `Recargo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Recargo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iva_id` int(11) DEFAULT NULL,
  `nombre` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `porcentaje` decimal(10,2) DEFAULT NULL,
  `importe` decimal(10,2) DEFAULT NULL,
  `tipoPorcentaje` tinyint(1) DEFAULT NULL,
  `tipoImporte` tinyint(1) DEFAULT NULL,
  `bonificacionImporte` decimal(10,2) DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ivaIncluido` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_8CD31965F231661A` (`iva_id`),
  CONSTRAINT `FK_8CD31965F231661A` FOREIGN KEY (`iva_id`) REFERENCES `iva` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Recargo`
--

LOCK TABLES `Recargo` WRITE;
/*!40000 ALTER TABLE `Recargo` DISABLE KEYS */;
/*!40000 ALTER TABLE `Recargo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Recibo`
--

DROP TABLE IF EXISTS `Recibo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Recibo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `serie` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `numero` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `unCobro_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_45052DCC81CC6317` (`unCobro_id`),
  KEY `IDX_45052DCCDB38439E` (`usuario_id`),
  KEY `IDX_45052DCCDE734E51` (`cliente_id`),
  CONSTRAINT `FK_45052DCC81CC6317` FOREIGN KEY (`unCobro_id`) REFERENCES `Cobro` (`id`),
  CONSTRAINT `FK_45052DCCDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`),
  CONSTRAINT `FK_45052DCCDE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Cliente` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Recibo`
--

LOCK TABLES `Recibo` WRITE;
/*!40000 ALTER TABLE `Recibo` DISABLE KEYS */;
/*!40000 ALTER TABLE `Recibo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Redireccion`
--

DROP TABLE IF EXISTS `Redireccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Redireccion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `parametros` longtext COLLATE utf8_unicode_ci COMMENT '(DC2Type:array)',
  `visto` tinyint(1) NOT NULL,
  `usuarioDe_id` int(11) DEFAULT NULL,
  `usuarioA_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_6916B006CAF6188C` (`usuarioDe_id`),
  KEY `IDX_6916B006AA3F0B0F` (`usuarioA_id`),
  CONSTRAINT `FK_6916B006AA3F0B0F` FOREIGN KEY (`usuarioA_id`) REFERENCES `Usuario` (`id`),
  CONSTRAINT `FK_6916B006CAF6188C` FOREIGN KEY (`usuarioDe_id`) REFERENCES `Usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Redireccion`
--

LOCK TABLES `Redireccion` WRITE;
/*!40000 ALTER TABLE `Redireccion` DISABLE KEYS */;
/*!40000 ALTER TABLE `Redireccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RegistroEnvio`
--

DROP TABLE IF EXISTS `RegistroEnvio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RegistroEnvio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empleado_id` int(11) DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `totalPedidos` decimal(10,2) DEFAULT NULL,
  `totalRendido` decimal(10,2) DEFAULT NULL,
  `numero` int(11) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `fechaRendicion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_938B809A952BE730` (`empleado_id`),
  CONSTRAINT `FK_938B809A952BE730` FOREIGN KEY (`empleado_id`) REFERENCES `persona_empleado` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RegistroEnvio`
--

LOCK TABLES `RegistroEnvio` WRITE;
/*!40000 ALTER TABLE `RegistroEnvio` DISABLE KEYS */;
/*!40000 ALTER TABLE `RegistroEnvio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Rol`
--

DROP TABLE IF EXISTS `Rol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Rol` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Rol`
--

LOCK TABLES `Rol` WRITE;
/*!40000 ALTER TABLE `Rol` DISABLE KEYS */;
INSERT INTO `Rol` VALUES (1,'Administrador',1);
/*!40000 ALTER TABLE `Rol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Salida`
--

DROP TABLE IF EXISTS `Salida`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Salida` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `caja_id` int(11) DEFAULT NULL,
  `pago_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_9258C27E63FB8380` (`pago_id`),
  KEY `IDX_9258C27EDB38439E` (`usuario_id`),
  KEY `IDX_9258C27E2D82B651` (`caja_id`),
  CONSTRAINT `FK_9258C27EBF396750` FOREIGN KEY (`id`) REFERENCES `Movimiento` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_9258C27E2D82B651` FOREIGN KEY (`caja_id`) REFERENCES `Caja` (`id`),
  CONSTRAINT `FK_9258C27E63FB8380` FOREIGN KEY (`pago_id`) REFERENCES `pago` (`id`),
  CONSTRAINT `FK_9258C27EDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Salida`
--

LOCK TABLES `Salida` WRITE;
/*!40000 ALTER TABLE `Salida` DISABLE KEYS */;
/*!40000 ALTER TABLE `Salida` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Sector`
--

DROP TABLE IF EXISTS `Sector`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Sector` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Sector`
--

LOCK TABLES `Sector` WRITE;
/*!40000 ALTER TABLE `Sector` DISABLE KEYS */;
/*!40000 ALTER TABLE `Sector` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Solicitud`
--

DROP TABLE IF EXISTS `Solicitud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Solicitud` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `encabezado` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `respuesta` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Solicitud`
--

LOCK TABLES `Solicitud` WRITE;
/*!40000 ALTER TABLE `Solicitud` DISABLE KEYS */;
/*!40000 ALTER TABLE `Solicitud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SueldoEmpleado`
--

DROP TABLE IF EXISTS `SueldoEmpleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SueldoEmpleado` (
  `id` int(11) NOT NULL,
  `inicio` date NOT NULL,
  `fin` date NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_D96EAFE3BF396750` FOREIGN KEY (`id`) REFERENCES `mov_empleado` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SueldoEmpleado`
--

LOCK TABLES `SueldoEmpleado` WRITE;
/*!40000 ALTER TABLE `SueldoEmpleado` DISABLE KEYS */;
/*!40000 ALTER TABLE `SueldoEmpleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tanda`
--

DROP TABLE IF EXISTS `Tanda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Tanda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cocina_id` int(11) DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_F14617372311565A` (`cocina_id`),
  CONSTRAINT `FK_F14617372311565A` FOREIGN KEY (`cocina_id`) REFERENCES `Cocina` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tanda`
--

LOCK TABLES `Tanda` WRITE;
/*!40000 ALTER TABLE `Tanda` DISABLE KEYS */;
/*!40000 ALTER TABLE `Tanda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Telefono`
--

DROP TABLE IF EXISTS `Telefono`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Telefono` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) DEFAULT NULL,
  `persona_id` int(11) DEFAULT NULL,
  `empleado_id` int(11) DEFAULT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `nacional` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `caracteristica` int(11) NOT NULL,
  `numero` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_38916829DE734E51` (`cliente_id`),
  KEY `IDX_38916829F5F88DB9` (`persona_id`),
  KEY `IDX_38916829952BE730` (`empleado_id`),
  KEY `IDX_38916829CB305D73` (`proveedor_id`),
  KEY `IDX_38916829521E1991` (`empresa_id`),
  CONSTRAINT `FK_38916829521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_38916829952BE730` FOREIGN KEY (`empleado_id`) REFERENCES `persona_empleado` (`id`),
  CONSTRAINT `FK_38916829CB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedor` (`id`),
  CONSTRAINT `FK_38916829DE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Cliente` (`id`),
  CONSTRAINT `FK_38916829F5F88DB9` FOREIGN KEY (`persona_id`) REFERENCES `Persona` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Telefono`
--

LOCK TABLES `Telefono` WRITE;
/*!40000 ALTER TABLE `Telefono` DISABLE KEYS */;
/*!40000 ALTER TABLE `Telefono` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TipoCobro`
--

DROP TABLE IF EXISTS `TipoCobro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TipoCobro` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `liquido` tinyint(1) DEFAULT NULL,
  `editable` tinyint(1) DEFAULT NULL,
  `darCambio` tinyint(1) DEFAULT NULL,
  `montoMinimo` decimal(10,2) DEFAULT NULL,
  `montoMaximo` decimal(10,2) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_E4986FDF521E1991` (`empresa_id`),
  CONSTRAINT `FK_E4986FDF521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TipoCobro`
--

LOCK TABLES `TipoCobro` WRITE;
/*!40000 ALTER TABLE `TipoCobro` DISABLE KEYS */;
INSERT INTO `TipoCobro` VALUES (1,1,'Efectivo registrable','Implica un movimiento en Caja',1,0,1,NULL,NULL,1),(2,1,'Efectivo no registrable','No implica un movimiento en caja',0,0,1,NULL,NULL,1),(3,1,'Tarjeta de Credito','Tarjeta de Credito',1,NULL,1,NULL,NULL,1);
/*!40000 ALTER TABLE `TipoCobro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TipoDocumento`
--

DROP TABLE IF EXISTS `TipoDocumento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TipoDocumento` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `abreviatura` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TipoDocumento`
--

LOCK TABLES `TipoDocumento` WRITE;
/*!40000 ALTER TABLE `TipoDocumento` DISABLE KEYS */;
INSERT INTO `TipoDocumento` VALUES (1,'Documento Nacional de Identidad','DNI','activo');
/*!40000 ALTER TABLE `TipoDocumento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TipoFactura`
--

DROP TABLE IF EXISTS `TipoFactura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TipoFactura` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nomenclatura` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `codigo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `discriminarIva` tinyint(1) DEFAULT NULL,
  `notaCreditoAnulacion` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TipoFactura`
--

LOCK TABLES `TipoFactura` WRITE;
/*!40000 ALTER TABLE `TipoFactura` DISABLE KEYS */;
INSERT INTO `TipoFactura` VALUES (1,'Factura A','Factura extendida por MONOTRIBUTISTA a RESPONSABLE INSCRIPTO, CONSUMIDOR FINAL, MONOTRIBUTISTA ó EXCENTO','A','001',NULL,NULL),(2,'Factura B',NULL,'B','006',NULL,NULL),(3,'Factura C',NULL,'C','011',NULL,NULL);
/*!40000 ALTER TABLE `TipoFactura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TipoOperacion`
--

DROP TABLE IF EXISTS `TipoOperacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TipoOperacion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TipoOperacion`
--

LOCK TABLES `TipoOperacion` WRITE;
/*!40000 ALTER TABLE `TipoOperacion` DISABLE KEYS */;
INSERT INTO `TipoOperacion` VALUES (1,'Venta','Operación que representa una venta por parte de la empresa a un cliente'),(2,'Compra','Operación que representa una compra por parte de la empresa a un proveedor');
/*!40000 ALTER TABLE `TipoOperacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TipoPedido`
--

DROP TABLE IF EXISTS `TipoPedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TipoPedido` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TipoPedido`
--

LOCK TABLES `TipoPedido` WRITE;
/*!40000 ALTER TABLE `TipoPedido` DISABLE KEYS */;
INSERT INTO `TipoPedido` VALUES (1,'mesa'),(2,'mostrador'),(3,'delivery');
/*!40000 ALTER TABLE `TipoPedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Usuario`
--

DROP TABLE IF EXISTS `Usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `apellido` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `salt` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `discr` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_EDD889C1D60322AC` (`role_id`),
  KEY `IDX_EDD889C1521E1991` (`empresa_id`),
  CONSTRAINT `FK_EDD889C1521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_EDD889C1D60322AC` FOREIGN KEY (`role_id`) REFERENCES `Rol` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Usuario`
--

LOCK TABLES `Usuario` WRITE;
/*!40000 ALTER TABLE `Usuario` DISABLE KEYS */;
INSERT INTO `Usuario` VALUES (1,1,NULL,'Example','Example','example@example.com','admin','7ba896180ccd282d635e5cf25062a165','a67d9aeb02267a90d82bb92a9c1ed44c0e110f0e',1,'usuario');
/*!40000 ALTER TABLE `Usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Valor`
--

DROP TABLE IF EXISTS `Valor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Valor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campo_id` int(11) DEFAULT NULL,
  `cobro_id` int(11) DEFAULT NULL,
  `pago_id` int(11) DEFAULT NULL,
  `valor` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_EF48082CA17A385C` (`campo_id`),
  KEY `IDX_EF48082C7AD3A2B4` (`cobro_id`),
  KEY `IDX_EF48082C63FB8380` (`pago_id`),
  CONSTRAINT `FK_EF48082C63FB8380` FOREIGN KEY (`pago_id`) REFERENCES `pago` (`id`),
  CONSTRAINT `FK_EF48082C7AD3A2B4` FOREIGN KEY (`cobro_id`) REFERENCES `Cobro` (`id`),
  CONSTRAINT `FK_EF48082CA17A385C` FOREIGN KEY (`campo_id`) REFERENCES `Campo` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Valor`
--

LOCK TABLES `Valor` WRITE;
/*!40000 ALTER TABLE `Valor` DISABLE KEYS */;
/*!40000 ALTER TABLE `Valor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Venta`
--

DROP TABLE IF EXISTS `Venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Venta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `pedido_id` int(11) DEFAULT NULL,
  `operacion_id` int(11) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cuit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `cambio` decimal(10,2) DEFAULT NULL,
  `serie` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `numero` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `condicionIva_id` int(11) DEFAULT NULL,
  `condicionIvaEmpresa_id` int(11) DEFAULT NULL,
  `tipoOperacion_id` int(11) DEFAULT NULL,
  `tipoFactura_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_4E26C1514854653A` (`pedido_id`),
  KEY `IDX_4E26C151DB38439E` (`usuario_id`),
  KEY `IDX_4E26C151DE734E51` (`cliente_id`),
  KEY `IDX_4E26C151F60CF12A` (`condicionIva_id`),
  KEY `IDX_4E26C1515C25E126` (`condicionIvaEmpresa_id`),
  KEY `IDX_4E26C151957DD03D` (`tipoOperacion_id`),
  KEY `IDX_4E26C151E6D597C3` (`operacion_id`),
  KEY `IDX_4E26C15110E064DC` (`tipoFactura_id`),
  CONSTRAINT `FK_4E26C15110E064DC` FOREIGN KEY (`tipoFactura_id`) REFERENCES `TipoFactura` (`id`),
  CONSTRAINT `FK_4E26C1514854653A` FOREIGN KEY (`pedido_id`) REFERENCES `Pedido` (`id`),
  CONSTRAINT `FK_4E26C1515C25E126` FOREIGN KEY (`condicionIvaEmpresa_id`) REFERENCES `CondicionIva` (`id`),
  CONSTRAINT `FK_4E26C151957DD03D` FOREIGN KEY (`tipoOperacion_id`) REFERENCES `TipoOperacion` (`id`),
  CONSTRAINT `FK_4E26C151DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`),
  CONSTRAINT `FK_4E26C151DE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Cliente` (`id`),
  CONSTRAINT `FK_4E26C151E6D597C3` FOREIGN KEY (`operacion_id`) REFERENCES `Operacion` (`id`),
  CONSTRAINT `FK_4E26C151F60CF12A` FOREIGN KEY (`condicionIva_id`) REFERENCES `CondicionIva` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Venta`
--

LOCK TABLES `Venta` WRITE;
/*!40000 ALTER TABLE `Venta` DISABLE KEYS */;
/*!40000 ALTER TABLE `Venta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente_descuentocliente`
--

DROP TABLE IF EXISTS `cliente_descuentocliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente_descuentocliente` (
  `cliente_id` int(11) NOT NULL,
  `descuentocliente_id` int(11) NOT NULL,
  PRIMARY KEY (`cliente_id`,`descuentocliente_id`),
  KEY `IDX_281F7BF9DE734E51` (`cliente_id`),
  KEY `IDX_281F7BF96C53F65B` (`descuentocliente_id`),
  CONSTRAINT `FK_281F7BF96C53F65B` FOREIGN KEY (`descuentocliente_id`) REFERENCES `DescuentoCliente` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_281F7BF9DE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Cliente` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente_descuentocliente`
--

LOCK TABLES `cliente_descuentocliente` WRITE;
/*!40000 ALTER TABLE `cliente_descuentocliente` DISABLE KEYS */;
/*!40000 ALTER TABLE `cliente_descuentocliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compra`
--

DROP TABLE IF EXISTS `compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `compra` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proveedor_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `fechaFactura` date DEFAULT NULL,
  `fechaEmision` datetime NOT NULL,
  `estado` tinyint(1) DEFAULT NULL,
  `total` decimal(10,3) DEFAULT NULL,
  `subTotal` decimal(10,3) DEFAULT NULL,
  `descuento` decimal(10,3) DEFAULT NULL,
  `otrosImp` decimal(10,3) DEFAULT NULL,
  `tipo` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `serie` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `numero` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `notaPedido_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9EC131FFCB305D73` (`proveedor_id`),
  KEY `IDX_9EC131FFFDD5DE1D` (`notaPedido_id`),
  KEY `IDX_9EC131FF521E1991` (`empresa_id`),
  CONSTRAINT `FK_9EC131FF521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_9EC131FFCB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedor` (`id`),
  CONSTRAINT `FK_9EC131FFFDD5DE1D` FOREIGN KEY (`notaPedido_id`) REFERENCES `nota_pedido` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compra`
--

LOCK TABLES `compra` WRITE;
/*!40000 ALTER TABLE `compra` DISABLE KEYS */;
/*!40000 ALTER TABLE `compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cuenta_empleado`
--

DROP TABLE IF EXISTS `cuenta_empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cuenta_empleado` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ultimoLote` date DEFAULT NULL,
  `pendiente` tinyint(1) DEFAULT NULL,
  `saldo` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cuenta_empleado`
--

LOCK TABLES `cuenta_empleado` WRITE;
/*!40000 ALTER TABLE `cuenta_empleado` DISABLE KEYS */;
/*!40000 ALTER TABLE `cuenta_empleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cuit`
--

DROP TABLE IF EXISTS `cuit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cuit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipoglobal` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `numero` int(11) NOT NULL,
  `verificador` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cuit`
--

LOCK TABLES `cuit` WRITE;
/*!40000 ALTER TABLE `cuit` DISABLE KEYS */;
/*!40000 ALTER TABLE `cuit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `descuentoproductoventa_categoriaproductoventa`
--

DROP TABLE IF EXISTS `descuentoproductoventa_categoriaproductoventa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `descuentoproductoventa_categoriaproductoventa` (
  `descuentoproductoventa_id` int(11) NOT NULL,
  `categoriaproductoventa_id` int(11) NOT NULL,
  PRIMARY KEY (`descuentoproductoventa_id`,`categoriaproductoventa_id`),
  KEY `IDX_5F3A2E1AF0E0CFEB` (`descuentoproductoventa_id`),
  KEY `IDX_5F3A2E1AC46C9C95` (`categoriaproductoventa_id`),
  CONSTRAINT `FK_5F3A2E1AC46C9C95` FOREIGN KEY (`categoriaproductoventa_id`) REFERENCES `CategoriaProductoVenta` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_5F3A2E1AF0E0CFEB` FOREIGN KEY (`descuentoproductoventa_id`) REFERENCES `DescuentoProductoVenta` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `descuentoproductoventa_categoriaproductoventa`
--

LOCK TABLES `descuentoproductoventa_categoriaproductoventa` WRITE;
/*!40000 ALTER TABLE `descuentoproductoventa_categoriaproductoventa` DISABLE KEYS */;
/*!40000 ALTER TABLE `descuentoproductoventa_categoriaproductoventa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `descuentoproductoventa_productoventa`
--

DROP TABLE IF EXISTS `descuentoproductoventa_productoventa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `descuentoproductoventa_productoventa` (
  `descuentoproductoventa_id` int(11) NOT NULL,
  `productoventa_id` int(11) NOT NULL,
  PRIMARY KEY (`descuentoproductoventa_id`,`productoventa_id`),
  KEY `IDX_A4FD0665F0E0CFEB` (`descuentoproductoventa_id`),
  KEY `IDX_A4FD066517242A18` (`productoventa_id`),
  CONSTRAINT `FK_A4FD066517242A18` FOREIGN KEY (`productoventa_id`) REFERENCES `ProductoVenta` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_A4FD0665F0E0CFEB` FOREIGN KEY (`descuentoproductoventa_id`) REFERENCES `DescuentoProductoVenta` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `descuentoproductoventa_productoventa`
--

LOCK TABLES `descuentoproductoventa_productoventa` WRITE;
/*!40000 ALTER TABLE `descuentoproductoventa_productoventa` DISABLE KEYS */;
/*!40000 ALTER TABLE `descuentoproductoventa_productoventa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ext_log_entries`
--

DROP TABLE IF EXISTS `ext_log_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ext_log_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `logged_at` datetime NOT NULL,
  `object_id` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `object_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `version` int(11) NOT NULL,
  `data` longtext COLLATE utf8_unicode_ci COMMENT '(DC2Type:array)',
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `log_class_lookup_idx` (`object_class`),
  KEY `log_date_lookup_idx` (`logged_at`),
  KEY `log_user_lookup_idx` (`username`),
  KEY `log_version_lookup_idx` (`object_id`,`object_class`,`version`)
) ENGINE=InnoDB AUTO_INCREMENT=220 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ext_log_entries`
--

LOCK TABLES `ext_log_entries` WRITE;
/*!40000 ALTER TABLE `ext_log_entries` DISABLE KEYS */;
INSERT INTO `ext_log_entries` VALUES (1,'create','2013-12-02 09:00:21','1','SisGG\\FinalBundle\\Entity\\CondicionIva',1,'N;',NULL),(2,'create','2013-12-02 09:00:21','2','SisGG\\FinalBundle\\Entity\\CondicionIva',1,'N;',NULL),(3,'create','2013-12-02 09:00:21','3','SisGG\\FinalBundle\\Entity\\CondicionIva',1,'N;',NULL),(4,'create','2013-12-02 09:00:21','4','SisGG\\FinalBundle\\Entity\\CondicionIva',1,'N;',NULL),(5,'create','2013-12-02 09:00:21','1','SisGG\\FinalBundle\\Entity\\Provincia',1,'N;',NULL),(6,'create','2013-12-02 09:00:21','1','SisGG\\FinalBundle\\Entity\\Empresa',1,'a:13:{s:6:\"nombre\";s:7:\"Example\";s:6:\"slogan\";s:55:\"Tu alegria a la hora de comer es la sonrisa de un niño\";s:11:\"responsable\";N;s:4:\"edad\";N;s:5:\"email\";N;s:11:\"contrasenia\";N;s:11:\"descripcion\";s:38:\"Empresa dedicada a la venta de comidas\";s:4:\"cuit\";s:13:\"20-20202020-2\";s:2:\"ip\";N;s:9:\"inicioAct\";N;s:7:\"carpeta\";N;s:16:\"carpetaAuditoria\";N;s:9:\"direccion\";a:1:{s:2:\"id\";i:1;}}',NULL),(7,'create','2013-12-02 09:00:21','1','SisGG\\FinalBundle\\Entity\\Usuario',1,'a:8:{s:8:\"apellido\";s:7:\"Example\";s:6:\"nombre\";s:7:\"Example\";s:5:\"email\";s:19:\"example@example.com\";s:8:\"username\";s:5:\"admin\";s:4:\"salt\";s:32:\"7ba896180ccd282d635e5cf25062a165\";s:8:\"password\";s:40:\"a67d9aeb02267a90d82bb92a9c1ed44c0e110f0e\";s:8:\"isActive\";b:1;s:4:\"role\";a:1:{s:2:\"id\";i:1;}}',NULL),(8,'create','2013-12-02 09:00:21','1','SisGG\\FinalBundle\\Entity\\IVA',1,'N;',NULL),(9,'create','2013-12-02 09:00:21','1','SisGG\\FinalBundle\\Entity\\Direccion',1,'a:8:{s:5:\"calle\";s:16:\"Av. Siempre Viva\";s:6:\"numero\";i:123;s:7:\"manzana\";N;s:8:\"edificio\";N;s:8:\"escalera\";N;s:4:\"piso\";N;s:12:\"departamento\";N;s:6:\"ciudad\";a:1:{s:2:\"id\";i:1;}}',NULL),(10,'create','2013-12-02 09:00:21','1','SisGG\\FinalBundle\\Entity\\Rol',1,'a:2:{s:4:\"role\";s:13:\"Administrador\";s:6:\"activo\";i:1;}',NULL),(11,'create','2013-12-02 09:00:21','1','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(12,'create','2013-12-02 09:00:21','2','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(13,'create','2013-12-02 09:00:21','3','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(14,'create','2013-12-02 09:00:21','4','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(15,'create','2013-12-02 09:00:21','5','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(16,'create','2013-12-02 09:00:21','6','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(17,'create','2013-12-02 09:00:21','7','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(18,'create','2013-12-02 09:00:21','8','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(19,'create','2013-12-02 09:00:21','9','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(20,'create','2013-12-02 09:00:21','10','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(21,'create','2013-12-02 09:00:21','11','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(22,'create','2013-12-02 09:00:21','12','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(23,'create','2013-12-02 09:00:21','13','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(24,'create','2013-12-02 09:00:21','14','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(25,'create','2013-12-02 09:00:21','15','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(26,'create','2013-12-02 09:00:21','16','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(27,'create','2013-12-02 09:00:21','17','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(28,'create','2013-12-02 09:00:21','18','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(29,'create','2013-12-02 09:00:21','19','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(30,'create','2013-12-02 09:00:21','20','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(31,'create','2013-12-02 09:00:21','21','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(32,'create','2013-12-02 09:00:21','22','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(33,'create','2013-12-02 09:00:21','23','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(34,'create','2013-12-02 09:00:21','24','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(35,'create','2013-12-02 09:00:21','25','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(36,'create','2013-12-02 09:00:21','26','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(37,'create','2013-12-02 09:00:21','27','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(38,'create','2013-12-02 09:00:21','28','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(39,'create','2013-12-02 09:00:21','29','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(40,'create','2013-12-02 09:00:21','30','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(41,'create','2013-12-02 09:00:21','31','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(42,'create','2013-12-02 09:00:21','32','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(43,'create','2013-12-02 09:00:21','33','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(44,'create','2013-12-02 09:00:21','34','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(45,'create','2013-12-02 09:00:21','35','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(46,'create','2013-12-02 09:00:21','36','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(47,'create','2013-12-02 09:00:21','37','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(48,'create','2013-12-02 09:00:21','38','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(49,'create','2013-12-02 09:00:21','39','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(50,'create','2013-12-02 09:00:21','40','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(51,'create','2013-12-02 09:00:21','41','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(52,'create','2013-12-02 09:00:21','42','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(53,'create','2013-12-02 09:00:21','43','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(54,'create','2013-12-02 09:00:21','44','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(55,'create','2013-12-02 09:00:21','45','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(56,'create','2013-12-02 09:00:21','46','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(57,'create','2013-12-02 09:00:21','47','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(58,'create','2013-12-02 09:00:21','48','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(59,'create','2013-12-02 09:00:21','49','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(60,'create','2013-12-02 09:00:21','50','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(61,'create','2013-12-02 09:00:21','51','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(62,'create','2013-12-02 09:00:21','52','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(63,'create','2013-12-02 09:00:21','53','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(64,'create','2013-12-02 09:00:21','54','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(65,'create','2013-12-02 09:00:21','55','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(66,'create','2013-12-02 09:00:21','56','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(67,'create','2013-12-02 09:00:21','57','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(68,'create','2013-12-02 09:00:21','58','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(69,'create','2013-12-02 09:00:21','59','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(70,'create','2013-12-02 09:00:21','60','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(71,'create','2013-12-02 09:00:21','61','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(72,'create','2013-12-02 09:00:21','62','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(73,'create','2013-12-02 09:00:21','63','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(74,'create','2013-12-02 09:00:21','64','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(75,'create','2013-12-02 09:00:21','65','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(76,'create','2013-12-02 09:00:21','66','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(77,'create','2013-12-02 09:00:21','67','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(78,'create','2013-12-02 09:00:21','68','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(79,'create','2013-12-02 09:00:21','69','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(80,'create','2013-12-02 09:00:21','70','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(81,'create','2013-12-02 09:00:21','71','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(82,'create','2013-12-02 09:00:21','72','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(83,'create','2013-12-02 09:00:21','73','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(84,'create','2013-12-02 09:00:21','74','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(85,'create','2013-12-02 09:00:21','75','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(86,'create','2013-12-02 09:00:21','76','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(87,'create','2013-12-02 09:00:21','77','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(88,'create','2013-12-02 09:00:21','78','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(89,'create','2013-12-02 09:00:21','79','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(90,'create','2013-12-02 09:00:21','80','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(91,'create','2013-12-02 09:00:21','81','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(92,'create','2013-12-02 09:00:21','82','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(93,'create','2013-12-02 09:00:21','83','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(94,'create','2013-12-02 09:00:21','84','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(95,'create','2013-12-02 09:00:21','85','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(96,'create','2013-12-02 09:00:21','86','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(97,'create','2013-12-02 09:00:21','87','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(98,'create','2013-12-02 09:00:21','88','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(99,'create','2013-12-02 09:00:21','89','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(100,'create','2013-12-02 09:00:21','90','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(101,'create','2013-12-02 09:00:21','91','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(102,'create','2013-12-02 09:00:21','92','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(103,'create','2013-12-02 09:00:21','93','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(104,'create','2013-12-02 09:00:21','94','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(105,'create','2013-12-02 09:00:21','95','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(106,'create','2013-12-02 09:00:21','96','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(107,'create','2013-12-02 09:00:21','97','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(108,'create','2013-12-02 09:00:21','98','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(109,'create','2013-12-02 09:00:21','99','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(110,'create','2013-12-02 09:00:21','100','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(111,'create','2013-12-02 09:00:21','101','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(112,'create','2013-12-02 09:00:21','102','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(113,'create','2013-12-02 09:00:21','103','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(114,'create','2013-12-02 09:00:21','104','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(115,'create','2013-12-02 09:00:21','105','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(116,'create','2013-12-02 09:00:21','106','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(117,'create','2013-12-02 09:00:21','107','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(118,'create','2013-12-02 09:00:21','108','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(119,'create','2013-12-02 09:00:21','109','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(120,'create','2013-12-02 09:00:21','110','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(121,'create','2013-12-02 09:00:21','111','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(122,'create','2013-12-02 09:00:21','112','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(123,'create','2013-12-02 09:00:21','113','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(124,'create','2013-12-02 09:00:21','114','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(125,'create','2013-12-02 09:00:21','115','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(126,'create','2013-12-02 09:00:21','116','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(127,'create','2013-12-02 09:00:21','117','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(128,'create','2013-12-02 09:00:21','118','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(129,'create','2013-12-02 09:00:21','119','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(130,'create','2013-12-02 09:00:21','120','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(131,'create','2013-12-02 09:00:21','121','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(132,'create','2013-12-02 09:00:21','122','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(133,'create','2013-12-02 09:00:21','123','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(134,'create','2013-12-02 09:00:21','124','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(135,'create','2013-12-02 09:00:21','125','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(136,'create','2013-12-02 09:00:21','126','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(137,'create','2013-12-02 09:00:21','127','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(138,'create','2013-12-02 09:00:21','128','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(139,'create','2013-12-02 09:00:21','129','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(140,'create','2013-12-02 09:00:21','130','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(141,'create','2013-12-02 09:00:21','131','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(142,'create','2013-12-02 09:00:21','132','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(143,'create','2013-12-02 09:00:21','133','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(144,'create','2013-12-02 09:00:21','134','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(145,'create','2013-12-02 09:00:21','135','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(146,'create','2013-12-02 09:00:21','136','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(147,'create','2013-12-02 09:00:21','137','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(148,'create','2013-12-02 09:00:21','138','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(149,'create','2013-12-02 09:00:21','139','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(150,'create','2013-12-02 09:00:21','140','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(151,'create','2013-12-02 09:00:21','141','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(152,'create','2013-12-02 09:00:21','142','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(153,'create','2013-12-02 09:00:21','143','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(154,'create','2013-12-02 09:00:21','144','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(155,'create','2013-12-02 09:00:21','145','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(156,'create','2013-12-02 09:00:21','146','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(157,'create','2013-12-02 09:00:21','147','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(158,'create','2013-12-02 09:00:21','148','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(159,'create','2013-12-02 09:00:21','149','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(160,'create','2013-12-02 09:00:21','150','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(161,'create','2013-12-02 09:00:21','151','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(162,'create','2013-12-02 09:00:21','152','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(163,'create','2013-12-02 09:00:21','153','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(164,'create','2013-12-02 09:00:21','154','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(165,'create','2013-12-02 09:00:21','155','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(166,'create','2013-12-02 09:00:21','156','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(167,'create','2013-12-02 09:00:21','157','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(168,'create','2013-12-02 09:00:21','158','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(169,'create','2013-12-02 09:00:21','159','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(170,'create','2013-12-02 09:00:21','160','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(171,'create','2013-12-02 09:00:21','161','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(172,'create','2013-12-02 09:00:21','162','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(173,'create','2013-12-02 09:00:21','163','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(174,'create','2013-12-02 09:00:21','164','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(175,'create','2013-12-02 09:00:21','165','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(176,'create','2013-12-02 09:00:21','166','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(177,'create','2013-12-02 09:00:21','167','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(178,'create','2013-12-02 09:00:21','168','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(179,'create','2013-12-02 09:00:21','169','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(180,'create','2013-12-02 09:00:21','170','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(181,'create','2013-12-02 09:00:21','171','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(182,'create','2013-12-02 09:00:21','172','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(183,'create','2013-12-02 09:00:21','173','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(184,'create','2013-12-02 09:00:21','174','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(185,'create','2013-12-02 09:00:21','175','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(186,'create','2013-12-02 09:00:21','176','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(187,'create','2013-12-02 09:00:21','177','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(188,'create','2013-12-02 09:00:21','178','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(189,'create','2013-12-02 09:00:21','179','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(190,'create','2013-12-02 09:00:21','180','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(191,'create','2013-12-02 09:00:21','181','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(192,'create','2013-12-02 09:00:21','182','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(193,'create','2013-12-02 09:00:21','183','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(194,'create','2013-12-02 09:00:21','184','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(195,'create','2013-12-02 09:00:22','1','SisGG\\FinalBundle\\Entity\\Concepto',1,'a:2:{s:6:\"nombre\";s:15:\"Pago por compra\";s:11:\"descripcion\";s:34:\"Pago de una compra a un proveedor.\";}',NULL),(196,'create','2013-12-02 09:00:22','2','SisGG\\FinalBundle\\Entity\\Concepto',1,'a:2:{s:6:\"nombre\";s:15:\"Cobro por venta\";s:11:\"descripcion\";s:32:\"Cobro de una venta a un cliente.\";}',NULL),(197,'create','2013-12-02 09:00:22','3','SisGG\\FinalBundle\\Entity\\Concepto',1,'a:2:{s:6:\"nombre\";s:18:\"Pago a un empleado\";s:11:\"descripcion\";s:32:\"Pago a un empleado por servicio.\";}',NULL),(198,'create','2013-12-02 09:00:22','1','SisGG\\FinalBundle\\Entity\\TipoCobro',1,'N;',NULL),(199,'create','2013-12-02 09:00:22','2','SisGG\\FinalBundle\\Entity\\TipoCobro',1,'N;',NULL),(200,'create','2013-12-02 09:00:22','3','SisGG\\FinalBundle\\Entity\\TipoCobro',1,'N;',NULL),(201,'create','2013-12-02 09:00:22','1','SisGG\\FinalBundle\\Entity\\Campo',1,'a:7:{s:6:\"nombre\";s:21:\"Numero de Comprobante\";s:9:\"requerido\";b:1;s:5:\"unico\";N;s:8:\"tipoDato\";s:4:\"text\";s:6:\"patron\";s:8:\"[0-9]{4}\";s:7:\"ejemplo\";s:4:\"0001\";s:9:\"tipoCobro\";a:1:{s:2:\"id\";i:3;}}',NULL),(202,'create','2013-12-02 09:00:22','1','SisGG\\FinalBundle\\Entity\\TipoPedido',1,'a:1:{s:6:\"nombre\";s:4:\"mesa\";}',NULL),(203,'create','2013-12-02 09:00:22','2','SisGG\\FinalBundle\\Entity\\TipoPedido',1,'a:1:{s:6:\"nombre\";s:9:\"mostrador\";}',NULL),(204,'create','2013-12-02 09:00:22','3','SisGG\\FinalBundle\\Entity\\TipoPedido',1,'a:1:{s:6:\"nombre\";s:8:\"delivery\";}',NULL),(205,'create','2013-12-02 09:00:22','1','SisGG\\FinalBundle\\Entity\\TipoFactura',1,'a:6:{s:6:\"nombre\";s:9:\"Factura A\";s:11:\"descripcion\";s:105:\"Factura extendida por MONOTRIBUTISTA a RESPONSABLE INSCRIPTO, CONSUMIDOR FINAL, MONOTRIBUTISTA ó EXCENTO\";s:12:\"nomenclatura\";s:1:\"A\";s:6:\"codigo\";s:3:\"001\";s:14:\"discriminarIva\";N;s:20:\"notaCreditoAnulacion\";N;}',NULL),(206,'create','2013-12-02 09:00:22','2','SisGG\\FinalBundle\\Entity\\TipoFactura',1,'a:6:{s:6:\"nombre\";s:9:\"Factura B\";s:11:\"descripcion\";N;s:12:\"nomenclatura\";s:1:\"B\";s:6:\"codigo\";s:3:\"006\";s:14:\"discriminarIva\";N;s:20:\"notaCreditoAnulacion\";N;}',NULL),(207,'create','2013-12-02 09:00:22','3','SisGG\\FinalBundle\\Entity\\TipoFactura',1,'a:6:{s:6:\"nombre\";s:9:\"Factura C\";s:11:\"descripcion\";N;s:12:\"nomenclatura\";s:1:\"C\";s:6:\"codigo\";s:3:\"011\";s:14:\"discriminarIva\";N;s:20:\"notaCreditoAnulacion\";N;}',NULL),(208,'create','2013-12-02 09:00:22','1','SisGG\\FinalBundle\\Entity\\TipoOperacion',1,'a:2:{s:6:\"nombre\";s:5:\"Venta\";s:11:\"descripcion\";s:72:\"Operación que representa una venta por parte de la empresa a un cliente\";}',NULL),(209,'create','2013-12-02 09:00:22','2','SisGG\\FinalBundle\\Entity\\TipoOperacion',1,'a:2:{s:6:\"nombre\";s:6:\"Compra\";s:11:\"descripcion\";s:75:\"Operación que representa una compra por parte de la empresa a un proveedor\";}',NULL),(210,'create','2013-12-02 09:00:22','1','SisGG\\FinalBundle\\Entity\\Caja',1,'a:18:{s:11:\"puntoVentaA\";N;s:14:\"ultimaFacturaA\";N;s:11:\"puntoVentaB\";N;s:14:\"ultimaFacturaB\";N;s:11:\"puntoVentaC\";N;s:14:\"ultimaFacturaC\";N;s:17:\"serieNotaCreditoA\";N;s:24:\"ultimoNumeroNotaCreditoA\";N;s:17:\"serieNotaCreditoB\";N;s:24:\"ultimoNumeroNotaCreditoB\";N;s:17:\"serieNotaCreditoC\";N;s:24:\"ultimoNumeroNotaCreditoC\";N;s:11:\"serieRecibo\";N;s:18:\"ultimoNumeroRecibo\";N;s:14:\"minimoApertura\";N;s:7:\"abierta\";b:0;s:5:\"saldo\";N;s:7:\"empresa\";N;}',NULL),(211,'create','2013-12-02 09:00:22','4','SisGG\\FinalBundle\\Entity\\Concepto',1,'a:2:{s:6:\"nombre\";s:15:\"Cobro por Venta\";s:11:\"descripcion\";s:15:\"Cobro por Venta\";}',NULL),(212,'create','2013-12-02 09:00:22','1','SisGG\\FinalBundle\\Entity\\TipoDocumento',1,'a:3:{s:6:\"nombre\";s:31:\"Documento Nacional de Identidad\";s:11:\"abreviatura\";s:3:\"DNI\";s:6:\"estado\";s:6:\"activo\";}',NULL),(213,'create','2013-12-02 09:19:12','2','SisGG\\FinalBundle\\Entity\\Direccion',1,'a:8:{s:5:\"calle\";s:16:\"Primeros Colonos\";s:6:\"numero\";s:4:\"2013\";s:7:\"manzana\";N;s:8:\"edificio\";N;s:8:\"escalera\";N;s:4:\"piso\";N;s:12:\"departamento\";N;s:6:\"ciudad\";a:1:{s:2:\"id\";i:5;}}','admin'),(214,'create','2013-12-02 09:20:32','3','SisGG\\FinalBundle\\Entity\\Direccion',1,'a:8:{s:5:\"calle\";s:9:\"Ciudadela\";s:6:\"numero\";s:4:\"3520\";s:7:\"manzana\";N;s:8:\"edificio\";N;s:8:\"escalera\";N;s:4:\"piso\";N;s:12:\"departamento\";N;s:6:\"ciudad\";a:1:{s:2:\"id\";i:4;}}','admin'),(215,'create','2013-12-02 09:21:29','4','SisGG\\FinalBundle\\Entity\\Direccion',1,'a:8:{s:5:\"calle\";s:7:\"Formosa\";s:6:\"numero\";s:4:\"2381\";s:7:\"manzana\";N;s:8:\"edificio\";N;s:8:\"escalera\";N;s:4:\"piso\";N;s:12:\"departamento\";N;s:6:\"ciudad\";a:1:{s:2:\"id\";i:2;}}','admin'),(216,'create','2013-12-02 09:22:19','5','SisGG\\FinalBundle\\Entity\\Direccion',1,'a:8:{s:5:\"calle\";s:11:\"Av. Lavalle\";s:6:\"numero\";s:4:\"3526\";s:7:\"manzana\";N;s:8:\"edificio\";N;s:8:\"escalera\";N;s:4:\"piso\";N;s:12:\"departamento\";N;s:6:\"ciudad\";a:1:{s:2:\"id\";i:1;}}','admin'),(217,'create','2013-12-02 09:23:05','6','SisGG\\FinalBundle\\Entity\\Direccion',1,'a:8:{s:5:\"calle\";s:14:\"Islas Malvinas\";s:6:\"numero\";s:3:\"584\";s:7:\"manzana\";N;s:8:\"edificio\";N;s:8:\"escalera\";N;s:4:\"piso\";N;s:12:\"departamento\";N;s:6:\"ciudad\";a:1:{s:2:\"id\";i:5;}}','admin'),(218,'create','2013-12-02 09:23:45','7','SisGG\\FinalBundle\\Entity\\Direccion',1,'a:8:{s:5:\"calle\";s:10:\"San Martin\";s:6:\"numero\";s:4:\"1514\";s:7:\"manzana\";N;s:8:\"edificio\";N;s:8:\"escalera\";N;s:4:\"piso\";N;s:12:\"departamento\";N;s:6:\"ciudad\";a:1:{s:2:\"id\";i:4;}}','admin'),(219,'update','2013-12-02 09:36:16','1','SisGG\\FinalBundle\\Entity\\Empresa',2,'a:1:{s:7:\"carpeta\";s:13:\"/var/backups/\";}','admin');
/*!40000 ALTER TABLE `ext_log_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ext_translations`
--

DROP TABLE IF EXISTS `ext_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ext_translations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `locale` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `object_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `field` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `foreign_key` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lookup_unique_idx` (`locale`,`object_class`,`field`,`foreign_key`),
  KEY `translations_lookup_idx` (`locale`,`object_class`,`foreign_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ext_translations`
--

LOCK TABLES `ext_translations` WRITE;
/*!40000 ALTER TABLE `ext_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `ext_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factura_servicio`
--

DROP TABLE IF EXISTS `factura_servicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factura_servicio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `servicio_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `fechaFactura` date DEFAULT NULL,
  `periodo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaEmision` datetime NOT NULL,
  `total` decimal(10,3) DEFAULT NULL,
  `serie` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `numero` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D0925CA171CAA3E7` (`servicio_id`),
  KEY `IDX_D0925CA1521E1991` (`empresa_id`),
  CONSTRAINT `FK_D0925CA1521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_D0925CA171CAA3E7` FOREIGN KEY (`servicio_id`) REFERENCES `servicio` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura_servicio`
--

LOCK TABLES `factura_servicio` WRITE;
/*!40000 ALTER TABLE `factura_servicio` DISABLE KEYS */;
/*!40000 ALTER TABLE `factura_servicio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fondo`
--

DROP TABLE IF EXISTS `fondo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fondo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_2DC0A6E53DA5256D` (`image_id`),
  CONSTRAINT `FK_2DC0A6E53DA5256D` FOREIGN KEY (`image_id`) REFERENCES `Image` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fondo`
--

LOCK TABLES `fondo` WRITE;
/*!40000 ALTER TABLE `fondo` DISABLE KEYS */;
/*!40000 ALTER TABLE `fondo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grupocliente_cliente`
--

DROP TABLE IF EXISTS `grupocliente_cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grupocliente_cliente` (
  `grupocliente_id` int(11) NOT NULL,
  `cliente_id` int(11) NOT NULL,
  PRIMARY KEY (`grupocliente_id`,`cliente_id`),
  KEY `IDX_F11CB89378A9344C` (`grupocliente_id`),
  KEY `IDX_F11CB893DE734E51` (`cliente_id`),
  CONSTRAINT `FK_F11CB893DE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Cliente` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_F11CB89378A9344C` FOREIGN KEY (`grupocliente_id`) REFERENCES `GrupoCliente` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grupocliente_cliente`
--

LOCK TABLES `grupocliente_cliente` WRITE;
/*!40000 ALTER TABLE `grupocliente_cliente` DISABLE KEYS */;
/*!40000 ALTER TABLE `grupocliente_cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grupocliente_descuentocliente`
--

DROP TABLE IF EXISTS `grupocliente_descuentocliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grupocliente_descuentocliente` (
  `grupocliente_id` int(11) NOT NULL,
  `descuentocliente_id` int(11) NOT NULL,
  PRIMARY KEY (`grupocliente_id`,`descuentocliente_id`),
  KEY `IDX_D6BF80EA78A9344C` (`grupocliente_id`),
  KEY `IDX_D6BF80EA6C53F65B` (`descuentocliente_id`),
  CONSTRAINT `FK_D6BF80EA6C53F65B` FOREIGN KEY (`descuentocliente_id`) REFERENCES `DescuentoCliente` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_D6BF80EA78A9344C` FOREIGN KEY (`grupocliente_id`) REFERENCES `GrupoCliente` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grupocliente_descuentocliente`
--

LOCK TABLES `grupocliente_descuentocliente` WRITE;
/*!40000 ALTER TABLE `grupocliente_descuentocliente` DISABLE KEYS */;
/*!40000 ALTER TABLE `grupocliente_descuentocliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `itemRegistroProduccion`
--

DROP TABLE IF EXISTS `itemRegistroProduccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `itemRegistroProduccion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `producto` int(11) DEFAULT NULL,
  `tasa_id` int(11) DEFAULT NULL,
  `cantidad` decimal(10,2) DEFAULT NULL,
  `utilizado` tinyint(1) NOT NULL,
  `costo` decimal(10,2) DEFAULT NULL,
  `registroProduccion` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_95218525A7BB0615` (`producto`),
  KEY `IDX_95218525E20BE1E2` (`tasa_id`),
  KEY `IDX_9521852589F2E403` (`registroProduccion`),
  CONSTRAINT `FK_9521852589F2E403` FOREIGN KEY (`registroProduccion`) REFERENCES `registroProduccion` (`id`),
  CONSTRAINT `FK_95218525A7BB0615` FOREIGN KEY (`producto`) REFERENCES `ProductoProduccion` (`id`),
  CONSTRAINT `FK_95218525E20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `itemRegistroProduccion`
--

LOCK TABLES `itemRegistroProduccion` WRITE;
/*!40000 ALTER TABLE `itemRegistroProduccion` DISABLE KEYS */;
/*!40000 ALTER TABLE `itemRegistroProduccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_LIC`
--

DROP TABLE IF EXISTS `item_LIC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_LIC` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lic` int(11) DEFAULT NULL,
  `tasa` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `gravado` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_AFBA32E2DE080B5A` (`lic`),
  CONSTRAINT `FK_AFBA32E2DE080B5A` FOREIGN KEY (`lic`) REFERENCES `libro_iva_compra` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_LIC`
--

LOCK TABLES `item_LIC` WRITE;
/*!40000 ALTER TABLE `item_LIC` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_LIC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_compra`
--

DROP TABLE IF EXISTS `item_compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_compra` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `producto` int(11) DEFAULT NULL,
  `tasa_id` int(11) DEFAULT NULL,
  `compra` int(11) DEFAULT NULL,
  `cantidad` decimal(10,3) DEFAULT NULL,
  `precioCosto` decimal(10,3) DEFAULT NULL,
  `total` decimal(10,3) DEFAULT NULL,
  `pIVA` decimal(10,3) DEFAULT NULL,
  `gIVA` tinyint(1) DEFAULT NULL,
  `tIVA` decimal(10,3) DEFAULT NULL,
  `bonificacion` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_18384430A7BB0615` (`producto`),
  KEY `IDX_18384430E20BE1E2` (`tasa_id`),
  KEY `IDX_183844309EC131FF` (`compra`),
  CONSTRAINT `FK_183844309EC131FF` FOREIGN KEY (`compra`) REFERENCES `compra` (`id`),
  CONSTRAINT `FK_18384430A7BB0615` FOREIGN KEY (`producto`) REFERENCES `Producto` (`id`),
  CONSTRAINT `FK_18384430E20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_compra`
--

LOCK TABLES `item_compra` WRITE;
/*!40000 ALTER TABLE `item_compra` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_especies`
--

DROP TABLE IF EXISTS `item_especies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_especies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `producto` int(11) DEFAULT NULL,
  `tasa_id` int(11) DEFAULT NULL,
  `especies` int(11) DEFAULT NULL,
  `cantidad` decimal(10,2) DEFAULT NULL,
  `precioCosto` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_A9479111A7BB0615` (`producto`),
  KEY `IDX_A9479111E20BE1E2` (`tasa_id`),
  KEY `IDX_A9479111C54A59DA` (`especies`),
  CONSTRAINT `FK_A9479111C54A59DA` FOREIGN KEY (`especies`) REFERENCES `EspeciesEmpleado` (`id`),
  CONSTRAINT `FK_A9479111A7BB0615` FOREIGN KEY (`producto`) REFERENCES `Producto` (`id`),
  CONSTRAINT `FK_A9479111E20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_especies`
--

LOCK TABLES `item_especies` WRITE;
/*!40000 ALTER TABLE `item_especies` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_especies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_nota_pedido`
--

DROP TABLE IF EXISTS `item_nota_pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_nota_pedido` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `producto` int(11) DEFAULT NULL,
  `tasa_id` int(11) DEFAULT NULL,
  `cantidad` decimal(10,2) DEFAULT NULL,
  `precioCosto` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `notaPedido` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_B81C17D6A7BB0615` (`producto`),
  KEY `IDX_B81C17D6E20BE1E2` (`tasa_id`),
  KEY `IDX_B81C17D6D82778A0` (`notaPedido`),
  CONSTRAINT `FK_B81C17D6D82778A0` FOREIGN KEY (`notaPedido`) REFERENCES `nota_pedido` (`id`),
  CONSTRAINT `FK_B81C17D6A7BB0615` FOREIGN KEY (`producto`) REFERENCES `Producto` (`id`),
  CONSTRAINT `FK_B81C17D6E20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_nota_pedido`
--

LOCK TABLES `item_nota_pedido` WRITE;
/*!40000 ALTER TABLE `item_nota_pedido` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_nota_pedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `itempedido_ingrediente`
--

DROP TABLE IF EXISTS `itempedido_ingrediente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `itempedido_ingrediente` (
  `itempedido_id` int(11) NOT NULL,
  `ingrediente_id` int(11) NOT NULL,
  PRIMARY KEY (`itempedido_id`,`ingrediente_id`),
  KEY `IDX_97BF75CBA99E891` (`itempedido_id`),
  KEY `IDX_97BF75CB769E458D` (`ingrediente_id`),
  CONSTRAINT `FK_97BF75CB769E458D` FOREIGN KEY (`ingrediente_id`) REFERENCES `Ingrediente` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_97BF75CBA99E891` FOREIGN KEY (`itempedido_id`) REFERENCES `ItemPedido` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `itempedido_ingrediente`
--

LOCK TABLES `itempedido_ingrediente` WRITE;
/*!40000 ALTER TABLE `itempedido_ingrediente` DISABLE KEYS */;
/*!40000 ALTER TABLE `itempedido_ingrediente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iva`
--

DROP TABLE IF EXISTS `iva`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iva` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa_id` int(11) DEFAULT NULL,
  `tasa` decimal(10,2) NOT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `gravado` tinyint(1) NOT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_FB97A603521E1991` (`empresa_id`),
  CONSTRAINT `FK_FB97A603521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iva`
--

LOCK TABLES `iva` WRITE;
/*!40000 ALTER TABLE `iva` DISABLE KEYS */;
INSERT INTO `iva` VALUES (1,1,21.00,'Tasa de Iva 21% Gravado',1,NULL),(2,1,10.50,NULL,1,1);
/*!40000 ALTER TABLE `iva` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `libro_iva_compra`
--

DROP TABLE IF EXISTS `libro_iva_compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `libro_iva_compra` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proveedor_id` int(11) DEFAULT NULL,
  `compra_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `tipo` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `cuit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `razonSocial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `neto` decimal(10,3) DEFAULT NULL,
  `acrecent` decimal(10,3) DEFAULT NULL,
  `total` decimal(10,3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_89B2384F2E704D7` (`compra_id`),
  KEY `IDX_89B2384CB305D73` (`proveedor_id`),
  KEY `IDX_89B2384521E1991` (`empresa_id`),
  CONSTRAINT `FK_89B2384521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_89B2384CB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedor` (`id`),
  CONSTRAINT `FK_89B2384F2E704D7` FOREIGN KEY (`compra_id`) REFERENCES `compra` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `libro_iva_compra`
--

LOCK TABLES `libro_iva_compra` WRITE;
/*!40000 ALTER TABLE `libro_iva_compra` DISABLE KEYS */;
/*!40000 ALTER TABLE `libro_iva_compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lineatanda_ingrediente`
--

DROP TABLE IF EXISTS `lineatanda_ingrediente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lineatanda_ingrediente` (
  `lineatanda_id` int(11) NOT NULL,
  `ingrediente_id` int(11) NOT NULL,
  PRIMARY KEY (`lineatanda_id`,`ingrediente_id`),
  KEY `IDX_4E68FE3211BF7F8B` (`lineatanda_id`),
  KEY `IDX_4E68FE32769E458D` (`ingrediente_id`),
  CONSTRAINT `FK_4E68FE32769E458D` FOREIGN KEY (`ingrediente_id`) REFERENCES `Ingrediente` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_4E68FE3211BF7F8B` FOREIGN KEY (`lineatanda_id`) REFERENCES `LineaTanda` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lineatanda_ingrediente`
--

LOCK TABLES `lineatanda_ingrediente` WRITE;
/*!40000 ALTER TABLE `lineatanda_ingrediente` DISABLE KEYS */;
/*!40000 ALTER TABLE `lineatanda_ingrediente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mensaje`
--

DROP TABLE IF EXISTS `mensaje`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mensaje` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `mensaje` longtext COLLATE utf8_unicode_ci,
  `leido` tinyint(1) NOT NULL,
  `nuevo` tinyint(1) NOT NULL,
  `tipo` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9B631D01DB38439E` (`usuario_id`),
  CONSTRAINT `FK_9B631D01DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensaje`
--

LOCK TABLES `mensaje` WRITE;
/*!40000 ALTER TABLE `mensaje` DISABLE KEYS */;
/*!40000 ALTER TABLE `mensaje` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mov_empleado`
--

DROP TABLE IF EXISTS `mov_empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mov_empleado` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cuenta` int(11) DEFAULT NULL,
  `monto` decimal(10,2) NOT NULL,
  `fecha` date NOT NULL,
  `fechaEmision` datetime NOT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `discr` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_E443D23431C7BFCF` (`cuenta`),
  CONSTRAINT `FK_E443D23431C7BFCF` FOREIGN KEY (`cuenta`) REFERENCES `cuenta_empleado` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mov_empleado`
--

LOCK TABLES `mov_empleado` WRITE;
/*!40000 ALTER TABLE `mov_empleado` DISABLE KEYS */;
/*!40000 ALTER TABLE `mov_empleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nota_pedido`
--

DROP TABLE IF EXISTS `nota_pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nota_pedido` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proveedor_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `estado` smallint(6) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_58744FE0CB305D73` (`proveedor_id`),
  KEY `IDX_58744FE0521E1991` (`empresa_id`),
  CONSTRAINT `FK_58744FE0521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_58744FE0CB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedor` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nota_pedido`
--

LOCK TABLES `nota_pedido` WRITE;
/*!40000 ALTER TABLE `nota_pedido` DISABLE KEYS */;
/*!40000 ALTER TABLE `nota_pedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pago`
--

DROP TABLE IF EXISTS `pago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pago` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `compra` int(11) DEFAULT NULL,
  `importe` decimal(10,3) DEFAULT NULL,
  `aclaracion` longtext COLLATE utf8_unicode_ci,
  `fecha` date DEFAULT NULL,
  `fechaEmision` datetime DEFAULT NULL,
  `facturaServicio` int(11) DEFAULT NULL,
  `tipoCobro_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_F4DF5F3E9EC131FF` (`compra`),
  KEY `IDX_F4DF5F3E53B38154` (`facturaServicio`),
  KEY `IDX_F4DF5F3EE414003F` (`tipoCobro_id`),
  CONSTRAINT `FK_F4DF5F3EE414003F` FOREIGN KEY (`tipoCobro_id`) REFERENCES `TipoCobro` (`id`),
  CONSTRAINT `FK_F4DF5F3E53B38154` FOREIGN KEY (`facturaServicio`) REFERENCES `factura_servicio` (`id`),
  CONSTRAINT `FK_F4DF5F3E9EC131FF` FOREIGN KEY (`compra`) REFERENCES `compra` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pago`
--

LOCK TABLES `pago` WRITE;
/*!40000 ALTER TABLE `pago` DISABLE KEYS */;
/*!40000 ALTER TABLE `pago` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `persona_empleado`
--

DROP TABLE IF EXISTS `persona_empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `persona_empleado` (
  `id` int(11) NOT NULL,
  `direccion_id` int(11) DEFAULT NULL,
  `cuenta` int(11) DEFAULT NULL,
  `imagen_id` int(11) DEFAULT NULL,
  `dni` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fechaNac` date NOT NULL,
  `fechaIngreso` date NOT NULL,
  `primerPago` date DEFAULT NULL,
  `sexo` tinyint(1) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_390AAB13D0A7BD7` (`direccion_id`),
  UNIQUE KEY `UNIQ_390AAB1331C7BFCF` (`cuenta`),
  UNIQUE KEY `UNIQ_390AAB13763C8AA7` (`imagen_id`),
  CONSTRAINT `FK_390AAB13BF396750` FOREIGN KEY (`id`) REFERENCES `Usuario` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_390AAB1331C7BFCF` FOREIGN KEY (`cuenta`) REFERENCES `cuenta_empleado` (`id`),
  CONSTRAINT `FK_390AAB13763C8AA7` FOREIGN KEY (`imagen_id`) REFERENCES `Image` (`id`),
  CONSTRAINT `FK_390AAB13D0A7BD7` FOREIGN KEY (`direccion_id`) REFERENCES `Direccion` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `persona_empleado`
--

LOCK TABLES `persona_empleado` WRITE;
/*!40000 ALTER TABLE `persona_empleado` DISABLE KEYS */;
/*!40000 ALTER TABLE `persona_empleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedor`
--

DROP TABLE IF EXISTS `proveedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proveedor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `direccion_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `razonSocial` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `cuit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `responsable` tinyint(1) NOT NULL,
  `activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_16C068CE832CBC66` (`razonSocial`),
  UNIQUE KEY `UNIQ_16C068CED0A7BD7` (`direccion_id`),
  KEY `IDX_16C068CE521E1991` (`empresa_id`),
  CONSTRAINT `FK_16C068CE521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_16C068CED0A7BD7` FOREIGN KEY (`direccion_id`) REFERENCES `Direccion` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor`
--

LOCK TABLES `proveedor` WRITE;
/*!40000 ALTER TABLE `proveedor` DISABLE KEYS */;
INSERT INTO `proveedor` VALUES (1,2,1,'Total Distribuidora','30-33111222-0','totalD@gmail.com',0,1),(2,3,1,'Hettinger Distribuciones SRL','20-32145672-3','het@gmail.com',0,1),(3,4,1,'Verduleria El rancho','20-45411121-3',NULL,0,1),(4,5,1,'Ilolay SA','30-69123478-3','ilolaySAL@gmail.com',0,1),(5,6,1,'Carniceria Caballito','20-35225412-5',NULL,0,1),(6,7,1,'Panaderia La nueva','20-55224124-5',NULL,0,1);
/*!40000 ALTER TABLE `proveedor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recargo_tipopedido`
--

DROP TABLE IF EXISTS `recargo_tipopedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recargo_tipopedido` (
  `recargo_id` int(11) NOT NULL,
  `tipopedido_id` int(11) NOT NULL,
  PRIMARY KEY (`recargo_id`,`tipopedido_id`),
  KEY `IDX_A54355E3E3DAE5D1` (`recargo_id`),
  KEY `IDX_A54355E3B0517A93` (`tipopedido_id`),
  CONSTRAINT `FK_A54355E3B0517A93` FOREIGN KEY (`tipopedido_id`) REFERENCES `TipoPedido` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_A54355E3E3DAE5D1` FOREIGN KEY (`recargo_id`) REFERENCES `Recargo` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recargo_tipopedido`
--

LOCK TABLES `recargo_tipopedido` WRITE;
/*!40000 ALTER TABLE `recargo_tipopedido` DISABLE KEYS */;
/*!40000 ALTER TABLE `recargo_tipopedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registroProduccion`
--

DROP TABLE IF EXISTS `registroProduccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registroProduccion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tasa_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `tipo` tinyint(1) DEFAULT NULL,
  `cantidad` decimal(10,2) DEFAULT NULL,
  `costo` decimal(10,2) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `productoProduccion` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_89F2E403EA73C921` (`productoProduccion`),
  KEY `IDX_89F2E403E20BE1E2` (`tasa_id`),
  KEY `IDX_89F2E403521E1991` (`empresa_id`),
  CONSTRAINT `FK_89F2E403521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_89F2E403E20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`),
  CONSTRAINT `FK_89F2E403EA73C921` FOREIGN KEY (`productoProduccion`) REFERENCES `ProductoProduccion` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registroProduccion`
--

LOCK TABLES `registroProduccion` WRITE;
/*!40000 ALTER TABLE `registroProduccion` DISABLE KEYS */;
/*!40000 ALTER TABLE `registroProduccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicio`
--

DROP TABLE IF EXISTS `servicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servicio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nombreEmpresa` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `cuit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `codigo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CB86F22A43AD9559` (`nombreEmpresa`),
  KEY `IDX_CB86F22A521E1991` (`empresa_id`),
  CONSTRAINT `FK_CB86F22A521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicio`
--

LOCK TABLES `servicio` WRITE;
/*!40000 ALTER TABLE `servicio` DISABLE KEYS */;
/*!40000 ALTER TABLE `servicio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasa`
--

DROP TABLE IF EXISTS `tasa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tasa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `um_id` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `abrev` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `valor` decimal(10,2) DEFAULT NULL,
  `pivote` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_B2AB323BA75CAB5E` (`um_id`),
  CONSTRAINT `FK_B2AB323BA75CAB5E` FOREIGN KEY (`um_id`) REFERENCES `unidad_medida` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasa`
--

LOCK TABLES `tasa` WRITE;
/*!40000 ALTER TABLE `tasa` DISABLE KEYS */;
INSERT INTO `tasa` VALUES (1,'24182f9f-5b06-1','Unidad','Unidad de un producto','u',1.00,1),(2,'24182f9f-5b06-1','Docena','Son 12 unidades de un producto','doc',12.00,0),(3,'24182f9f-5b06-1','Media docena',NULL,'1/2 doc',6.00,0),(4,'81bc97d4-5b0d-1','Gramo','','gr',1.00,1),(5,'81bc97d4-5b0d-1','Kilogramo','Es un kilo de un producto','kg',1000.00,0),(6,'81bc97d4-5b0d-1','Caja de maizena','Representa el contenido de una cajita de maizena','cajM',350.00,0),(7,'81bc97d4-5b0d-1','Bolsa de 3 KG','Bolsa como la de papa frita que tiene tres kilos','3 KG',3000.00,0);
/*!40000 ALTER TABLE `tasa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_pago`
--

DROP TABLE IF EXISTS `tipo_pago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_pago` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `atr1` longtext COLLATE utf8_unicode_ci,
  `atr2` longtext COLLATE utf8_unicode_ci,
  `atr3` longtext COLLATE utf8_unicode_ci,
  `atr4` longtext COLLATE utf8_unicode_ci,
  `atr5` longtext COLLATE utf8_unicode_ci,
  `tipo1` int(11) DEFAULT NULL,
  `tipo2` int(11) DEFAULT NULL,
  `tipo3` int(11) DEFAULT NULL,
  `tipo4` int(11) DEFAULT NULL,
  `tipo5` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_FEF0887B521E1991` (`empresa_id`),
  CONSTRAINT `FK_FEF0887B521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_pago`
--

LOCK TABLES `tipo_pago` WRITE;
/*!40000 ALTER TABLE `tipo_pago` DISABLE KEYS */;
/*!40000 ALTER TABLE `tipo_pago` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unidad_medida`
--

DROP TABLE IF EXISTS `unidad_medida`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `unidad_medida` (
  `id` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `IDX_7DA31363521E1991` (`empresa_id`),
  CONSTRAINT `FK_7DA31363521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unidad_medida`
--

LOCK TABLES `unidad_medida` WRITE;
/*!40000 ALTER TABLE `unidad_medida` DISABLE KEYS */;
INSERT INTO `unidad_medida` VALUES ('24182f9f-5b06-1',1,'Cantidad','Cantidad de un producto'),('81bc97d4-5b0d-1',1,'Peso','Representa los pesos de los distintos productos');
/*!40000 ALTER TABLE `unidad_medida` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-12-02 11:07:08
