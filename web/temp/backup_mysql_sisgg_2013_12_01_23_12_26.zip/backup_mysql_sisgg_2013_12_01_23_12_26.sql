-- MySQL dump 10.13  Distrib 5.5.32, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: SisGG
-- ------------------------------------------------------
-- Server version	5.5.32-0ubuntu0.13.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AdicionalEmpleado`
--

DROP TABLE IF EXISTS `AdicionalEmpleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AdicionalEmpleado` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_2A72E716BF396750` FOREIGN KEY (`id`) REFERENCES `mov_empleado` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AdicionalEmpleado`
--

LOCK TABLES `AdicionalEmpleado` WRITE;
/*!40000 ALTER TABLE `AdicionalEmpleado` DISABLE KEYS */;
/*!40000 ALTER TABLE `AdicionalEmpleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Agenda`
--

DROP TABLE IF EXISTS `Agenda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Agenda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `etiqueta` int(11) DEFAULT NULL,
  `asunto` longtext COLLATE utf8_unicode_ci NOT NULL,
  `lugar` longtext COLLATE utf8_unicode_ci,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `todos` tinyint(1) DEFAULT NULL,
  `inicioFec` date DEFAULT NULL,
  `finFec` date DEFAULT NULL,
  `inicioHora` time DEFAULT NULL,
  `finHora` time DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_2B41CD416D5CA63A` (`etiqueta`),
  KEY `IDX_2B41CD41DB38439E` (`usuario_id`),
  CONSTRAINT `FK_2B41CD416D5CA63A` FOREIGN KEY (`etiqueta`) REFERENCES `EtiquetaAgenda` (`id`),
  CONSTRAINT `FK_2B41CD41DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Agenda`
--

LOCK TABLES `Agenda` WRITE;
/*!40000 ALTER TABLE `Agenda` DISABLE KEYS */;
/*!40000 ALTER TABLE `Agenda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Apertura`
--

DROP TABLE IF EXISTS `Apertura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Apertura` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `caja_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_268D37BDDB38439E` (`usuario_id`),
  KEY `IDX_268D37BD2D82B651` (`caja_id`),
  CONSTRAINT `FK_268D37BD2D82B651` FOREIGN KEY (`caja_id`) REFERENCES `Caja` (`id`),
  CONSTRAINT `FK_268D37BDBF396750` FOREIGN KEY (`id`) REFERENCES `Movimiento` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_268D37BDDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Apertura`
--

LOCK TABLES `Apertura` WRITE;
/*!40000 ALTER TABLE `Apertura` DISABLE KEYS */;
INSERT INTO `Apertura` VALUES (1,1,1),(20,1,1),(27,1,1),(39,1,1),(107,4,1);
/*!40000 ALTER TABLE `Apertura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Backup`
--

DROP TABLE IF EXISTS `Backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `carpeta` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `archivo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_385CD49ADB38439E` (`usuario_id`),
  CONSTRAINT `FK_385CD49ADB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Backup`
--

LOCK TABLES `Backup` WRITE;
/*!40000 ALTER TABLE `Backup` DISABLE KEYS */;
INSERT INTO `Backup` VALUES (1,4,'/var/backups/','backup_mysql_sisgg_2013_12_01_23_05_44.sql','2013-12-01 23:05:45');
/*!40000 ALTER TABLE `Backup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Caja`
--

DROP TABLE IF EXISTS `Caja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Caja` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa_id` int(11) DEFAULT NULL,
  `puntoVentaA` int(11) DEFAULT NULL,
  `ultimaFacturaA` int(11) DEFAULT NULL,
  `puntoVentaB` int(11) DEFAULT NULL,
  `ultimaFacturaB` int(11) DEFAULT NULL,
  `puntoVentaC` int(11) DEFAULT NULL,
  `ultimaFacturaC` int(11) DEFAULT NULL,
  `minimoApertura` decimal(10,2) DEFAULT NULL,
  `abierta` tinyint(1) DEFAULT NULL,
  `saldo` decimal(10,2) DEFAULT NULL,
  `serieNotaCreditoA` int(11) DEFAULT NULL,
  `ultimoNumeroNotaCreditoA` int(11) DEFAULT NULL,
  `serieNotaCreditoB` int(11) DEFAULT NULL,
  `ultimoNumeroNotaCreditoB` int(11) DEFAULT NULL,
  `serieNotaCreditoC` int(11) DEFAULT NULL,
  `ultimoNumeroNotaCreditoC` int(11) DEFAULT NULL,
  `serieRecibo` int(11) DEFAULT NULL,
  `ultimoNumeroRecibo` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_44575B3B521E1991` (`empresa_id`),
  CONSTRAINT `FK_44575B3B521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Caja`
--

LOCK TABLES `Caja` WRITE;
/*!40000 ALTER TABLE `Caja` DISABLE KEYS */;
INSERT INTO `Caja` VALUES (1,NULL,1,27,1,19,1,41,NULL,1,3.07,1,0,1,0,1,0,1,4);
/*!40000 ALTER TABLE `Caja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Campo`
--

DROP TABLE IF EXISTS `Campo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Campo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `requerido` tinyint(1) DEFAULT NULL,
  `unico` tinyint(1) DEFAULT NULL,
  `tipoDato` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `patron` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ejemplo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipoCobro_id` int(11) DEFAULT NULL,
  `discr` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_E8D618AEE414003F` (`tipoCobro_id`),
  CONSTRAINT `FK_E8D618AEE414003F` FOREIGN KEY (`tipoCobro_id`) REFERENCES `TipoCobro` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Campo`
--

LOCK TABLES `Campo` WRITE;
/*!40000 ALTER TABLE `Campo` DISABLE KEYS */;
INSERT INTO `Campo` VALUES (1,'Numero de Comprobante',1,NULL,'text','[0-9]{4}','0001',3,'campo'),(2,'Numero de Cheque',1,NULL,'text','[0-9]{8}','00000001',4,'campo');
/*!40000 ALTER TABLE `Campo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CancelarEmpleado`
--

DROP TABLE IF EXISTS `CancelarEmpleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CancelarEmpleado` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_AB7562F8BF396750` FOREIGN KEY (`id`) REFERENCES `mov_empleado` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CancelarEmpleado`
--

LOCK TABLES `CancelarEmpleado` WRITE;
/*!40000 ALTER TABLE `CancelarEmpleado` DISABLE KEYS */;
/*!40000 ALTER TABLE `CancelarEmpleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cargo`
--

DROP TABLE IF EXISTS `Cargo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cargo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `tipo` int(11) NOT NULL,
  `porDia` int(11) DEFAULT NULL,
  `porFecha` int(11) DEFAULT NULL,
  `porDiaSemana` int(11) DEFAULT NULL,
  `monto` decimal(10,2) DEFAULT NULL,
  `negativo` decimal(10,2) DEFAULT NULL,
  `discr` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cargo`
--

LOCK TABLES `Cargo` WRITE;
/*!40000 ALTER TABLE `Cargo` DISABLE KEYS */;
INSERT INTO `Cargo` VALUES (1,'Martin',NULL,0,NULL,21,NULL,1000.00,100.00,'cargo_sistema'),(2,'Martin',NULL,0,NULL,21,NULL,1000.00,100.00,'cargo_empleado'),(3,'Martin',NULL,0,NULL,21,NULL,1000.00,100.00,'cargo_empleado');
/*!40000 ALTER TABLE `Cargo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CargoEmpleado`
--

DROP TABLE IF EXISTS `CargoEmpleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CargoEmpleado` (
  `id` int(11) NOT NULL,
  `empleado` int(11) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  `cargoSistema` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_EFE623A3B5257733` (`cargoSistema`),
  KEY `IDX_EFE623A3D9D9BF52` (`empleado`),
  CONSTRAINT `FK_EFE623A3B5257733` FOREIGN KEY (`cargoSistema`) REFERENCES `CargoSistema` (`id`),
  CONSTRAINT `FK_EFE623A3BF396750` FOREIGN KEY (`id`) REFERENCES `Cargo` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_EFE623A3D9D9BF52` FOREIGN KEY (`empleado`) REFERENCES `persona_empleado` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CargoEmpleado`
--

LOCK TABLES `CargoEmpleado` WRITE;
/*!40000 ALTER TABLE `CargoEmpleado` DISABLE KEYS */;
INSERT INTO `CargoEmpleado` VALUES (2,2,1,1),(3,3,1,1);
/*!40000 ALTER TABLE `CargoEmpleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CargoSistema`
--

DROP TABLE IF EXISTS `CargoSistema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CargoSistema` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_AD14ACCB521E1991` (`empresa_id`),
  CONSTRAINT `FK_AD14ACCB521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_AD14ACCBBF396750` FOREIGN KEY (`id`) REFERENCES `Cargo` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CargoSistema`
--

LOCK TABLES `CargoSistema` WRITE;
/*!40000 ALTER TABLE `CargoSistema` DISABLE KEYS */;
INSERT INTO `CargoSistema` VALUES (1,1);
/*!40000 ALTER TABLE `CargoSistema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CategoriaProductoProduccion`
--

DROP TABLE IF EXISTS `CategoriaProductoProduccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CategoriaProductoProduccion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `padre_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_A7F3044C3A909126` (`nombre`),
  KEY `IDX_A7F3044C613CEC58` (`padre_id`),
  KEY `IDX_A7F3044C521E1991` (`empresa_id`),
  CONSTRAINT `FK_A7F3044C521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_A7F3044C613CEC58` FOREIGN KEY (`padre_id`) REFERENCES `CategoriaProductoProduccion` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CategoriaProductoProduccion`
--

LOCK TABLES `CategoriaProductoProduccion` WRITE;
/*!40000 ALTER TABLE `CategoriaProductoProduccion` DISABLE KEYS */;
INSERT INTO `CategoriaProductoProduccion` VALUES (1,NULL,1,'Carnes',NULL,1),(2,NULL,1,'Verduras',NULL,1);
/*!40000 ALTER TABLE `CategoriaProductoProduccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CategoriaProductoVenta`
--

DROP TABLE IF EXISTS `CategoriaProductoVenta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CategoriaProductoVenta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `padre_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_EA15CFA63A909126` (`nombre`),
  KEY `IDX_EA15CFA6613CEC58` (`padre_id`),
  KEY `IDX_EA15CFA6521E1991` (`empresa_id`),
  CONSTRAINT `FK_EA15CFA6521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_EA15CFA6613CEC58` FOREIGN KEY (`padre_id`) REFERENCES `CategoriaProductoVenta` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CategoriaProductoVenta`
--

LOCK TABLES `CategoriaProductoVenta` WRITE;
/*!40000 ALTER TABLE `CategoriaProductoVenta` DISABLE KEYS */;
INSERT INTO `CategoriaProductoVenta` VALUES (1,NULL,1,'Pastas',NULL,1),(2,NULL,1,'Bebidas',NULL,1),(3,NULL,1,'Rapidas',NULL,1);
/*!40000 ALTER TABLE `CategoriaProductoVenta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ChatMensaje`
--

DROP TABLE IF EXISTS `ChatMensaje`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ChatMensaje` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `destino` int(11) DEFAULT NULL,
  `usuario` int(11) DEFAULT NULL,
  `mensaje` longtext COLLATE utf8_unicode_ci,
  `eliminar` int(11) DEFAULT NULL,
  `leido` tinyint(1) DEFAULT NULL,
  `envio` tinyint(1) DEFAULT NULL,
  `fechaEnvio` datetime DEFAULT NULL,
  `fechaRecibo` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_4CAD7BE881F64EFA` (`destino`),
  KEY `IDX_4CAD7BE82265B05D` (`usuario`),
  CONSTRAINT `FK_4CAD7BE82265B05D` FOREIGN KEY (`usuario`) REFERENCES `Usuario` (`id`),
  CONSTRAINT `FK_4CAD7BE881F64EFA` FOREIGN KEY (`destino`) REFERENCES `Usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ChatMensaje`
--

LOCK TABLES `ChatMensaje` WRITE;
/*!40000 ALTER TABLE `ChatMensaje` DISABLE KEYS */;
/*!40000 ALTER TABLE `ChatMensaje` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cierre`
--

DROP TABLE IF EXISTS `Cierre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cierre` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `caja_id` int(11) DEFAULT NULL,
  `conformidad` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `extraerTotal` tinyint(1) DEFAULT NULL,
  `numeroCierre` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D770F9F1DB38439E` (`usuario_id`),
  KEY `IDX_D770F9F12D82B651` (`caja_id`),
  CONSTRAINT `FK_D770F9F12D82B651` FOREIGN KEY (`caja_id`) REFERENCES `Caja` (`id`),
  CONSTRAINT `FK_D770F9F1BF396750` FOREIGN KEY (`id`) REFERENCES `Movimiento` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_D770F9F1DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cierre`
--

LOCK TABLES `Cierre` WRITE;
/*!40000 ALTER TABLE `Cierre` DISABLE KEYS */;
INSERT INTO `Cierre` VALUES (19,1,1,NULL,NULL,1),(26,1,1,NULL,NULL,2),(38,1,1,NULL,NULL,3),(106,4,1,NULL,NULL,4);
/*!40000 ALTER TABLE `Cierre` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Ciudad`
--

DROP TABLE IF EXISTS `Ciudad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Ciudad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provincia_id` int(11) DEFAULT NULL,
  `nombre` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `codigoPostal` int(11) NOT NULL,
  `porDefecto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_892A00A84E7121AF` (`provincia_id`),
  CONSTRAINT `FK_892A00A84E7121AF` FOREIGN KEY (`provincia_id`) REFERENCES `Provincia` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Ciudad`
--

LOCK TABLES `Ciudad` WRITE;
/*!40000 ALTER TABLE `Ciudad` DISABLE KEYS */;
INSERT INTO `Ciudad` VALUES (1,1,'Posadas',3300,1),(2,1,'Obera',3360,0);
/*!40000 ALTER TABLE `Ciudad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cliente`
--

DROP TABLE IF EXISTS `Cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cliente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `telefono_id` int(11) DEFAULT NULL,
  `direccion_id` int(11) DEFAULT NULL,
  `email` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `documento` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `apellido` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `cuit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipoDocumento_id` int(11) DEFAULT NULL,
  `condicionIva_id` int(11) DEFAULT NULL,
  `discr` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `porDefecto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_3BA1A2B9FD6D75CD` (`telefono_id`),
  UNIQUE KEY `UNIQ_3BA1A2B9D0A7BD7` (`direccion_id`),
  KEY `IDX_3BA1A2B93668888B` (`tipoDocumento_id`),
  KEY `IDX_3BA1A2B9F60CF12A` (`condicionIva_id`),
  CONSTRAINT `FK_3BA1A2B93668888B` FOREIGN KEY (`tipoDocumento_id`) REFERENCES `TipoDocumento` (`id`),
  CONSTRAINT `FK_3BA1A2B9D0A7BD7` FOREIGN KEY (`direccion_id`) REFERENCES `Direccion` (`id`),
  CONSTRAINT `FK_3BA1A2B9F60CF12A` FOREIGN KEY (`condicionIva_id`) REFERENCES `CondicionIva` (`id`),
  CONSTRAINT `FK_3BA1A2B9FD6D75CD` FOREIGN KEY (`telefono_id`) REFERENCES `Telefono` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cliente`
--

LOCK TABLES `Cliente` WRITE;
/*!40000 ALTER TABLE `Cliente` DISABLE KEYS */;
INSERT INTO `Cliente` VALUES (1,1,2,NULL,'activo',NULL,'Herrera','Fernando Martin','20-34366629-3',NULL,1,'cliente',0),(2,2,4,NULL,'activo',NULL,'Herrera','Horacio',NULL,NULL,1,'cliente',0),(3,3,8,NULL,'activo',NULL,'Aquino','Ramona',NULL,NULL,3,'cliente',0),(4,4,10,NULL,'activo',NULL,'Consumidor','Final',NULL,NULL,3,'cliente',1),(5,5,19,NULL,'activo',NULL,'Soley','Francisco',NULL,NULL,3,'cliente',0),(6,6,23,NULL,'activo',NULL,'Ayala','Agustín',NULL,NULL,3,'cliente',0),(7,7,24,NULL,'activo',NULL,'Amarilla','Fernando',NULL,NULL,3,'cliente',0),(8,8,25,NULL,'inactivo',NULL,'Acosta','Fernando',NULL,NULL,3,'cliente',0),(9,9,26,NULL,'activo',NULL,'Blanco','Carlos Ezequiel',NULL,NULL,3,'cliente',0),(10,10,27,NULL,'activo',NULL,'Pirlo','Andrea',NULL,NULL,3,'cliente',0),(11,11,28,NULL,'activo',NULL,'Tevez','Carlos',NULL,NULL,3,'cliente',0),(12,12,29,NULL,'activo',NULL,'Aguero','Sergio',NULL,NULL,3,'cliente',0),(13,13,30,NULL,'activo',NULL,'Gigliotti','Emanuel',NULL,NULL,3,'cliente',0);
/*!40000 ALTER TABLE `Cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cobro`
--

DROP TABLE IF EXISTS `Cobro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cobro` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `venta_id` int(11) DEFAULT NULL,
  `importe` decimal(10,2) DEFAULT NULL,
  `aclaracion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipoCobro_id` int(11) DEFAULT NULL,
  `dtype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `unRecibo_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_31634A2263616B01` (`unRecibo_id`),
  KEY `IDX_31634A22F2A5805D` (`venta_id`),
  KEY `IDX_31634A22E414003F` (`tipoCobro_id`),
  CONSTRAINT `FK_31634A2263616B01` FOREIGN KEY (`unRecibo_id`) REFERENCES `Cobro` (`id`),
  CONSTRAINT `FK_31634A22E414003F` FOREIGN KEY (`tipoCobro_id`) REFERENCES `TipoCobro` (`id`),
  CONSTRAINT `FK_31634A22F2A5805D` FOREIGN KEY (`venta_id`) REFERENCES `Venta` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cobro`
--

LOCK TABLES `Cobro` WRITE;
/*!40000 ALTER TABLE `Cobro` DISABLE KEYS */;
INSERT INTO `Cobro` VALUES (1,1,44.80,NULL,1,'cobro',NULL),(2,3,81.20,NULL,1,'cobro',NULL),(3,5,38.50,NULL,1,'cobro',NULL),(4,7,13.30,NULL,1,'cobro',NULL),(5,9,20.00,NULL,1,'cobro',NULL),(6,10,19.08,NULL,3,'cobro',NULL),(7,11,100.00,NULL,1,'cobro',NULL),(8,12,100.00,NULL,1,'cobro',NULL),(9,13,20.00,NULL,1,'cobro',NULL),(10,14,37.70,NULL,1,'cobro',NULL),(11,15,50.00,NULL,1,'cobro',NULL),(12,17,50.00,NULL,1,'cobro',NULL),(13,18,20.00,NULL,1,'cobro',NULL),(14,19,18.00,NULL,1,'cobro',NULL),(15,20,48.00,NULL,1,'cobro',NULL),(16,21,360.00,NULL,1,'cobro',NULL),(17,22,50.00,NULL,1,'cobro',NULL),(18,23,18.00,NULL,3,'cobro',NULL),(19,24,180.00,NULL,3,'cobro',NULL),(20,28,33.00,NULL,1,'cobro',NULL),(22,30,44.50,NULL,1,'cobro',NULL),(25,34,26.50,NULL,1,'cobro',NULL),(26,35,24.00,NULL,1,'cobro',NULL),(27,36,26.50,NULL,1,'cobro',NULL),(28,37,26.50,NULL,1,'cobro',NULL),(29,38,26.50,NULL,1,'cobro',NULL),(30,39,100.00,NULL,1,'cobro',NULL),(31,40,100.00,NULL,1,'cobro',NULL),(32,41,150.00,NULL,1,'cobro',NULL),(33,42,100.00,NULL,1,'cobro',NULL),(34,43,100.00,NULL,1,'cobro',NULL),(35,44,100.00,NULL,1,'cobro',NULL),(36,47,71.00,NULL,3,'cobro',NULL),(37,48,50.00,NULL,1,'cobro',NULL),(38,51,66.00,NULL,1,'cobro',NULL),(39,53,66.00,NULL,1,'cobro',NULL),(40,54,66.00,NULL,1,'cobro',NULL),(41,56,66.00,NULL,1,'cobro',NULL),(42,57,100.00,NULL,1,'cobro',NULL),(43,58,95.00,NULL,3,'cobro',NULL),(44,59,57.95,NULL,1,'cobro',NULL),(45,60,23.00,NULL,1,'cobro',NULL),(46,63,40.50,NULL,1,'cobro',NULL),(47,68,20.00,NULL,1,'cobro',NULL),(49,NULL,20.25,'Ninguna',1,'cobro',NULL),(50,72,12.00,NULL,1,'cobro',NULL),(51,73,32.40,NULL,3,'cobro',NULL),(52,74,50.00,NULL,1,'cobro',NULL),(53,75,62.40,NULL,3,'cobro',NULL),(54,77,23.00,NULL,1,'cobro',NULL),(55,79,11.00,NULL,1,'cobro',NULL),(56,80,34.00,NULL,1,'cobro',NULL),(57,81,34.00,NULL,1,'cobro',NULL);
/*!40000 ALTER TABLE `Cobro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cocina`
--

DROP TABLE IF EXISTS `Cocina`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cocina` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `numeroTandas` int(11) NOT NULL,
  `tamanoMaximoEspera` int(11) DEFAULT NULL,
  `tamanoMaximoTandas` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cocina`
--

LOCK TABLES `Cocina` WRITE;
/*!40000 ALTER TABLE `Cocina` DISABLE KEYS */;
INSERT INTO `Cocina` VALUES (1,'Cocina Principal',1,NULL,NULL);
/*!40000 ALTER TABLE `Cocina` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Concepto`
--

DROP TABLE IF EXISTS `Concepto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Concepto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipo` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9DF5EA86521E1991` (`empresa_id`),
  CONSTRAINT `FK_9DF5EA86521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Concepto`
--

LOCK TABLES `Concepto` WRITE;
/*!40000 ALTER TABLE `Concepto` DISABLE KEYS */;
INSERT INTO `Concepto` VALUES (1,1,'Pago por compra','Pago de una compra a un proveedor.','activo',0),(2,1,'Cobro por venta','Cobro de una venta a un cliente.','inactivo',1),(3,1,'Pago a un empleado','Pago a un empleado por servicio.','activo',0),(4,NULL,'Cobro por Venta','Cobro por Venta','activo',1);
/*!40000 ALTER TABLE `Concepto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CondicionIva`
--

DROP TABLE IF EXISTS `CondicionIva`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CondicionIva` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `abreviatura` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CondicionIva`
--

LOCK TABLES `CondicionIva` WRITE;
/*!40000 ALTER TABLE `CondicionIva` DISABLE KEYS */;
INSERT INTO `CondicionIva` VALUES (1,'IVA RESPONSABLE INSCRIPTO','RI','activo'),(2,'RESPONSABLE MONOTRIBUTO','RM','activo'),(3,'CONSUMIDOR FINAL','CF','activo'),(4,'EXENTO',NULL,'activo');
/*!40000 ALTER TABLE `CondicionIva` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ContadoEmpleado`
--

DROP TABLE IF EXISTS `ContadoEmpleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ContadoEmpleado` (
  `id` int(11) NOT NULL,
  `pago_id` int(11) DEFAULT NULL,
  `liquido` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8A44E4B363FB8380` (`pago_id`),
  CONSTRAINT `FK_8A44E4B363FB8380` FOREIGN KEY (`pago_id`) REFERENCES `pago` (`id`),
  CONSTRAINT `FK_8A44E4B3BF396750` FOREIGN KEY (`id`) REFERENCES `mov_empleado` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ContadoEmpleado`
--

LOCK TABLES `ContadoEmpleado` WRITE;
/*!40000 ALTER TABLE `ContadoEmpleado` DISABLE KEYS */;
/*!40000 ALTER TABLE `ContadoEmpleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CuentaCorriente`
--

DROP TABLE IF EXISTS `CuentaCorriente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CuentaCorriente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maximo` decimal(10,2) DEFAULT NULL,
  `saldo` decimal(10,2) DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fechaCreacion` datetime NOT NULL,
  `fechaEliminacion` datetime DEFAULT NULL,
  `plazoGeneracionRecibos` int(11) DEFAULT NULL,
  `diasEntreAvisos` int(11) DEFAULT NULL,
  `numeroCuenta` int(11) NOT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_BF296AB0DE734E51` (`cliente_id`),
  CONSTRAINT `FK_BF296AB0DE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Cliente` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CuentaCorriente`
--

LOCK TABLES `CuentaCorriente` WRITE;
/*!40000 ALTER TABLE `CuentaCorriente` DISABLE KEYS */;
INSERT INTO `CuentaCorriente` VALUES (1,2500.00,0.00,'activo','2013-10-31 22:28:34',NULL,30,NULL,1,12),(2,3000.00,NULL,'activo','2013-11-02 11:01:29',NULL,30,NULL,2,11),(3,3000.00,-23.00,'activo','2013-11-02 11:01:50',NULL,15,NULL,3,7),(4,NULL,0.00,'activo','2013-11-02 11:17:50',NULL,30,NULL,4,6),(5,15000.00,0.00,'activo','2013-11-02 18:03:27',NULL,30,NULL,5,1),(6,2000.00,0.00,'activo','2013-11-04 15:47:00',NULL,30,NULL,6,3);
/*!40000 ALTER TABLE `CuentaCorriente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Descuento`
--

DROP TABLE IF EXISTS `Descuento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Descuento` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `porcentaje` decimal(10,2) DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `discr` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Descuento`
--

LOCK TABLES `Descuento` WRITE;
/*!40000 ALTER TABLE `Descuento` DISABLE KEYS */;
INSERT INTO `Descuento` VALUES (1,'Cliente exclusivo',50.00,'Descuento por buen cliente','activo','descuentocliente'),(2,'Estrategia de Marketing',30.00,'Estrategia magistral','inactivo','descuentoproductoventa');
/*!40000 ALTER TABLE `Descuento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DescuentoCliente`
--

DROP TABLE IF EXISTS `DescuentoCliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DescuentoCliente` (
  `id` int(11) NOT NULL,
  `importe` decimal(10,2) DEFAULT NULL,
  `tipoPorcentaje` tinyint(1) DEFAULT NULL,
  `tipoImporte` tinyint(1) DEFAULT NULL,
  `minimo` decimal(10,2) DEFAULT NULL,
  `maximo` decimal(10,2) DEFAULT NULL,
  `venta_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_12778F1AF2A5805D` (`venta_id`),
  CONSTRAINT `FK_12778F1ABF396750` FOREIGN KEY (`id`) REFERENCES `Descuento` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_12778F1AF2A5805D` FOREIGN KEY (`venta_id`) REFERENCES `Venta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DescuentoCliente`
--

LOCK TABLES `DescuentoCliente` WRITE;
/*!40000 ALTER TABLE `DescuentoCliente` DISABLE KEYS */;
INSERT INTO `DescuentoCliente` VALUES (1,30.00,1,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `DescuentoCliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DescuentoProductoVenta`
--

DROP TABLE IF EXISTS `DescuentoProductoVenta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DescuentoProductoVenta` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_CA04E58ABF396750` FOREIGN KEY (`id`) REFERENCES `Descuento` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DescuentoProductoVenta`
--

LOCK TABLES `DescuentoProductoVenta` WRITE;
/*!40000 ALTER TABLE `DescuentoProductoVenta` DISABLE KEYS */;
INSERT INTO `DescuentoProductoVenta` VALUES (2);
/*!40000 ALTER TABLE `DescuentoProductoVenta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DetalleSolicitud`
--

DROP TABLE IF EXISTS `DetalleSolicitud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DetalleSolicitud` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `solicitud_id` int(11) DEFAULT NULL,
  `texto` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_F599354A1CB9D6E4` (`solicitud_id`),
  CONSTRAINT `FK_F599354A1CB9D6E4` FOREIGN KEY (`solicitud_id`) REFERENCES `Solicitud` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DetalleSolicitud`
--

LOCK TABLES `DetalleSolicitud` WRITE;
/*!40000 ALTER TABLE `DetalleSolicitud` DISABLE KEYS */;
/*!40000 ALTER TABLE `DetalleSolicitud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Direccion`
--

DROP TABLE IF EXISTS `Direccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Direccion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ciudad_id` int(11) NOT NULL,
  `calle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `numero` int(11) NOT NULL,
  `manzana` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edificio` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `escalera` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `piso` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `departamento` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_71753C36E8608214` (`ciudad_id`),
  CONSTRAINT `FK_71753C36E8608214` FOREIGN KEY (`ciudad_id`) REFERENCES `Ciudad` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Direccion`
--

LOCK TABLES `Direccion` WRITE;
/*!40000 ALTER TABLE `Direccion` DISABLE KEYS */;
INSERT INTO `Direccion` VALUES (1,1,'Bolivar',3118,NULL,NULL,NULL,NULL,NULL),(2,1,'Luchessi',4590,NULL,NULL,NULL,NULL,NULL),(3,1,'Luchessi',4590,NULL,NULL,NULL,NULL,NULL),(4,1,'Luchessi',4590,NULL,NULL,NULL,NULL,NULL),(5,1,'Luchessi',4590,NULL,NULL,NULL,NULL,NULL),(6,1,'Luchessi',4590,NULL,NULL,NULL,NULL,NULL),(7,1,'Luchessi',4590,NULL,NULL,NULL,NULL,NULL),(8,1,'Luchessi',4590,NULL,NULL,NULL,NULL,NULL),(9,1,'Luchessi',4590,NULL,NULL,NULL,NULL,NULL),(10,1,'Ninguna',1111,NULL,NULL,NULL,NULL,NULL),(11,1,'Luchessi',4590,NULL,NULL,NULL,NULL,NULL),(12,1,'Luchessi',4590,NULL,NULL,NULL,NULL,NULL),(13,1,'Luchessi',4590,NULL,NULL,NULL,NULL,NULL),(14,1,'Luchessi',4590,NULL,NULL,NULL,NULL,NULL),(15,1,'Luchessi',4590,NULL,NULL,NULL,NULL,NULL),(16,1,'Luchessi',4590,NULL,NULL,NULL,NULL,NULL),(17,1,'Luchessi',4590,NULL,NULL,NULL,NULL,NULL),(18,1,'Luchessi',4590,NULL,NULL,NULL,NULL,NULL),(19,1,'Lavalle',8518,'Z','3',NULL,NULL,NULL),(20,1,'Lavalle',8518,'Z','3',NULL,NULL,NULL),(21,1,'Luchessi',4590,NULL,NULL,NULL,NULL,NULL),(22,1,'Luchessi',4590,NULL,NULL,NULL,NULL,NULL),(23,1,'Luchessi',4590,NULL,NULL,NULL,NULL,NULL),(24,1,'Bolivar',321,NULL,NULL,NULL,NULL,NULL),(25,1,'Las Américia',3127,NULL,NULL,NULL,NULL,NULL),(26,1,'San Martin',3029,NULL,NULL,NULL,NULL,NULL),(27,1,'Chacabuco',2013,NULL,NULL,NULL,NULL,NULL),(28,1,'Zapiola',1512,NULL,NULL,NULL,NULL,NULL),(29,1,'Rademacher',1516,NULL,NULL,NULL,NULL,NULL),(30,1,'Centenario',1526,NULL,NULL,NULL,NULL,NULL),(31,1,'Chacabuco',2013,NULL,NULL,NULL,NULL,NULL),(32,1,'La Valle',1515,NULL,NULL,NULL,NULL,NULL),(33,1,'Luchessi',4590,NULL,NULL,NULL,NULL,NULL),(34,1,'Bolivar',321,NULL,NULL,NULL,NULL,NULL),(35,1,'Bolivar',321,NULL,NULL,NULL,NULL,NULL),(36,1,'San Martin',3029,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `Direccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EgresoEmpleado`
--

DROP TABLE IF EXISTS `EgresoEmpleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EgresoEmpleado` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_55FA6BCFBF396750` FOREIGN KEY (`id`) REFERENCES `mov_empleado` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EgresoEmpleado`
--

LOCK TABLES `EgresoEmpleado` WRITE;
/*!40000 ALTER TABLE `EgresoEmpleado` DISABLE KEYS */;
/*!40000 ALTER TABLE `EgresoEmpleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Empresa`
--

DROP TABLE IF EXISTS `Empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Empresa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `direccion_id` int(11) DEFAULT NULL,
  `imagen_id` int(11) DEFAULT NULL,
  `nombre` varchar(70) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slogan` longtext COLLATE utf8_unicode_ci,
  `responsable` tinyint(1) NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contrasenia` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci NOT NULL,
  `cuit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `inicioAct` date DEFAULT NULL,
  `condicionIva_id` int(11) DEFAULT NULL,
  `edad` int(11) DEFAULT NULL,
  `carpeta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `carpetaAuditoria` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_776A63CCD0A7BD7` (`direccion_id`),
  UNIQUE KEY `UNIQ_776A63CC763C8AA7` (`imagen_id`),
  KEY `IDX_776A63CCF60CF12A` (`condicionIva_id`),
  CONSTRAINT `FK_776A63CC763C8AA7` FOREIGN KEY (`imagen_id`) REFERENCES `Image` (`id`),
  CONSTRAINT `FK_776A63CCD0A7BD7` FOREIGN KEY (`direccion_id`) REFERENCES `Direccion` (`id`),
  CONSTRAINT `FK_776A63CCF60CF12A` FOREIGN KEY (`condicionIva_id`) REFERENCES `CondicionIva` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Empresa`
--

LOCK TABLES `Empresa` WRITE;
/*!40000 ALTER TABLE `Empresa` DISABLE KEYS */;
INSERT INTO `Empresa` VALUES (1,1,6,'Example','Tu alegria a la hora de comer es la sonrisa de un niño',0,'admin@gmail.com','estandarte','Empresa dedicada a la venta de comidas','20-20202020-2','2013-10-01',1,10,'/var/backups/',NULL,'192.168.1.22');
/*!40000 ALTER TABLE `Empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Entrada`
--

DROP TABLE IF EXISTS `Entrada`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Entrada` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `caja_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_6F49BE8DB38439E` (`usuario_id`),
  KEY `IDX_6F49BE82D82B651` (`caja_id`),
  CONSTRAINT `FK_6F49BE82D82B651` FOREIGN KEY (`caja_id`) REFERENCES `Caja` (`id`),
  CONSTRAINT `FK_6F49BE8BF396750` FOREIGN KEY (`id`) REFERENCES `Movimiento` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_6F49BE8DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Entrada`
--

LOCK TABLES `Entrada` WRITE;
/*!40000 ALTER TABLE `Entrada` DISABLE KEYS */;
INSERT INTO `Entrada` VALUES (2,1,1),(3,1,1),(5,1,1),(7,1,1),(9,1,1),(11,1,1),(13,1,1),(15,1,1),(17,1,1),(22,1,1),(24,1,1),(28,1,1),(30,1,1),(32,1,1),(34,1,1),(36,1,1),(40,1,1),(42,1,1),(44,1,1),(45,1,1),(46,1,1),(47,1,1),(48,1,1),(49,1,1),(50,1,1),(51,1,1),(52,1,1),(53,1,1),(54,1,1),(55,1,1),(57,1,1),(59,1,1),(61,1,1),(63,1,1),(65,1,1),(67,1,1),(68,1,1),(69,1,1),(70,1,1),(71,1,1),(72,1,1),(74,1,1),(75,1,1),(76,1,1),(77,1,1),(78,1,1),(79,1,1),(81,1,1),(82,1,1),(83,1,1),(84,1,1),(85,1,1),(86,1,1),(87,1,1),(88,1,1),(89,1,1),(90,1,1),(91,1,1),(92,1,1),(93,1,1),(94,1,1),(95,1,1),(97,1,1),(98,1,1),(99,1,1),(100,1,1),(101,1,1),(102,1,1),(103,1,1),(104,1,1),(105,1,1);
/*!40000 ALTER TABLE `Entrada` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EspeciesEmpleado`
--

DROP TABLE IF EXISTS `EspeciesEmpleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EspeciesEmpleado` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_99362E68BF396750` FOREIGN KEY (`id`) REFERENCES `mov_empleado` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EspeciesEmpleado`
--

LOCK TABLES `EspeciesEmpleado` WRITE;
/*!40000 ALTER TABLE `EspeciesEmpleado` DISABLE KEYS */;
/*!40000 ALTER TABLE `EspeciesEmpleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EtiquetaAgenda`
--

DROP TABLE IF EXISTS `EtiquetaAgenda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EtiquetaAgenda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `etiqueta` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `color` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EtiquetaAgenda`
--

LOCK TABLES `EtiquetaAgenda` WRITE;
/*!40000 ALTER TABLE `EtiquetaAgenda` DISABLE KEYS */;
/*!40000 ALTER TABLE `EtiquetaAgenda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GrupoCliente`
--

DROP TABLE IF EXISTS `GrupoCliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GrupoCliente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GrupoCliente`
--

LOCK TABLES `GrupoCliente` WRITE;
/*!40000 ALTER TABLE `GrupoCliente` DISABLE KEYS */;
INSERT INTO `GrupoCliente` VALUES (1,'Clientes exclusivos',NULL,'activo');
/*!40000 ALTER TABLE `GrupoCliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GrupoMesa`
--

DROP TABLE IF EXISTS `GrupoMesa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GrupoMesa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GrupoMesa`
--

LOCK TABLES `GrupoMesa` WRITE;
/*!40000 ALTER TABLE `GrupoMesa` DISABLE KEYS */;
/*!40000 ALTER TABLE `GrupoMesa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Image`
--

DROP TABLE IF EXISTS `Image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Image`
--

LOCK TABLES `Image` WRITE;
/*!40000 ALTER TABLE `Image` DISABLE KEYS */;
INSERT INTO `Image` VALUES (2,'50b9bc8b5162b0537c3d7b50b84990dc3a622db6','50b9bc8b5162b0537c3d7b50b84990dc3a622db6.jpeg'),(4,'98bf2245aae0b181b42f76fb011d61414793cfae','98bf2245aae0b181b42f76fb011d61414793cfae.jpeg'),(6,'c846ac1c5f35b752c0f15bb3001b67cb853f4ed0','c846ac1c5f35b752c0f15bb3001b67cb853f4ed0.jpeg'),(8,'2078996f0ec9106cab5627831902aa479efb7df1','2078996f0ec9106cab5627831902aa479efb7df1.jpeg'),(10,NULL,NULL),(12,'25f97ce174039d3ef141093fd67f1b697d32c80f','25f97ce174039d3ef141093fd67f1b697d32c80f.jpeg'),(14,'6f12a7c66c8041e38c9a52076abc8b185321a374','6f12a7c66c8041e38c9a52076abc8b185321a374.jpeg'),(16,'f6649d2063b860363625c1ecf85ef55463b36c1c','f6649d2063b860363625c1ecf85ef55463b36c1c.jpeg'),(18,'8159505d69f598031151ebf3be13d58321de25e7','8159505d69f598031151ebf3be13d58321de25e7.jpeg'),(20,'6791015770e5d05530ba7c000ff0b400f705bfcf','6791015770e5d05530ba7c000ff0b400f705bfcf.jpeg'),(22,'e1b66a4f1bac35461d988c8ebfb7cff7d7f38654','e1b66a4f1bac35461d988c8ebfb7cff7d7f38654.jpeg'),(24,NULL,NULL);
/*!40000 ALTER TABLE `Image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Ingrediente`
--

DROP TABLE IF EXISTS `Ingrediente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Ingrediente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tasa_id` int(11) DEFAULT NULL,
  `productoproduccion_id` int(11) NOT NULL,
  `plato_id` int(11) DEFAULT NULL,
  `cantidad` decimal(10,2) DEFAULT NULL,
  `precioCosto` decimal(10,2) DEFAULT NULL,
  `coeficiente` decimal(10,6) DEFAULT NULL,
  `obligatorio` tinyint(1) NOT NULL,
  `preElaborado_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_39282BC9E20BE1E2` (`tasa_id`),
  KEY `IDX_39282BC93F84EE79` (`productoproduccion_id`),
  KEY `IDX_39282BC9508F408D` (`preElaborado_id`),
  KEY `IDX_39282BC9B0DB09EF` (`plato_id`),
  CONSTRAINT `FK_39282BC93F84EE79` FOREIGN KEY (`productoproduccion_id`) REFERENCES `ProductoProduccion` (`id`),
  CONSTRAINT `FK_39282BC9508F408D` FOREIGN KEY (`preElaborado_id`) REFERENCES `PreElaborado` (`id`),
  CONSTRAINT `FK_39282BC9B0DB09EF` FOREIGN KEY (`plato_id`) REFERENCES `Plato` (`id`),
  CONSTRAINT `FK_39282BC9E20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Ingrediente`
--

LOCK TABLES `Ingrediente` WRITE;
/*!40000 ALTER TABLE `Ingrediente` DISABLE KEYS */;
INSERT INTO `Ingrediente` VALUES (1,2,4,2,200.00,2.10,0.001000,1,NULL),(2,1,5,2,2.00,24.00,1.000000,0,NULL),(3,2,12,2,50.00,0.50,0.001000,0,NULL);
/*!40000 ALTER TABLE `Ingrediente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IngresoEmpleado`
--

DROP TABLE IF EXISTS `IngresoEmpleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IngresoEmpleado` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_6D473EC8BF396750` FOREIGN KEY (`id`) REFERENCES `mov_empleado` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IngresoEmpleado`
--

LOCK TABLES `IngresoEmpleado` WRITE;
/*!40000 ALTER TABLE `IngresoEmpleado` DISABLE KEYS */;
INSERT INTO `IngresoEmpleado` VALUES (1);
/*!40000 ALTER TABLE `IngresoEmpleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ItemCierre`
--

DROP TABLE IF EXISTS `ItemCierre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ItemCierre` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cierre_id` int(11) DEFAULT NULL,
  `importeSistema` decimal(10,2) DEFAULT NULL,
  `importeReal` decimal(10,2) DEFAULT NULL,
  `tipoCobro_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_38B20D6DC5CD756B` (`cierre_id`),
  KEY `IDX_38B20D6DE414003F` (`tipoCobro_id`),
  CONSTRAINT `FK_38B20D6DC5CD756B` FOREIGN KEY (`cierre_id`) REFERENCES `Cierre` (`id`),
  CONSTRAINT `FK_38B20D6DE414003F` FOREIGN KEY (`tipoCobro_id`) REFERENCES `TipoCobro` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ItemCierre`
--

LOCK TABLES `ItemCierre` WRITE;
/*!40000 ALTER TABLE `ItemCierre` DISABLE KEYS */;
INSERT INTO `ItemCierre` VALUES (1,19,428.50,428.50,1),(2,19,19.08,19.08,3),(3,26,193.60,193.60,1),(4,26,0.00,0.00,3),(5,38,642.60,642.60,1),(6,38,18.00,18.00,3),(7,106,3072.65,3072.00,1),(8,106,529.80,529.80,3),(9,106,0.00,0.00,4);
/*!40000 ALTER TABLE `ItemCierre` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ItemDescuentoPedido`
--

DROP TABLE IF EXISTS `ItemDescuentoPedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ItemDescuentoPedido` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descuento_id` int(11) DEFAULT NULL,
  `pedido_id` int(11) DEFAULT NULL,
  `totalDescuento` decimal(10,2) NOT NULL,
  `detalle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_27B4A4EEF045077C` (`descuento_id`),
  KEY `IDX_27B4A4EE4854653A` (`pedido_id`),
  CONSTRAINT `FK_27B4A4EE4854653A` FOREIGN KEY (`pedido_id`) REFERENCES `Pedido` (`id`),
  CONSTRAINT `FK_27B4A4EEF045077C` FOREIGN KEY (`descuento_id`) REFERENCES `DescuentoCliente` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ItemDescuentoPedido`
--

LOCK TABLES `ItemDescuentoPedido` WRITE;
/*!40000 ALTER TABLE `ItemDescuentoPedido` DISABLE KEYS */;
INSERT INTO `ItemDescuentoPedido` VALUES (1,1,1,15.93,'Cliente exclusivo'),(2,1,3,11.31,'Cliente exclusivo'),(3,1,4,15.93,'Cliente exclusivo'),(4,1,7,30.00,'Cliente exclusivo'),(5,1,9,30.00,'Cliente exclusivo'),(6,1,10,44.80,'Cliente exclusivo'),(7,1,11,0.00,'Cliente exclusivo'),(8,1,12,32.95,'Cliente exclusivo'),(9,1,NULL,44.50,'Cliente exclusivo'),(10,1,15,37.70,'Cliente exclusivo'),(11,1,16,33.85,'Cliente exclusivo'),(12,1,18,100.00,'Cliente exclusivo'),(13,1,21,0.00,'Cliente exclusivo'),(14,1,22,0.00,'Cliente exclusivo'),(15,1,29,0.00,'Cliente exclusivo');
/*!40000 ALTER TABLE `ItemDescuentoPedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ItemDescuentoVenta`
--

DROP TABLE IF EXISTS `ItemDescuentoVenta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ItemDescuentoVenta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descuento_id` int(11) DEFAULT NULL,
  `venta_id` int(11) DEFAULT NULL,
  `totalDescuento` decimal(10,2) DEFAULT NULL,
  `detalle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `porcentaje` decimal(10,2) DEFAULT NULL,
  `totalDescuentoSinIva` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_B45EDCDDF045077C` (`descuento_id`),
  KEY `IDX_B45EDCDDF2A5805D` (`venta_id`),
  CONSTRAINT `FK_B45EDCDDF045077C` FOREIGN KEY (`descuento_id`) REFERENCES `DescuentoCliente` (`id`),
  CONSTRAINT `FK_B45EDCDDF2A5805D` FOREIGN KEY (`venta_id`) REFERENCES `Venta` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ItemDescuentoVenta`
--

LOCK TABLES `ItemDescuentoVenta` WRITE;
/*!40000 ALTER TABLE `ItemDescuentoVenta` DISABLE KEYS */;
INSERT INTO `ItemDescuentoVenta` VALUES (1,1,1,44.80,'Cliente exclusivo',0.00,0.00),(2,1,3,30.00,'Cliente exclusivo',0.00,0.00),(3,1,5,30.00,'Cliente exclusivo',0.00,0.00),(4,1,6,15.93,'Cliente exclusivo',0.00,0.00),(5,1,11,32.95,'Cliente exclusivo',0.00,0.00),(6,1,14,37.70,'Cliente exclusivo',0.00,0.00),(7,1,15,33.85,'Cliente exclusivo',0.00,0.00),(8,1,19,0.00,'Cliente exclusivo',0.00,0.00),(9,1,20,0.00,'Cliente exclusivo',0.00,0.00),(10,1,24,100.00,'Cliente exclusivo',0.00,0.00),(11,1,30,44.50,'Descuento por zzzz',50.00,36.78),(14,1,34,26.50,'Descuento por zzzz',50.00,21.90),(15,1,34,NULL,'Descuento por zzzz',50.00,NULL),(16,1,35,24.00,'Descuento por zzzz',50.00,19.84),(17,1,35,NULL,'Descuento por zzzz',50.00,NULL),(18,1,36,26.50,'Descuento por zzzz',50.00,21.90),(19,1,36,NULL,'Descuento por zzzz',50.00,NULL),(20,1,37,26.50,'Descuento por zzzz',50.00,21.90),(21,1,37,NULL,'Descuento por zzzz',50.00,NULL),(22,1,38,26.50,'Descuento por zzzz',50.00,21.90),(23,1,38,NULL,'Descuento por zzzz',50.00,NULL),(24,1,39,35.50,'Descuento por zzzz',50.00,29.34),(25,1,39,NULL,'Descuento por zzzz',50.00,NULL),(26,1,59,57.95,'Descuento por zzzz',50.00,47.89),(27,1,59,NULL,'Descuento por zzzz',50.00,NULL),(28,1,62,24.00,'Descuento por zzzz',50.00,19.84),(29,1,62,NULL,'Descuento por zzzz',50.00,NULL),(30,1,64,20.25,'Descuento por buen cliente',50.00,16.74),(31,1,64,NULL,'Descuento por buen cliente',50.00,NULL),(32,1,65,20.25,'Descuento por buen cliente',50.00,16.74),(33,1,65,NULL,'Descuento por buen cliente',50.00,NULL),(34,1,69,5.25,'Descuento por buen cliente',50.00,4.34),(35,1,69,NULL,'Descuento por buen cliente',50.00,NULL),(36,1,70,15.00,'Descuento por buen cliente',50.00,12.40),(37,1,70,NULL,'Descuento por buen cliente',50.00,NULL);
/*!40000 ALTER TABLE `ItemDescuentoVenta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ItemIvaVenta`
--

DROP TABLE IF EXISTS `ItemIvaVenta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ItemIvaVenta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iva_id` int(11) DEFAULT NULL,
  `venta_id` int(11) DEFAULT NULL,
  `tasa` decimal(10,3) DEFAULT NULL,
  `total` decimal(10,3) DEFAULT NULL,
  `gravado` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_F0C015DCF231661A` (`iva_id`),
  KEY `IDX_F0C015DCF2A5805D` (`venta_id`),
  CONSTRAINT `FK_F0C015DCF231661A` FOREIGN KEY (`iva_id`) REFERENCES `iva` (`id`),
  CONSTRAINT `FK_F0C015DCF2A5805D` FOREIGN KEY (`venta_id`) REFERENCES `Venta` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ItemIvaVenta`
--

LOCK TABLES `ItemIvaVenta` WRITE;
/*!40000 ALTER TABLE `ItemIvaVenta` DISABLE KEYS */;
INSERT INTO `ItemIvaVenta` VALUES (1,1,30,21.000,7.723,1),(2,1,34,21.000,4.599,1),(3,1,35,21.000,4.165,1),(4,1,36,21.000,4.599,1),(5,1,37,21.000,4.599,1),(6,1,38,21.000,4.599,1),(7,1,39,21.000,6.161,1),(8,1,40,21.000,12.322,1),(9,1,41,21.000,12.322,1),(10,1,42,21.000,9.198,1),(11,1,43,21.000,9.198,1),(12,1,44,21.000,9.198,1),(13,1,45,21.000,12.322,1),(14,1,47,21.000,12.322,1),(15,1,48,21.000,12.322,1),(16,1,51,21.000,11.455,1),(17,1,53,21.000,11.455,1),(18,1,54,21.000,11.455,1),(19,1,56,21.000,11.455,1),(20,1,57,21.000,10.413,1),(21,1,58,21.000,16.488,1),(22,1,59,21.000,10.057,1),(23,1,60,21.000,3.992,1),(24,1,61,21.000,11.107,1),(25,1,62,21.000,4.165,1),(26,1,63,21.000,7.029,1),(27,1,64,21.000,3.514,1),(28,1,65,21.000,3.514,1),(29,1,66,21.000,5.207,1),(30,1,67,21.000,1.822,1),(31,1,68,21.000,7.029,1),(32,1,69,21.000,0.911,1),(33,1,70,21.000,2.603,1),(34,1,71,21.000,2.083,1),(35,1,72,21.000,2.083,1),(36,1,73,21.000,5.623,1),(37,1,74,21.000,8.331,1),(38,1,75,21.000,10.830,1),(39,1,76,21.000,5.207,1),(40,1,77,21.000,3.992,1),(41,1,78,21.000,3.992,1),(42,1,79,21.000,1.909,1),(43,1,80,21.000,5.901,1),(44,1,81,21.000,5.901,1);
/*!40000 ALTER TABLE `ItemIvaVenta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ItemLIV`
--

DROP TABLE IF EXISTS `ItemLIV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ItemLIV` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `liv_id` int(11) DEFAULT NULL,
  `tasa` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `gravado` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9EE103C98D8298DC` (`liv_id`),
  CONSTRAINT `FK_9EE103C98D8298DC` FOREIGN KEY (`liv_id`) REFERENCES `LibroIvaVenta` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ItemLIV`
--

LOCK TABLES `ItemLIV` WRITE;
/*!40000 ALTER TABLE `ItemLIV` DISABLE KEYS */;
INSERT INTO `ItemLIV` VALUES (1,1,21.00,40.26,1),(2,1,15.00,0.00,1),(3,2,21.00,19.09,1),(4,2,15.00,0.00,1),(5,3,21.00,5.73,1),(6,3,15.00,0.00,1),(7,4,21.00,3.99,1),(8,4,15.00,0.00,1),(9,5,21.00,5.73,1),(10,5,15.00,0.00,1),(11,6,21.00,5.73,1),(12,6,15.00,0.00,1),(13,7,21.00,15.45,1),(14,7,15.00,0.00,1),(15,8,21.00,21.17,1),(16,8,15.00,0.00,1),(17,9,21.00,3.99,1),(18,9,15.00,0.00,1),(19,10,21.00,14.23,1),(20,10,15.00,0.00,1),(21,11,21.00,12.32,1),(22,11,15.00,0.00,1),(23,12,21.00,3.82,1),(24,12,15.00,0.00,1),(25,13,21.00,3.99,1),(26,13,15.00,0.00,1),(27,14,21.00,3.12,1),(28,14,15.00,0.00,1),(29,15,21.00,3.12,1),(30,15,15.00,0.00,1);
/*!40000 ALTER TABLE `ItemLIV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ItemPedido`
--

DROP TABLE IF EXISTS `ItemPedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ItemPedido` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tasa_id` int(11) DEFAULT NULL,
  `productoventa_id` int(11) DEFAULT NULL,
  `pedido_id` int(11) DEFAULT NULL,
  `precioUnitario` decimal(10,2) DEFAULT NULL,
  `descuento` decimal(10,2) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `cantidad` double DEFAULT NULL,
  `consideraciones` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaHora` datetime DEFAULT NULL,
  `vinculado` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_2C82E764E20BE1E2` (`tasa_id`),
  KEY `IDX_2C82E76417242A18` (`productoventa_id`),
  KEY `IDX_2C82E7644854653A` (`pedido_id`),
  CONSTRAINT `FK_2C82E76417242A18` FOREIGN KEY (`productoventa_id`) REFERENCES `ProductoVenta` (`id`),
  CONSTRAINT `FK_2C82E7644854653A` FOREIGN KEY (`pedido_id`) REFERENCES `Pedido` (`id`),
  CONSTRAINT `FK_2C82E764E20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=224 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ItemPedido`
--

LOCK TABLES `ItemPedido` WRITE;
/*!40000 ALTER TABLE `ItemPedido` DISABLE KEYS */;
INSERT INTO `ItemPedido` VALUES (1,1,1,1,11.00,30.00,11.00,1,NULL,'Listo',NULL,1),(2,1,1,2,11.00,30.00,11.00,1,NULL,'Listo',NULL,1),(3,1,1,2,11.00,30.00,11.00,1,NULL,'Listo',NULL,1),(4,1,1,3,11.00,30.00,11.00,1,NULL,'Listo',NULL,1),(5,1,1,NULL,11.00,30.00,11.00,1,NULL,'nuevo',NULL,NULL),(6,1,1,NULL,11.00,30.00,11.00,1,NULL,'nuevo',NULL,NULL),(7,1,1,NULL,11.00,30.00,11.00,1,NULL,'nuevo',NULL,NULL),(8,1,1,4,11.00,30.00,11.00,1,NULL,'Listo',NULL,1),(9,1,1,4,11.00,30.00,11.00,1,NULL,'Listo',NULL,1),(10,1,1,4,11.00,30.00,11.00,1,NULL,'Listo',NULL,1),(11,1,1,5,11.00,30.00,11.00,1,NULL,'Listo',NULL,1),(12,1,1,5,11.00,30.00,11.00,1,NULL,'Listo',NULL,1),(13,1,1,5,11.00,30.00,11.00,1,NULL,'Listo',NULL,1),(14,1,1,6,11.00,30.00,11.00,1,NULL,'Listo',NULL,1),(15,1,1,6,11.00,30.00,11.00,1,NULL,'Listo',NULL,1),(16,1,1,6,11.00,30.00,11.00,1,NULL,'Listo',NULL,1),(17,1,1,7,11.00,30.00,110.00,10,NULL,'Listo',NULL,1),(18,1,1,8,11.00,30.00,11.00,1,NULL,'Listo',NULL,1),(19,1,2,8,12.00,30.00,12.00,1,NULL,'Listo',NULL,1),(20,1,2,9,12.00,30.00,12.00,1,NULL,'Listo',NULL,1),(21,1,1,9,11.00,30.00,220.00,20,NULL,'Listo',NULL,1),(22,1,1,10,11.00,30.00,44.00,4,NULL,'Listo',NULL,1),(23,1,2,10,12.00,30.00,84.00,7,NULL,'Listo',NULL,1),(24,1,1,11,11.00,30.00,11.00,1,NULL,'Listo',NULL,1),(25,1,2,11,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(26,1,2,12,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(27,1,1,12,11.00,30.00,77.00,7,NULL,'Listo',NULL,1),(28,1,1,13,11.00,30.00,110.00,10,NULL,'Listo',NULL,1),(29,1,2,13,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(30,1,1,14,11.00,30.00,11.00,1,NULL,'Listo',NULL,1),(31,1,2,14,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(32,1,1,15,11.00,30.00,11.00,1,NULL,'Listo',NULL,1),(33,1,1,15,11.00,30.00,11.00,1,NULL,'Listo',NULL,1),(34,1,2,15,12.00,0.00,60.00,5,NULL,'Listo',NULL,1),(35,1,1,16,11.00,30.00,11.00,1,NULL,'Listo',NULL,1),(36,1,2,16,12.00,0.00,60.00,5,NULL,'Listo',NULL,1),(37,1,1,17,11.00,30.00,11.00,1,NULL,'Listo',NULL,1),(38,1,2,17,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(39,1,3,18,18.00,0.00,18.00,1,NULL,'cancelado',NULL,NULL),(40,1,3,18,18.00,0.00,18.00,1,NULL,'cancelado',NULL,NULL),(41,1,3,18,18.00,0.00,360.00,20,NULL,'Listo',NULL,NULL),(42,1,3,19,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(43,1,3,20,18.00,0.00,360.00,20,NULL,'Listo',NULL,NULL),(44,1,3,21,18.00,0.00,126.00,7,NULL,'cancelado',NULL,NULL),(45,1,3,21,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(46,1,3,22,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(47,1,1,22,11.00,30.00,11.00,1,NULL,'cancelado',NULL,NULL),(48,1,1,23,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(49,1,2,23,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(50,1,3,24,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(51,1,1,24,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(52,1,1,25,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(53,1,2,25,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(54,1,2,26,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(55,1,3,26,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(56,1,1,27,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(57,1,3,27,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(58,1,3,28,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(59,1,3,28,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(60,1,3,29,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(61,1,3,30,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(62,1,3,30,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(63,1,1,31,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(64,1,2,31,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(65,1,1,32,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(66,1,2,32,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(67,1,1,33,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(68,1,2,33,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(69,1,1,34,11.00,0.00,33.00,3,NULL,'Listo',NULL,1),(70,1,2,NULL,12.00,0.00,12.00,1,NULL,'nuevo',NULL,NULL),(71,1,1,35,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(72,1,2,35,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(73,1,3,NULL,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(74,1,3,NULL,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(75,1,3,35,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(76,1,3,35,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(77,1,1,36,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(78,1,2,36,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(79,1,1,37,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(80,1,2,37,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(81,1,3,38,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(82,1,1,39,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(83,1,2,39,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(84,1,1,40,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(85,1,2,40,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(86,1,1,41,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(87,1,2,41,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(88,1,1,42,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(89,1,2,42,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(90,1,3,42,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(91,1,1,43,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(92,1,2,43,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(93,1,3,43,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(94,1,1,44,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(95,1,2,44,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(96,1,3,44,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(97,1,1,45,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(98,1,2,45,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(99,1,1,46,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(100,1,2,46,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(101,1,1,47,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(102,1,2,47,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(103,1,1,48,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(104,1,2,48,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(105,1,3,48,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(106,1,3,49,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(107,1,1,49,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(108,1,2,49,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(109,1,1,50,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(110,1,2,50,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(111,1,3,50,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(112,1,3,51,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(113,1,3,51,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(114,1,3,52,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(115,1,3,52,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(116,1,3,53,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(117,1,2,54,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(118,1,3,54,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(119,1,1,55,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(120,1,3,55,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(121,1,2,55,12.00,0.00,36.00,3,NULL,'Listo',NULL,1),(122,1,1,56,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(123,1,2,56,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(124,1,3,57,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(125,1,1,58,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(126,1,9,58,12.00,0.00,12.00,1,NULL,'Listo',NULL,NULL),(127,1,1,59,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(128,1,11,59,23.00,0.00,23.00,1,NULL,'Listo',NULL,1),(129,1,3,59,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(130,1,9,59,12.00,0.00,12.00,1,NULL,'Listo',NULL,NULL),(131,1,2,59,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(132,1,6,59,20.40,0.00,20.40,1,NULL,'Listo',NULL,1),(133,1,7,59,19.50,0.00,19.50,1,NULL,'Listo',NULL,1),(134,1,1,60,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(135,1,11,60,23.00,0.00,23.00,1,NULL,'Listo',NULL,1),(136,1,1,61,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(137,1,11,61,23.00,0.00,23.00,1,NULL,'Listo',NULL,1),(138,1,1,62,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(139,1,11,62,23.00,0.00,23.00,1,NULL,'Listo',NULL,1),(140,1,3,63,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(141,1,2,63,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(142,1,6,63,20.40,0.00,20.40,1,NULL,'Listo',NULL,1),(143,1,1,64,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(144,1,11,64,23.00,0.00,23.00,1,NULL,'Listo',NULL,1),(145,1,1,65,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(146,1,11,65,23.00,0.00,23.00,1,NULL,'Listo',NULL,1),(147,1,2,65,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(148,1,1,66,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(149,1,10,66,10.50,0.00,10.50,1,NULL,'Listo',NULL,NULL),(150,1,3,67,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(151,1,9,67,12.00,0.00,12.00,1,NULL,'Listo',NULL,NULL),(152,1,10,67,10.50,0.00,10.50,1,NULL,'Listo',NULL,NULL),(153,1,3,68,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(154,1,9,68,12.00,0.00,12.00,1,NULL,'Listo',NULL,NULL),(155,1,10,68,10.50,0.00,10.50,1,NULL,'Listo',NULL,NULL),(156,1,3,69,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(157,1,9,69,12.00,0.00,12.00,1,NULL,'Listo',NULL,NULL),(158,1,10,69,10.50,0.00,10.50,1,NULL,'Listo',NULL,NULL),(159,1,3,70,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(160,1,9,70,12.00,0.00,12.00,1,NULL,'Listo',NULL,NULL),(161,1,10,71,10.50,0.00,10.50,1,NULL,'Listo',NULL,NULL),(162,1,3,72,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(163,1,9,72,12.00,0.00,12.00,1,NULL,'Listo',NULL,NULL),(164,1,10,72,10.50,0.00,10.50,1,NULL,'Listo',NULL,NULL),(165,1,10,73,10.50,0.00,10.50,1,NULL,'Listo',NULL,NULL),(166,1,3,74,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(167,1,9,74,12.00,0.00,12.00,1,NULL,'Listo',NULL,NULL),(168,1,9,75,12.00,0.00,12.00,1,NULL,'Listo',NULL,NULL),(169,1,2,76,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(170,1,6,77,20.40,0.00,20.40,1,NULL,'Listo',NULL,1),(171,1,2,77,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(172,1,9,78,12.00,0.00,12.00,1,NULL,'Listo',NULL,NULL),(173,1,2,78,12.00,0.00,24.00,2,NULL,'Listo',NULL,1),(174,1,2,78,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(175,1,9,79,12.00,0.00,12.00,1,NULL,'Listo',NULL,NULL),(176,1,9,63,12.00,0.00,12.00,1,NULL,'Listo',NULL,NULL),(177,1,3,80,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(178,1,9,80,12.00,0.00,12.00,1,NULL,'Listo',NULL,NULL),(179,1,3,81,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(180,1,9,81,12.00,0.00,12.00,1,NULL,'Listo',NULL,NULL),(181,1,10,82,10.50,0.00,10.50,1,NULL,'Listo',NULL,NULL),(182,1,2,82,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(183,1,2,82,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(184,1,1,84,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(185,1,2,85,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(186,1,7,81,19.50,0.00,19.50,1,NULL,'cancelado',NULL,NULL),(187,4,8,81,23.00,0.00,23.00,1,NULL,'Listo',NULL,1),(188,4,8,81,23.00,0.00,23.00,1,NULL,'Listo',NULL,1),(189,4,8,81,23.00,0.00,23.00,1,NULL,'Listo',NULL,1),(190,4,8,81,23.00,0.00,23.00,1,NULL,'Listo',NULL,1),(191,4,8,81,23.00,0.00,23.00,1,NULL,'Listo',NULL,1),(192,4,8,81,23.00,0.00,23.00,1,NULL,'Listo',NULL,1),(193,4,8,81,23.00,0.00,23.00,1,NULL,'Listo',NULL,1),(194,4,8,81,23.00,0.00,23.00,1,NULL,'Listo',NULL,1),(195,4,8,81,23.00,0.00,23.00,1,NULL,'Listo',NULL,1),(196,4,8,81,23.00,0.00,23.00,1,NULL,'cancelado',NULL,NULL),(197,4,8,81,23.00,0.00,23.00,1,NULL,'cancelado',NULL,NULL),(198,4,8,81,23.00,0.00,23.00,1,NULL,'cancelado',NULL,NULL),(199,4,8,81,23.00,0.00,23.00,1,'que sepa tejer','Listo',NULL,1),(200,4,8,81,23.00,0.00,23.00,1,NULL,'cancelado',NULL,NULL),(201,4,8,81,23.00,0.00,23.00,1,NULL,'cancelado',NULL,NULL),(202,1,1,86,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(203,1,11,86,23.00,0.00,23.00,1,NULL,'Listo',NULL,1),(204,1,2,87,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(205,1,1,88,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(206,1,11,88,23.00,0.00,23.00,1,NULL,'Listo',NULL,1),(207,1,9,88,12.00,0.00,12.00,1,NULL,'Listo',NULL,NULL),(208,1,1,89,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(209,1,1,90,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(210,1,11,90,23.00,0.00,23.00,1,NULL,'Listo',NULL,1),(211,1,1,91,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(212,1,11,91,23.00,0.00,23.00,1,NULL,'Listo',NULL,1),(213,1,1,92,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(214,1,11,92,23.00,0.00,23.00,1,NULL,'Listo',NULL,1),(215,1,2,93,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(216,1,2,94,12.00,0.00,12.00,1,NULL,'cancelado',NULL,NULL),(217,1,2,94,12.00,0.00,12.00,1,NULL,'Listo',NULL,1),(218,1,1,95,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(219,1,1,96,11.00,0.00,11.00,1,NULL,'Listo',NULL,1),(220,1,11,96,23.00,0.00,23.00,1,NULL,'Listo',NULL,1),(221,1,3,96,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(222,1,3,97,18.00,0.00,18.00,1,NULL,'Listo',NULL,NULL),(223,1,9,97,12.00,0.00,12.00,1,NULL,'Listo',NULL,NULL);
/*!40000 ALTER TABLE `ItemPedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ItemRecargoPedido`
--

DROP TABLE IF EXISTS `ItemRecargoPedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ItemRecargoPedido` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recargo_id` int(11) DEFAULT NULL,
  `pedido_id` int(11) DEFAULT NULL,
  `totalRecargo` decimal(10,2) NOT NULL,
  `detalle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_91E521E3E3DAE5D1` (`recargo_id`),
  KEY `IDX_91E521E34854653A` (`pedido_id`),
  CONSTRAINT `FK_91E521E34854653A` FOREIGN KEY (`pedido_id`) REFERENCES `Pedido` (`id`),
  CONSTRAINT `FK_91E521E3E3DAE5D1` FOREIGN KEY (`recargo_id`) REFERENCES `Recargo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ItemRecargoPedido`
--

LOCK TABLES `ItemRecargoPedido` WRITE;
/*!40000 ALTER TABLE `ItemRecargoPedido` DISABLE KEYS */;
INSERT INTO `ItemRecargoPedido` VALUES (1,1,1,30.00,'Recargo'),(2,1,2,30.00,'Recargo'),(3,1,3,30.00,'Recargo'),(4,1,4,30.00,'Recargo'),(5,1,11,30.00,'Recargo'),(6,1,22,30.00,'Recargo'),(7,1,24,30.00,'Recargo'),(8,1,25,30.00,'Recargo'),(9,1,26,30.00,'Recargo'),(10,1,27,30.00,'Recargo'),(11,1,28,30.00,'Recargo'),(12,1,29,30.00,'Recargo');
/*!40000 ALTER TABLE `ItemRecargoPedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ItemRecargoVenta`
--

DROP TABLE IF EXISTS `ItemRecargoVenta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ItemRecargoVenta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recargo_id` int(11) DEFAULT NULL,
  `venta_id` int(11) DEFAULT NULL,
  `totalRecargo` decimal(10,2) NOT NULL,
  `detalle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `porcentaje` decimal(10,2) DEFAULT NULL,
  `tasaIva` decimal(10,2) NOT NULL,
  `totalRecargoSinIva` decimal(10,2) NOT NULL,
  `iva_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_83F6ECE2E3DAE5D1` (`recargo_id`),
  KEY `IDX_83F6ECE2F2A5805D` (`venta_id`),
  KEY `IDX_83F6ECE2F231661A` (`iva_id`),
  CONSTRAINT `FK_83F6ECE2E3DAE5D1` FOREIGN KEY (`recargo_id`) REFERENCES `Recargo` (`id`),
  CONSTRAINT `FK_83F6ECE2F231661A` FOREIGN KEY (`iva_id`) REFERENCES `iva` (`id`),
  CONSTRAINT `FK_83F6ECE2F2A5805D` FOREIGN KEY (`venta_id`) REFERENCES `Venta` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ItemRecargoVenta`
--

LOCK TABLES `ItemRecargoVenta` WRITE;
/*!40000 ALTER TABLE `ItemRecargoVenta` DISABLE KEYS */;
INSERT INTO `ItemRecargoVenta` VALUES (1,1,6,30.00,'Recargo',0.00,0.00,0.00,NULL),(2,1,17,30.00,'Recargo',0.00,0.00,0.00,NULL),(3,1,20,30.00,'Recargo',0.00,0.00,0.00,NULL),(4,1,25,30.00,'Recargo',0.00,0.00,0.00,NULL),(5,1,26,30.00,'Recargo',0.00,0.00,0.00,NULL),(6,1,27,30.00,'Recargo',0.00,0.00,0.00,NULL),(7,1,28,30.00,'Recargo',0.00,0.00,0.00,NULL),(8,1,30,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(13,1,34,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(14,1,34,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(15,1,35,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(16,1,35,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(17,1,36,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(18,1,36,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(19,1,37,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(20,1,37,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(21,1,38,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(22,1,38,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(23,1,39,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(24,1,39,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(25,1,40,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(26,1,40,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(27,1,41,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(28,1,41,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(29,1,42,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(30,1,43,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(31,1,44,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(32,1,45,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(33,1,47,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(34,1,48,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(35,1,51,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(36,1,53,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(37,1,54,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(38,1,56,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(39,1,57,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(40,1,58,30.00,'Recargo por que se me canta',NULL,21.00,24.79,1),(41,1,61,30.00,'Recargo por envio',NULL,21.00,24.79,1),(42,1,62,30.00,'Recargo por envio',NULL,21.00,24.79,1);
/*!40000 ALTER TABLE `ItemRecargoVenta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LibroIvaVenta`
--

DROP TABLE IF EXISTS `LibroIvaVenta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LibroIvaVenta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) DEFAULT NULL,
  `venta_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `tipo` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `cuit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `razonSocial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `neto` decimal(10,3) DEFAULT NULL,
  `acrecent` decimal(10,3) DEFAULT NULL,
  `total` decimal(10,3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_16A0DA06F2A5805D` (`venta_id`),
  KEY `IDX_16A0DA06DE734E51` (`cliente_id`),
  KEY `IDX_16A0DA06521E1991` (`empresa_id`),
  CONSTRAINT `FK_16A0DA06521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_16A0DA06DE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Cliente` (`id`),
  CONSTRAINT `FK_16A0DA06F2A5805D` FOREIGN KEY (`venta_id`) REFERENCES `Venta` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LibroIvaVenta`
--

LOCK TABLES `LibroIvaVenta` WRITE;
/*!40000 ALTER TABLE `LibroIvaVenta` DISABLE KEYS */;
INSERT INTO `LibroIvaVenta` VALUES (1,1,3,1,'2013-10-21 00:00:00','A',NULL,'Herrera, Fernando Martin',-40.264,0.000,NULL),(2,1,5,1,'2013-10-21 00:00:00','A',NULL,'Herrera, Fernando Martin',-19.091,0.000,NULL),(3,1,6,1,'2013-10-21 00:00:00','A',NULL,'Herrera, Fernando Martin',-5.727,0.000,NULL),(4,2,7,1,'2013-10-21 00:00:00','A',NULL,'Herrera, Horacio',-3.992,0.000,NULL),(5,2,9,1,'2013-10-21 00:00:00','B',NULL,'Herrera, Horacio',-5.727,0.000,NULL),(6,2,10,1,'2013-10-21 00:00:00','B',NULL,'Herrera, Horacio',-5.727,0.000,NULL),(7,1,11,1,'2013-10-21 00:00:00','A',NULL,'Herrera, Fernando Martin',129.604,0.000,145.050),(8,1,12,1,'2013-10-21 00:00:00','A',NULL,'Herrera, Fernando Martin',75.442,0.000,96.615),(9,2,13,1,'2013-10-21 00:00:00','B',NULL,'Herrera, Horacio',16.470,0.000,20.462),(10,1,14,1,'2013-10-21 00:00:00','B',NULL,'Herrera, Fernando Martin',98.869,0.000,113.100),(11,1,15,1,'2013-10-21 00:00:00','A',NULL,'Herrera, Fernando Martin',21.528,0.000,33.850),(12,NULL,17,1,'2013-10-21 00:00:00','B',NULL,'Consumidor Final',41.582,0.000,45.400),(13,2,18,1,'2013-10-21 00:00:00','A',NULL,'Herrera, Horacio',15.708,0.000,19.700),(14,1,19,1,'2013-10-21 00:00:00','A',NULL,'Herrera, Fernando Martin',14.876,0.000,18.000),(15,1,20,1,'2013-10-21 00:00:00','A',NULL,'Herrera, Fernando Martin',44.876,0.000,48.000),(16,2,21,1,'2013-10-21 00:00:00','C',NULL,'Herrera, Horacio',297.521,0.000,360.000),(17,NULL,22,1,'2013-10-21 00:00:00','C',NULL,'Consumidor Final',19.008,0.000,23.000),(18,2,23,1,'2013-10-21 00:00:00','C',NULL,'Herrera, Horacio',14.876,0.000,18.000),(19,1,24,1,'2013-10-22 00:00:00','C',NULL,'Herrera, Fernando Martin',197.521,0.000,260.000),(20,3,25,1,'2013-10-22 00:00:00','C',NULL,'Aquino, Ramona',49.008,0.000,53.000),(21,3,26,1,'2013-10-22 00:00:00','C',NULL,'Aquino, Ramona',54.793,0.000,60.000),(22,3,27,1,'2013-10-22 00:00:00','C',NULL,'Aquino, Ramona',53.967,0.000,59.000),(23,3,28,1,'2013-10-22 00:00:00','C',NULL,'Aquino, Ramona',59.752,0.000,66.000);
/*!40000 ALTER TABLE `LibroIvaVenta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LineaTanda`
--

DROP TABLE IF EXISTS `LineaTanda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LineaTanda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tanda_id` int(11) DEFAULT NULL,
  `cantidad` double DEFAULT NULL,
  `cantidadElaborados` double DEFAULT NULL,
  `consideraciones` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `productoVenta_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_7FEF55B9EE52484E` (`productoVenta_id`),
  KEY `IDX_7FEF55B9242F34B1` (`tanda_id`),
  CONSTRAINT `FK_7FEF55B9242F34B1` FOREIGN KEY (`tanda_id`) REFERENCES `Tanda` (`id`),
  CONSTRAINT `FK_7FEF55B9EE52484E` FOREIGN KEY (`productoVenta_id`) REFERENCES `ProductoVenta` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LineaTanda`
--

LOCK TABLES `LineaTanda` WRITE;
/*!40000 ALTER TABLE `LineaTanda` DISABLE KEYS */;
INSERT INTO `LineaTanda` VALUES (1,NULL,0,0,NULL,1),(2,NULL,0,0,NULL,1),(3,NULL,0,0,NULL,1),(4,NULL,0,0,NULL,1),(5,NULL,0,0,NULL,1),(6,NULL,0,0,NULL,1),(7,NULL,0,0,NULL,1),(8,NULL,0,0,NULL,2),(9,NULL,0,0,NULL,2),(10,NULL,0,0,NULL,1),(11,NULL,0,0,NULL,1),(12,NULL,0,0,NULL,2),(13,NULL,0,0,NULL,1),(14,NULL,0,0,NULL,2),(15,NULL,0,0,NULL,2),(16,NULL,0,0,NULL,1),(17,NULL,0,0,NULL,1),(18,NULL,0,0,NULL,2),(19,NULL,0,0,NULL,1),(20,NULL,0,0,NULL,2),(21,NULL,0,0,NULL,1),(22,NULL,0,0,NULL,2),(23,NULL,0,0,NULL,1),(24,NULL,0,0,NULL,2),(25,NULL,0,0,NULL,1),(26,NULL,0,0,NULL,1),(27,NULL,0,0,NULL,2),(28,NULL,0,0,NULL,1),(29,NULL,0,0,NULL,2),(30,NULL,0,0,NULL,1),(31,NULL,0,0,NULL,1),(32,NULL,0,0,NULL,2),(33,NULL,0,0,NULL,2),(34,NULL,0,0,NULL,1),(35,NULL,0,0,NULL,1),(36,NULL,0,0,NULL,1),(37,NULL,0,0,NULL,2),(38,NULL,0,NULL,NULL,1),(39,NULL,0,NULL,NULL,2),(40,NULL,0,0,NULL,1),(41,NULL,0,0,NULL,2),(42,NULL,0,0,NULL,1),(43,NULL,0,0,NULL,2),(44,NULL,0,0,NULL,1),(45,NULL,0,0,NULL,2),(46,NULL,0,0,NULL,1),(47,NULL,0,0,NULL,2),(48,NULL,0,0,NULL,1),(49,NULL,0,0,NULL,2),(50,NULL,0,0,NULL,1),(51,NULL,0,0,NULL,2),(52,NULL,0,0,NULL,2),(53,NULL,0,0,NULL,2),(54,NULL,0,0,NULL,1),(55,NULL,0,0,NULL,2),(56,NULL,0,0,NULL,1),(57,NULL,0,0,NULL,2),(58,NULL,0,0,NULL,1),(59,NULL,0,0,NULL,11),(60,NULL,0,0,NULL,2),(61,NULL,0,0,NULL,6),(62,NULL,0,0,NULL,7),(63,NULL,0,0,NULL,1),(64,NULL,0,0,NULL,1),(65,NULL,0,0,NULL,11),(66,NULL,0,0,NULL,2),(67,NULL,0,0,NULL,1),(68,NULL,0,0,NULL,11),(69,NULL,0,NULL,NULL,2),(70,NULL,0,0,NULL,6),(71,NULL,0,0,NULL,2),(72,NULL,0,NULL,NULL,1),(73,NULL,0,NULL,NULL,11),(74,NULL,0,0,NULL,2),(75,NULL,0,0,NULL,2),(76,NULL,0,0,NULL,2),(77,NULL,0,0,NULL,8),(78,NULL,0,0,NULL,2),(79,NULL,0,0,NULL,1),(80,NULL,0,0,NULL,11),(81,NULL,0,0,NULL,2),(82,NULL,0,0,NULL,2),(83,NULL,0,0,NULL,1),(84,NULL,0,0,NULL,11),(85,NULL,0,0,NULL,1),(86,NULL,0,0,NULL,11),(87,NULL,0,0,NULL,2),(88,NULL,0,0,NULL,2),(89,NULL,0,0,NULL,1),(90,NULL,0,0,NULL,1),(91,NULL,0,0,NULL,11);
/*!40000 ALTER TABLE `LineaTanda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LineaVenta`
--

DROP TABLE IF EXISTS `LineaVenta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LineaVenta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tasa_id` int(11) DEFAULT NULL,
  `venta_id` int(11) DEFAULT NULL,
  `cantidad` decimal(10,2) DEFAULT NULL,
  `precioUnitario` decimal(10,2) DEFAULT NULL,
  `bonificacion` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `productoVenta_id` int(11) DEFAULT NULL,
  `ivaProductoVenta_id` int(11) DEFAULT NULL,
  `tasaIva` decimal(10,2) DEFAULT NULL,
  `precioNeto` decimal(10,2) DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `precioUnitarioSinIva` decimal(10,2) DEFAULT NULL,
  `precioNetoSinIva` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_C08F83DFEE52484E` (`productoVenta_id`),
  KEY `IDX_C08F83DF49460268` (`ivaProductoVenta_id`),
  KEY `IDX_C08F83DFE20BE1E2` (`tasa_id`),
  KEY `IDX_C08F83DFF2A5805D` (`venta_id`),
  CONSTRAINT `FK_C08F83DF49460268` FOREIGN KEY (`ivaProductoVenta_id`) REFERENCES `iva` (`id`),
  CONSTRAINT `FK_C08F83DFE20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`),
  CONSTRAINT `FK_C08F83DFEE52484E` FOREIGN KEY (`productoVenta_id`) REFERENCES `ProductoVenta` (`id`),
  CONSTRAINT `FK_C08F83DFF2A5805D` FOREIGN KEY (`venta_id`) REFERENCES `Venta` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LineaVenta`
--

LOCK TABLES `LineaVenta` WRITE;
/*!40000 ALTER TABLE `LineaVenta` DISABLE KEYS */;
INSERT INTO `LineaVenta` VALUES (1,1,1,4.00,11.00,30.00,NULL,1,1,NULL,NULL,NULL,NULL,NULL),(2,1,1,7.00,12.00,30.00,NULL,2,1,NULL,NULL,NULL,NULL,NULL),(3,1,3,1.00,12.00,30.00,NULL,2,1,NULL,NULL,NULL,NULL,NULL),(4,1,3,20.00,11.00,30.00,NULL,1,1,NULL,NULL,NULL,NULL,NULL),(5,1,5,10.00,11.00,30.00,NULL,1,1,NULL,NULL,NULL,NULL,NULL),(6,1,6,3.00,11.00,30.00,NULL,1,1,NULL,NULL,NULL,NULL,NULL),(7,1,7,1.00,11.00,30.00,NULL,1,1,NULL,NULL,NULL,NULL,NULL),(8,1,7,1.00,12.00,30.00,NULL,2,1,NULL,NULL,NULL,NULL,NULL),(9,1,9,3.00,11.00,30.00,NULL,1,1,NULL,NULL,NULL,NULL,NULL),(10,1,10,3.00,11.00,30.00,NULL,1,1,NULL,NULL,NULL,NULL,NULL),(11,1,11,1.00,12.00,0.00,NULL,2,1,NULL,NULL,NULL,NULL,NULL),(12,1,11,7.00,11.00,30.00,NULL,1,1,NULL,NULL,NULL,NULL,NULL),(13,1,12,10.00,11.00,30.00,NULL,1,1,NULL,NULL,NULL,NULL,NULL),(14,1,12,1.00,12.00,0.00,NULL,2,1,NULL,NULL,NULL,NULL,NULL),(15,1,13,1.00,11.00,30.00,NULL,1,1,NULL,NULL,NULL,NULL,NULL),(16,1,13,1.00,12.00,0.00,NULL,2,1,NULL,NULL,NULL,NULL,NULL),(17,1,14,2.00,11.00,30.00,NULL,1,1,NULL,NULL,NULL,NULL,NULL),(18,1,14,5.00,12.00,0.00,NULL,2,1,NULL,NULL,NULL,NULL,NULL),(19,1,15,1.00,11.00,30.00,NULL,1,1,NULL,NULL,NULL,NULL,NULL),(20,1,15,5.00,12.00,0.00,NULL,2,1,NULL,NULL,NULL,NULL,NULL),(21,1,17,2.00,11.00,30.00,NULL,1,1,NULL,NULL,NULL,NULL,NULL),(22,1,18,1.00,11.00,30.00,NULL,1,1,NULL,NULL,NULL,NULL,NULL),(23,1,18,1.00,12.00,0.00,NULL,2,1,NULL,NULL,NULL,NULL,NULL),(24,1,19,1.00,18.00,0.00,NULL,3,1,NULL,NULL,NULL,NULL,NULL),(25,1,20,1.00,18.00,0.00,NULL,3,1,NULL,NULL,NULL,NULL,NULL),(26,1,21,20.00,18.00,0.00,NULL,3,1,NULL,NULL,NULL,NULL,NULL),(27,1,22,1.00,11.00,0.00,NULL,1,1,NULL,NULL,NULL,NULL,NULL),(28,1,22,1.00,12.00,0.00,NULL,2,1,NULL,NULL,NULL,NULL,NULL),(29,1,23,1.00,18.00,0.00,NULL,3,1,NULL,NULL,NULL,NULL,NULL),(30,1,24,20.00,18.00,0.00,NULL,3,1,NULL,NULL,NULL,NULL,NULL),(31,1,25,1.00,11.00,0.00,NULL,1,1,NULL,NULL,NULL,NULL,NULL),(32,1,25,1.00,12.00,0.00,NULL,2,1,NULL,NULL,NULL,NULL,NULL),(33,1,26,1.00,12.00,0.00,NULL,2,1,NULL,NULL,NULL,NULL,NULL),(34,1,26,1.00,18.00,0.00,NULL,3,1,NULL,NULL,NULL,NULL,NULL),(35,1,27,1.00,11.00,0.00,NULL,1,1,NULL,NULL,NULL,NULL,NULL),(36,1,27,1.00,18.00,0.00,NULL,3,1,NULL,NULL,NULL,NULL,NULL),(37,1,28,2.00,18.00,0.00,NULL,3,1,NULL,NULL,NULL,NULL,NULL),(41,1,30,1.00,11.00,0.00,NULL,1,1,21.00,11.00,'Ravioles gigantes            Alicuota de Iva 21.00 % - Gravado',9.09,9.09),(42,1,30,1.00,12.00,0.00,NULL,2,1,21.00,12.00,'Lomito con papas            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(43,1,30,2.00,18.00,0.00,NULL,3,1,21.00,36.00,'Coca Cola por 3 litros            Alicuota de Iva 21.00 % - Gravado',14.88,29.75),(48,1,34,2.00,11.00,0.00,NULL,1,1,21.00,22.00,'Ravioles gigantes            Alicuota de Iva 21.00 % - Gravado',9.09,18.18),(49,1,34,2.00,12.00,0.00,NULL,2,1,21.00,24.00,'Lomito con papas            Alicuota de Iva 21.00 % - Gravado',9.92,19.83),(50,1,35,2.00,18.00,0.00,NULL,3,1,21.00,36.00,'Coca Cola por 3 litros            Alicuota de Iva 21.00 % - Gravado',14.88,29.75),(51,1,36,2.00,11.00,0.00,NULL,1,1,21.00,22.00,'Ravioles gigantes            Alicuota de Iva 21.00 % - Gravado',9.09,18.18),(52,1,36,2.00,12.00,0.00,NULL,2,1,21.00,24.00,'Lomito con papas            Alicuota de Iva 21.00 % - Gravado',9.92,19.83),(53,1,37,2.00,11.00,0.00,NULL,1,1,21.00,22.00,'Ravioles gigantes            Alicuota de Iva 21.00 % - Gravado',9.09,18.18),(54,1,37,2.00,12.00,0.00,NULL,2,1,21.00,24.00,'Lomito con papas            Alicuota de Iva 21.00 % - Gravado',9.92,19.83),(55,1,38,2.00,11.00,0.00,NULL,1,1,21.00,22.00,'Ravioles gigantes            Alicuota de Iva 21.00 % - Gravado',9.09,18.18),(56,1,38,2.00,12.00,0.00,NULL,2,1,21.00,24.00,'Lomito con papas            Alicuota de Iva 21.00 % - Gravado',9.92,19.83),(57,1,39,2.00,11.00,0.00,NULL,1,1,21.00,22.00,'Ravioles gigantes            Alicuota de Iva 21.00 % - Gravado',9.09,18.18),(58,1,39,2.00,12.00,0.00,NULL,2,1,21.00,24.00,'Lomito con papas            Alicuota de Iva 21.00 % - Gravado',9.92,19.83),(59,1,39,2.00,18.00,0.00,NULL,3,1,21.00,36.00,'Coca Cola por 3 litros            Alicuota de Iva 21.00 % - Gravado',14.88,29.75),(60,1,40,2.00,11.00,0.00,NULL,1,1,21.00,22.00,'Ravioles gigantes            Alicuota de Iva 21.00 % - Gravado',9.09,18.18),(61,1,40,2.00,12.00,0.00,NULL,2,1,21.00,24.00,'Lomito con papas            Alicuota de Iva 21.00 % - Gravado',9.92,19.83),(62,1,40,2.00,18.00,0.00,NULL,3,1,21.00,36.00,'Coca Cola por 3 litros            Alicuota de Iva 21.00 % - Gravado',14.88,29.75),(63,1,41,2.00,11.00,0.00,NULL,1,1,21.00,22.00,'Ravioles gigantes            Alicuota de Iva 21.00 % - Gravado',9.09,18.18),(64,1,41,2.00,12.00,0.00,NULL,2,1,21.00,24.00,'Lomito con papas            Alicuota de Iva 21.00 % - Gravado',9.92,19.83),(65,1,41,2.00,18.00,0.00,NULL,3,1,21.00,36.00,'Coca Cola por 3 litros            Alicuota de Iva 21.00 % - Gravado',14.88,29.75),(66,1,42,2.00,11.00,0.00,NULL,1,1,21.00,22.00,'Ravioles gigantes            Alicuota de Iva 21.00 % - Gravado',9.09,18.18),(67,1,42,2.00,12.00,0.00,NULL,2,1,21.00,24.00,'Lomito con papas            Alicuota de Iva 21.00 % - Gravado',9.92,19.83),(68,1,43,2.00,11.00,0.00,NULL,1,1,21.00,22.00,'Ravioles gigantes            Alicuota de Iva 21.00 % - Gravado',9.09,18.18),(69,1,43,2.00,12.00,0.00,NULL,2,1,21.00,24.00,'Lomito con papas            Alicuota de Iva 21.00 % - Gravado',9.92,19.83),(70,NULL,44,1.00,11.00,0.00,NULL,1,1,21.00,11.00,'Ravioles gigantes\r\n            Alicuota de Iva 21.00 % - Gravado',9.09,9.09),(71,NULL,44,1.00,12.00,0.00,NULL,2,1,21.00,12.00,'Lomito con papas\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(72,NULL,45,1.00,11.00,0.00,NULL,1,1,21.00,11.00,'Ravioles gigantes\r\n            Alicuota de Iva 21.00 % - Gravado',9.09,9.09),(73,NULL,45,1.00,12.00,0.00,NULL,2,1,21.00,12.00,'Lomito con papas\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(74,NULL,45,1.00,18.00,0.00,NULL,3,1,21.00,18.00,'Coca Cola por 3 litros\r\n            Alicuota de Iva 21.00 % - Gravado',14.88,14.88),(75,NULL,47,1.00,18.00,0.00,NULL,3,1,21.00,18.00,'Coca Cola por 3 litros\r\n            Alicuota de Iva 21.00 % - Gravado',14.88,14.88),(76,NULL,47,1.00,11.00,0.00,NULL,1,1,21.00,11.00,'Ravioles gigantes\r\n            Alicuota de Iva 21.00 % - Gravado',9.09,9.09),(77,NULL,47,1.00,12.00,0.00,NULL,2,1,21.00,12.00,'Lomito con papas\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(78,NULL,48,1.00,11.00,0.00,NULL,1,1,21.00,11.00,'Ravioles gigantes\r\n            Alicuota de Iva 21.00 % - Gravado',9.09,9.09),(79,NULL,48,1.00,12.00,0.00,NULL,2,1,21.00,12.00,'Lomito con papas\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(80,NULL,48,1.00,18.00,0.00,NULL,3,1,21.00,18.00,'Coca Cola por 3 litros\r\n            Alicuota de Iva 21.00 % - Gravado',14.88,14.88),(81,NULL,51,2.00,18.00,0.00,NULL,3,1,21.00,36.00,'Coca Cola por 3 litros\r\n            Alicuota de Iva 21.00 % - Gravado',14.88,29.75),(82,NULL,53,2.00,18.00,0.00,NULL,3,1,21.00,36.00,'Coca Cola por 3 litros\r\n            Alicuota de Iva 21.00 % - Gravado',14.88,29.75),(83,NULL,54,2.00,18.00,0.00,NULL,3,1,21.00,36.00,'Coca Cola por 3 litros\r\n            Alicuota de Iva 21.00 % - Gravado',14.88,29.75),(84,NULL,56,2.00,18.00,0.00,NULL,3,1,21.00,36.00,'Coca Cola por 3 litros\r\n            Alicuota de Iva 21.00 % - Gravado',14.88,29.75),(85,NULL,57,1.00,12.00,0.00,NULL,2,1,21.00,12.00,'Lomito con papas\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(86,NULL,57,1.00,18.00,0.00,NULL,3,1,21.00,18.00,'Coca Cola por 3 litros\r\n            Alicuota de Iva 21.00 % - Gravado',14.88,14.88),(87,NULL,58,1.00,11.00,0.00,NULL,1,1,21.00,11.00,'Ravioles gigantes\r\n            Alicuota de Iva 21.00 % - Gravado',9.09,9.09),(88,NULL,58,1.00,18.00,0.00,NULL,3,1,21.00,18.00,'Coca Cola por 3 litros\r\n            Alicuota de Iva 21.00 % - Gravado',14.88,14.88),(89,NULL,58,3.00,12.00,0.00,NULL,2,1,21.00,36.00,'Lomito con papas\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,29.75),(90,NULL,59,1.00,11.00,0.00,NULL,1,1,21.00,11.00,'Ravioles gigantes\r\n            Alicuota de Iva 21.00 % - Gravado',9.09,9.09),(91,NULL,59,1.00,23.00,0.00,NULL,11,1,21.00,23.00,'Tallarines con queso\r\n            Alicuota de Iva 21.00 % - Gravado',19.01,19.01),(92,NULL,59,1.00,18.00,0.00,NULL,3,1,21.00,18.00,'Coca Cola por 3 litros\r\n            Alicuota de Iva 21.00 % - Gravado',14.88,14.88),(93,NULL,59,1.00,12.00,0.00,NULL,9,1,21.00,12.00,'Cerveza Quilmes 1lt\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(94,NULL,59,1.00,12.00,0.00,NULL,2,1,21.00,12.00,'Lomito con papas\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(95,NULL,59,1.00,20.40,0.00,NULL,6,1,21.00,20.40,'Hamburguesa\r\n            Alicuota de Iva 21.00 % - Gravado',16.86,16.86),(96,NULL,59,1.00,19.50,0.00,NULL,7,1,21.00,19.50,'Pizza Mozzarela\r\n            Alicuota de Iva 21.00 % - Gravado',16.12,16.12),(97,NULL,60,1.00,11.00,0.00,NULL,1,1,21.00,11.00,'Ravioles gigantes\r\n            Alicuota de Iva 21.00 % - Gravado',9.09,9.09),(98,NULL,60,1.00,12.00,0.00,NULL,2,1,21.00,12.00,'Lomito con papas\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(99,NULL,61,1.00,11.00,0.00,NULL,1,1,21.00,11.00,'Ravioles gigantes\r\n            Alicuota de Iva 21.00 % - Gravado',9.09,9.09),(100,NULL,61,1.00,23.00,0.00,NULL,11,1,21.00,23.00,'Tallarines con queso\r\n            Alicuota de Iva 21.00 % - Gravado',19.01,19.01),(101,NULL,62,1.00,18.00,0.00,NULL,3,1,21.00,18.00,'Coca Cola por 3 litros\r\n            Alicuota de Iva 21.00 % - Gravado',14.88,14.88),(102,NULL,63,1.00,18.00,0.00,NULL,3,1,21.00,18.00,'Coca Cola por 3 litros\r\n            Alicuota de Iva 21.00 % - Gravado',14.88,14.88),(103,NULL,63,1.00,12.00,0.00,NULL,9,1,21.00,12.00,'Cerveza Quilmes 1lt\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(104,NULL,63,1.00,10.50,0.00,NULL,10,1,21.00,10.50,'Levite de litro\r\n            Alicuota de Iva 21.00 % - Gravado',8.68,8.68),(105,NULL,64,1.00,18.00,0.00,NULL,3,1,21.00,18.00,'Coca Cola por 3 litros\r\n            Alicuota de Iva 21.00 % - Gravado',14.88,14.88),(106,NULL,64,1.00,12.00,0.00,NULL,9,1,21.00,12.00,'Cerveza Quilmes 1lt\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(107,NULL,64,1.00,10.50,0.00,NULL,10,1,21.00,10.50,'Levite de litro\r\n            Alicuota de Iva 21.00 % - Gravado',8.68,8.68),(108,NULL,65,1.00,18.00,0.00,NULL,3,1,21.00,18.00,'Coca Cola por 3 litros\r\n            Alicuota de Iva 21.00 % - Gravado',14.88,14.88),(109,NULL,65,1.00,12.00,0.00,NULL,9,1,21.00,12.00,'Cerveza Quilmes 1lt\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(110,NULL,65,1.00,10.50,0.00,NULL,10,1,21.00,10.50,'Levite de litro\r\n            Alicuota de Iva 21.00 % - Gravado',8.68,8.68),(111,NULL,66,1.00,18.00,0.00,NULL,3,1,21.00,18.00,'Coca Cola por 3 litros\r\n            Alicuota de Iva 21.00 % - Gravado',14.88,14.88),(112,NULL,66,1.00,12.00,0.00,NULL,9,1,21.00,12.00,'Cerveza Quilmes 1lt\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(113,NULL,67,1.00,10.50,0.00,NULL,10,1,21.00,10.50,'Levite de litro\r\n            Alicuota de Iva 21.00 % - Gravado',8.68,8.68),(114,NULL,68,1.00,18.00,0.00,NULL,3,1,21.00,18.00,'Coca Cola por 3 litros\r\n            Alicuota de Iva 21.00 % - Gravado',14.88,14.88),(115,NULL,68,1.00,12.00,0.00,NULL,9,1,21.00,12.00,'Cerveza Quilmes 1lt\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(116,NULL,68,1.00,10.50,0.00,NULL,10,1,21.00,10.50,'Levite de litro\r\n            Alicuota de Iva 21.00 % - Gravado',8.68,8.68),(117,NULL,69,1.00,10.50,0.00,NULL,10,1,21.00,10.50,'Levite de litro\r\n            Alicuota de Iva 21.00 % - Gravado',8.68,8.68),(118,NULL,70,1.00,18.00,0.00,NULL,3,1,21.00,18.00,'Coca Cola por 3 litros\r\n            Alicuota de Iva 21.00 % - Gravado',14.88,14.88),(119,NULL,70,1.00,12.00,0.00,NULL,9,1,21.00,12.00,'Cerveza Quilmes 1lt\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(120,NULL,71,1.00,12.00,0.00,NULL,9,1,21.00,12.00,'Cerveza Quilmes 1lt\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(121,NULL,72,1.00,12.00,0.00,NULL,2,1,21.00,12.00,'Lomito con papas\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(122,NULL,73,1.00,20.40,0.00,NULL,6,1,21.00,20.40,'Hamburguesa\r\n            Alicuota de Iva 21.00 % - Gravado',16.86,16.86),(123,NULL,73,1.00,12.00,0.00,NULL,2,1,21.00,12.00,'Lomito con papas\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(124,NULL,74,1.00,12.00,0.00,NULL,9,1,21.00,12.00,'Cerveza Quilmes 1lt\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(125,NULL,74,3.00,12.00,0.00,NULL,2,1,21.00,36.00,'Lomito con papas\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,29.75),(126,NULL,75,1.00,18.00,0.00,NULL,3,1,21.00,18.00,'Coca Cola por 3 litros\r\n            Alicuota de Iva 21.00 % - Gravado',14.88,14.88),(127,NULL,75,1.00,12.00,0.00,NULL,2,1,21.00,12.00,'Lomito con papas\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(128,NULL,75,1.00,20.40,0.00,NULL,6,1,21.00,20.40,'Hamburguesa\r\n            Alicuota de Iva 21.00 % - Gravado',16.86,16.86),(129,NULL,75,1.00,12.00,0.00,NULL,9,1,21.00,12.00,'Cerveza Quilmes 1lt\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(130,NULL,76,1.00,18.00,0.00,NULL,3,1,21.00,18.00,'Coca Cola por 3 litros\r\n            Alicuota de Iva 21.00 % - Gravado',14.88,14.88),(131,NULL,76,1.00,12.00,0.00,NULL,9,1,21.00,12.00,'Cerveza Quilmes 1lt\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(132,NULL,77,1.00,11.00,0.00,NULL,1,1,21.00,11.00,'Ravioles gigantes\r\n            Alicuota de Iva 21.00 % - Gravado',9.09,9.09),(133,NULL,77,1.00,12.00,0.00,NULL,2,1,21.00,12.00,'Lomito con papas\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(134,NULL,78,1.00,11.00,0.00,NULL,1,1,21.00,11.00,'Ravioles gigantes\r\n            Alicuota de Iva 21.00 % - Gravado',9.09,9.09),(135,NULL,78,1.00,12.00,0.00,NULL,2,1,21.00,12.00,'Lomito con papas\r\n            Alicuota de Iva 21.00 % - Gravado',9.92,9.92),(136,NULL,79,1.00,11.00,0.00,NULL,1,1,21.00,11.00,'Ravioles gigantes\r\n            Alicuota de Iva 21.00 % - Gravado',9.09,9.09),(137,NULL,80,1.00,11.00,0.00,NULL,1,1,21.00,11.00,'Ravioles gigantes\r\n            Alicuota de Iva 21.00 % - Gravado',9.09,9.09),(138,NULL,80,1.00,23.00,0.00,NULL,11,1,21.00,23.00,'Tallarines con queso\r\n            Alicuota de Iva 21.00 % - Gravado',19.01,19.01),(139,NULL,81,1.00,11.00,0.00,NULL,1,1,21.00,11.00,'Ravioles gigantes\r\n            Alicuota de Iva 21.00 % - Gravado',9.09,9.09),(140,NULL,81,1.00,23.00,0.00,NULL,11,1,21.00,23.00,'Tallarines con queso\r\n            Alicuota de Iva 21.00 % - Gravado',19.01,19.01);
/*!40000 ALTER TABLE `LineaVenta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Localidad`
--

DROP TABLE IF EXISTS `Localidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Localidad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provincia_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CD9962B34E7121AF` (`provincia_id`),
  CONSTRAINT `FK_CD9962B34E7121AF` FOREIGN KEY (`provincia_id`) REFERENCES `Provincia` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Localidad`
--

LOCK TABLES `Localidad` WRITE;
/*!40000 ALTER TABLE `Localidad` DISABLE KEYS */;
/*!40000 ALTER TABLE `Localidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Lote`
--

DROP TABLE IF EXISTS `Lote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Lote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `caja_id` int(11) DEFAULT NULL,
  `fechaApertura` datetime DEFAULT NULL,
  `fechaCierre` datetime DEFAULT NULL,
  `saldo` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_C5869DA1DB38439E` (`usuario_id`),
  KEY `IDX_C5869DA12D82B651` (`caja_id`),
  CONSTRAINT `FK_C5869DA12D82B651` FOREIGN KEY (`caja_id`) REFERENCES `Caja` (`id`),
  CONSTRAINT `FK_C5869DA1DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Lote`
--

LOCK TABLES `Lote` WRITE;
/*!40000 ALTER TABLE `Lote` DISABLE KEYS */;
INSERT INTO `Lote` VALUES (1,1,1,'2013-10-19 18:35:43','2013-10-21 08:07:01',NULL),(2,1,1,'2013-10-21 08:09:40','2013-10-21 09:29:19',NULL),(3,1,1,'2013-10-21 14:28:06','2013-10-21 19:35:15',NULL),(4,1,1,'2013-10-21 19:36:29','2013-12-01 11:37:28',NULL),(5,4,1,'2013-12-01 22:27:59',NULL,NULL);
/*!40000 ALTER TABLE `Lote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Mantenimiento`
--

DROP TABLE IF EXISTS `Mantenimiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Mantenimiento` (
  `id` int(11) NOT NULL,
  `tasa_id` int(11) DEFAULT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `iva_id` int(11) DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `precioCosto` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_8E3E5820E20BE1E2` (`tasa_id`),
  KEY `IDX_8E3E5820CB305D73` (`proveedor_id`),
  KEY `IDX_8E3E5820F231661A` (`iva_id`),
  CONSTRAINT `FK_8E3E5820BF396750` FOREIGN KEY (`id`) REFERENCES `Producto` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_8E3E5820CB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedor` (`id`),
  CONSTRAINT `FK_8E3E5820E20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`),
  CONSTRAINT `FK_8E3E5820F231661A` FOREIGN KEY (`iva_id`) REFERENCES `iva` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Mantenimiento`
--

LOCK TABLES `Mantenimiento` WRITE;
/*!40000 ALTER TABLE `Mantenimiento` DISABLE KEYS */;
/*!40000 ALTER TABLE `Mantenimiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Marca`
--

DROP TABLE IF EXISTS `Marca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Marca` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Marca`
--

LOCK TABLES `Marca` WRITE;
/*!40000 ALTER TABLE `Marca` DISABLE KEYS */;
/*!40000 ALTER TABLE `Marca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MarcaTemporal`
--

DROP TABLE IF EXISTS `MarcaTemporal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MarcaTemporal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cocina_id` int(11) DEFAULT NULL,
  `color` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `minutos` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D82C185D2311565A` (`cocina_id`),
  CONSTRAINT `FK_D82C185D2311565A` FOREIGN KEY (`cocina_id`) REFERENCES `Cocina` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MarcaTemporal`
--

LOCK TABLES `MarcaTemporal` WRITE;
/*!40000 ALTER TABLE `MarcaTemporal` DISABLE KEYS */;
INSERT INTO `MarcaTemporal` VALUES (1,1,'#141ee7',1),(2,1,'#ca7819',3),(3,1,'#000000',15);
/*!40000 ALTER TABLE `MarcaTemporal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MateriaPrima`
--

DROP TABLE IF EXISTS `MateriaPrima`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MateriaPrima` (
  `id` int(11) NOT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `tasa_id` int(11) DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `precioCosto` decimal(10,2) DEFAULT NULL,
  `cantidad` decimal(10,2) DEFAULT NULL,
  `cantidadDeseada` decimal(10,2) DEFAULT NULL,
  `superaMin` tinyint(1) DEFAULT NULL,
  `cantidadMinima` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CA2388F3CB305D73` (`proveedor_id`),
  KEY `IDX_CA2388F3E20BE1E2` (`tasa_id`),
  CONSTRAINT `FK_CA2388F3BF396750` FOREIGN KEY (`id`) REFERENCES `Producto` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_CA2388F3CB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedor` (`id`),
  CONSTRAINT `FK_CA2388F3E20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MateriaPrima`
--

LOCK TABLES `MateriaPrima` WRITE;
/*!40000 ALTER TABLE `MateriaPrima` DISABLE KEYS */;
INSERT INTO `MateriaPrima` VALUES (4,1,3,'Carne',10.50,995.80,NULL,0,10.00),(5,1,1,'Huevo',12.00,978.00,NULL,0,10.00),(12,1,3,'Tomate',10.00,29.60,NULL,0,1.00);
/*!40000 ALTER TABLE `MateriaPrima` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Mercaderia`
--

DROP TABLE IF EXISTS `Mercaderia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Mercaderia` (
  `id` int(11) NOT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `imagen_id` int(11) DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `precioVenta` decimal(10,2) DEFAULT NULL,
  `precioCosto` decimal(10,2) DEFAULT NULL,
  `cantidad` decimal(10,2) DEFAULT NULL,
  `margen` decimal(10,2) DEFAULT NULL,
  `margenMin` decimal(10,2) DEFAULT NULL,
  `supera` tinyint(1) NOT NULL,
  `cantidadDeseada` decimal(10,2) DEFAULT NULL,
  `cantidadMinima` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_B00CD745763C8AA7` (`imagen_id`),
  KEY `IDX_B00CD745CB305D73` (`proveedor_id`),
  CONSTRAINT `FK_B00CD745763C8AA7` FOREIGN KEY (`imagen_id`) REFERENCES `Image` (`id`),
  CONSTRAINT `FK_B00CD745BF396750` FOREIGN KEY (`id`) REFERENCES `Producto` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_B00CD745CB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedor` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Mercaderia`
--

LOCK TABLES `Mercaderia` WRITE;
/*!40000 ALTER TABLE `Mercaderia` DISABLE KEYS */;
INSERT INTO `Mercaderia` VALUES (3,1,8,'Coca Cola por 3 litros',18.00,15.00,908.00,20.00,10.00,0,NULL,100.00),(9,1,18,'Cerveza Quilmes 1lt',12.00,10.00,1982.00,20.00,15.00,0,NULL,20.00),(10,1,20,'Levite de litro',10.50,10.00,991.00,5.00,4.00,0,NULL,20.00);
/*!40000 ALTER TABLE `Mercaderia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Mesa`
--

DROP TABLE IF EXISTS `Mesa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Mesa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sector_id` int(11) DEFAULT NULL,
  `numero` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_38812DCCDE95C867` (`sector_id`),
  CONSTRAINT `FK_38812DCCDE95C867` FOREIGN KEY (`sector_id`) REFERENCES `Sector` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Mesa`
--

LOCK TABLES `Mesa` WRITE;
/*!40000 ALTER TABLE `Mesa` DISABLE KEYS */;
INSERT INTO `Mesa` VALUES (1,1,1),(2,1,2),(3,1,3),(4,1,4),(5,1,5),(6,1,6),(7,1,7),(8,1,8),(9,1,9),(10,1,10),(11,2,1),(12,2,2),(13,2,3),(14,2,4),(15,2,5),(16,2,6),(17,2,7),(18,2,8),(19,2,9),(20,2,10),(21,2,11),(22,2,12),(23,2,13),(24,2,14),(25,2,15),(26,2,16),(27,2,17),(28,2,18),(29,2,19),(30,2,20),(31,2,21),(32,2,22),(33,2,23),(34,2,24),(35,2,25),(36,2,26),(37,2,27),(38,2,28),(39,2,29),(40,2,30);
/*!40000 ALTER TABLE `Mesa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Movimiento`
--

DROP TABLE IF EXISTS `Movimiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Movimiento` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lote_id` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `concepto_id` int(11) DEFAULT NULL,
  `importe` decimal(10,2) DEFAULT NULL,
  `aclaracion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `dtype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_87A213AAB172197C` (`lote_id`),
  KEY `IDX_87A213AAA9276E6C` (`tipo_id`),
  KEY `IDX_87A213AA6C2330BD` (`concepto_id`),
  CONSTRAINT `FK_87A213AA6C2330BD` FOREIGN KEY (`concepto_id`) REFERENCES `Concepto` (`id`),
  CONSTRAINT `FK_87A213AAA9276E6C` FOREIGN KEY (`tipo_id`) REFERENCES `TipoCobro` (`id`),
  CONSTRAINT `FK_87A213AAB172197C` FOREIGN KEY (`lote_id`) REFERENCES `Lote` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Movimiento`
--

LOCK TABLES `Movimiento` WRITE;
/*!40000 ALTER TABLE `Movimiento` DISABLE KEYS */;
INSERT INTO `Movimiento` VALUES (1,1,1,NULL,0.00,NULL,'2013-10-19 18:35:43','apertura'),(2,1,1,NULL,38.50,'Factura A 0001-00000003','2013-10-21 00:48:04','entrada'),(3,1,1,NULL,13.30,'Factura A 0001-00000005','2013-10-21 00:51:24','entrada'),(4,1,1,NULL,13.30,'Cambio Factura A 0001-00000005','2013-10-21 00:51:24','salida'),(5,1,1,NULL,20.00,'Factura B 0001-00000006','2013-10-21 07:12:56','entrada'),(6,1,1,NULL,20.00,'Cambio Factura B 0001-00000006','2013-10-21 07:12:56','salida'),(7,1,3,NULL,19.08,'Factura B 0001-00000007 Numero de Comprobante:0001','2013-10-21 07:14:18','entrada'),(8,1,1,NULL,19.08,'Cambio Factura B 0001-00000007','2013-10-21 07:14:18','salida'),(9,1,1,NULL,100.00,'Factura A 0001-00000008','2013-10-21 07:27:46','entrada'),(10,1,1,NULL,-45.05,'Cambio Factura A 0001-00000008','2013-10-21 07:27:46','salida'),(11,1,1,NULL,100.00,'Factura A 0001-00000009','2013-10-21 07:33:09','entrada'),(12,1,1,NULL,3.38,'Cambio Factura A 0001-00000009','2013-10-21 07:33:09','salida'),(13,1,1,NULL,20.00,'Factura B 0001-00000010','2013-10-21 07:54:51','entrada'),(14,1,1,NULL,-0.46,'Cambio Factura B 0001-00000010','2013-10-21 07:54:52','salida'),(15,1,1,NULL,37.70,'Factura B 0001-00000011','2013-10-21 08:01:45','entrada'),(16,1,1,NULL,-75.40,'Cambio Factura B 0001-00000011','2013-10-21 08:01:45','salida'),(17,1,1,NULL,50.00,'Factura A 0001-00000012','2013-10-21 08:04:24','entrada'),(18,1,1,NULL,16.15,'Cambio Factura A 0001-00000012','2013-10-21 08:04:24','salida'),(19,1,NULL,NULL,NULL,NULL,'2013-10-21 08:07:01','cierre'),(20,2,1,NULL,428.50,NULL,'2013-10-21 08:09:40','apertura'),(21,2,1,1,300.00,'Según Factura A 0002-0000008','2013-10-21 08:10:41','salida'),(22,2,1,NULL,50.00,'Factura B 0001-00000013','2013-10-21 08:32:12','entrada'),(23,2,1,NULL,4.60,'Cambio Factura B 0001-00000013','2013-10-21 08:32:12','salida'),(24,2,1,NULL,20.00,'Factura A 0001-00000013','2013-10-21 09:27:43','entrada'),(25,2,1,NULL,0.30,'Cambio Factura A 0001-00000013','2013-10-21 09:27:43','salida'),(26,2,NULL,NULL,NULL,NULL,'2013-10-21 09:29:19','cierre'),(27,3,1,NULL,193.60,NULL,'2013-10-21 14:28:06','apertura'),(28,3,1,NULL,18.00,'Factura A 0001-00000013','2013-10-21 17:03:22','entrada'),(29,3,1,NULL,0.00,'Cambio Factura A 0001-00000013','2013-10-21 17:03:22','salida'),(30,3,1,NULL,48.00,'Factura A 0001-00000013','2013-10-21 17:54:27','entrada'),(31,3,1,NULL,0.00,'Cambio Factura A 0001-00000013','2013-10-21 17:54:27','salida'),(32,3,1,NULL,360.00,'Factura C 0001-00000013','2013-10-21 18:21:28','entrada'),(33,3,1,NULL,0.00,'Cambio Factura C 0001-00000013','2013-10-21 18:21:28','salida'),(34,3,1,NULL,50.00,'Factura C 0001-00000014','2013-10-21 19:30:34','entrada'),(35,3,1,NULL,27.00,'Cambio Factura C 0001-00000014','2013-10-21 19:30:34','salida'),(36,3,3,NULL,18.00,'Factura C 0001-00000015 Numero de Comprobante:0002','2013-10-21 19:33:07','entrada'),(37,3,1,NULL,0.00,'Cambio Factura C 0001-00000015','2013-10-21 19:33:07','salida'),(38,3,NULL,NULL,NULL,NULL,'2013-10-21 19:35:15','cierre'),(39,4,1,NULL,642.60,NULL,'2013-10-21 19:36:29','apertura'),(40,4,3,NULL,180.00,'Factura C 0001-00000016 Numero de Comprobante:0001','2013-10-22 08:20:00','entrada'),(41,4,1,NULL,-80.00,'Cambio Factura C 0001-00000016','2013-10-22 08:20:00','salida'),(42,4,1,NULL,33.00,'Factura C 0001-00000020','2013-10-22 10:41:47','entrada'),(43,4,1,NULL,-33.00,'Cambio Factura C 0001-00000020','2013-10-22 10:41:47','salida'),(44,4,1,NULL,26.50,'Factura C 0001-00000021','2013-10-26 09:28:38','entrada'),(45,4,1,NULL,26.50,'Factura C 0001-00000021','2013-10-26 09:29:11','entrada'),(46,4,1,NULL,26.50,'Factura C 0001-00000021','2013-10-26 09:30:39','entrada'),(47,4,1,NULL,26.50,'Factura C 0001-00000021','2013-10-26 09:31:51','entrada'),(48,4,1,NULL,26.50,'Factura C 0001-00000021','2013-10-26 09:32:31','entrada'),(49,4,1,NULL,24.00,'Factura C 0001-00000020','2013-10-26 10:43:56','entrada'),(50,4,1,NULL,26.50,'Factura C 0001-00000020','2013-10-26 11:03:29','entrada'),(51,4,1,NULL,26.50,'Factura C 0001-00000022','2013-10-26 11:15:36','entrada'),(52,4,1,NULL,26.50,'Factura A 0001-00000014','2013-10-26 11:24:07','entrada'),(53,4,1,NULL,26.50,'Factura A 0001-00000014','2013-10-26 11:25:29','entrada'),(54,4,1,NULL,26.50,'Factura A 0001-00000014','2013-10-26 11:25:52','entrada'),(55,4,1,NULL,100.00,'Factura A 0001-00000015','2013-10-26 18:51:42','entrada'),(56,4,1,NULL,64.50,'Cambio Factura A 0001-00000015','2013-10-26 18:51:42','salida'),(57,4,1,NULL,100.00,'Factura A 0001-00000016','2013-10-26 18:55:12','entrada'),(58,4,1,NULL,29.00,'Cambio Factura A 0001-00000016','2013-10-26 18:55:12','salida'),(59,4,1,NULL,150.00,'Factura A 0001-00000017','2013-10-26 19:03:55','entrada'),(60,4,1,NULL,79.00,'Cambio Factura A 0001-00000017','2013-10-26 19:03:55','salida'),(61,4,1,NULL,100.00,'Factura A 0001-00000018','2013-10-26 19:10:56','entrada'),(62,4,1,NULL,47.00,'Cambio Factura A 0001-00000018','2013-10-26 19:10:56','salida'),(63,4,1,NULL,100.00,'Factura A 0001-00000019','2013-10-26 19:31:57','entrada'),(64,4,1,NULL,47.00,'Cambio Factura A 0001-00000019','2013-10-26 19:31:57','salida'),(65,4,1,NULL,100.00,'Factura A 0001-00000020','2013-10-26 19:38:28','entrada'),(66,4,1,NULL,47.00,'Cambio Factura A 0001-00000020','2013-10-26 19:38:28','salida'),(67,4,3,NULL,89.00,'Factura A 0001-00000022 Numero de Comprobante:0002','2013-10-26 20:22:51','entrada'),(68,4,3,NULL,71.00,'Factura A 0001-00000022 Numero de Comprobante:0003','2013-10-26 20:23:28','entrada'),(69,4,1,NULL,50.00,'Factura C 0001-00000023','2013-10-27 10:43:50','entrada'),(70,4,1,NULL,71.00,'Factura C 0001-00000024','2013-10-27 14:04:27','entrada'),(71,4,1,NULL,66.00,'Factura C 0001-00000024','2013-10-27 16:02:39','entrada'),(72,4,1,NULL,100.00,'Factura A 0001-00000023','2013-10-27 17:12:39','entrada'),(73,4,1,NULL,29.00,'Cambio Factura A 0001-00000023','2013-10-27 17:12:40','salida'),(74,4,1,NULL,66.00,'Factura A 0001-00000023','2013-10-27 17:13:41','entrada'),(75,4,1,NULL,66.00,'Factura A 0001-00000024','2013-10-27 17:16:58','entrada'),(76,4,1,NULL,66.00,'Factura A 0001-00000025','2013-10-27 17:50:27','entrada'),(77,4,1,NULL,66.00,'Factura A 0001-00000025','2013-10-27 17:52:48','entrada'),(78,4,1,NULL,71.00,'Registro de Envio 00000003','2013-10-27 19:42:51','entrada'),(79,4,1,NULL,100.00,'Factura A 0001-00000026','2013-10-27 22:34:54','entrada'),(80,4,1,NULL,40.00,'Cambio Factura A 0001-00000026','2013-10-27 22:34:55','salida'),(81,4,3,NULL,95.00,'Factura B 0001-00000014 Numero de Comprobante:0012','2013-10-27 22:41:55','entrada'),(82,4,1,NULL,95.00,'Registro de Envio 00000005','2013-10-27 22:43:52','entrada'),(83,4,1,NULL,57.95,'Factura A 0001-00000027','2013-10-27 23:01:46','entrada'),(84,4,1,NULL,23.00,'Factura C 0001-00000025','2013-10-28 13:58:15','entrada'),(85,4,1,4,300.00,'Factura que no se cobro en tiempo y forma','2013-10-28 14:40:05','entrada'),(86,4,1,NULL,40.50,'Factura C 0001-00000028','2013-11-02 17:19:32','entrada'),(87,4,1,NULL,20.00,'Factura C 0001-00000033','2013-11-02 18:46:39','entrada'),(88,4,1,NULL,20.25,'Recibo 0001-00000001','2013-11-03 18:15:16','entrada'),(89,4,1,NULL,31.00,'Recibo 0001-00000005','2013-11-03 18:30:02','entrada'),(90,4,1,NULL,12.00,'Factura C 0001-00000037','2013-11-03 22:13:02','entrada'),(91,4,1,NULL,88.00,'Registro de Envio 00000006','2013-11-03 22:18:27','entrada'),(92,4,1,NULL,59.00,'Registro de Envio 00000002','2013-11-03 22:18:41','entrada'),(93,4,1,NULL,24.85,'Registro de Envio 00000001','2013-11-03 22:18:55','entrada'),(94,4,3,NULL,32.40,'Factura C 0001-00000038 Numero de Comprobante:0015','2013-11-04 11:56:48','entrada'),(95,4,1,NULL,50.00,'Factura C 0001-00000039','2013-11-04 15:35:41','entrada'),(96,4,1,NULL,2.00,'Cambio Factura C 0001-00000039','2013-11-04 15:35:41','salida'),(97,4,1,NULL,42.00,'Registro de Envio 00000007','2013-11-04 15:43:06','entrada'),(98,4,3,NULL,62.40,'Factura C 0001-00000040 Numero de Comprobante:0003','2013-11-04 15:45:29','entrada'),(99,4,1,NULL,20.00,'Recibo 0001-00000002','2013-11-04 15:48:12','entrada'),(100,4,1,NULL,10.00,'Recibo 0001-00000003','2013-11-04 15:49:23','entrada'),(101,4,1,NULL,12.00,'Recibo 0001-00000004','2013-11-16 18:32:33','entrada'),(102,4,1,NULL,23.00,'Factura B 0001-00000015','2013-11-23 08:09:16','entrada'),(103,4,1,NULL,11.00,'Factura B 0001-00000017','2013-11-25 09:19:38','entrada'),(104,4,1,NULL,34.00,'Factura B 0001-00000018','2013-11-30 23:28:08','entrada'),(105,4,1,NULL,34.00,'Factura B 0001-00000019','2013-12-01 00:17:06','entrada'),(106,4,NULL,NULL,NULL,NULL,'2013-12-01 11:37:28','cierre'),(107,5,1,NULL,3.07,NULL,'2013-12-01 22:27:59','apertura');
/*!40000 ALTER TABLE `Movimiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MovimientoCuentaCorriente`
--

DROP TABLE IF EXISTS `MovimientoCuentaCorriente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MovimientoCuentaCorriente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cuenta_id` int(11) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `importe` decimal(10,2) NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dtype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_63A09DF29AEFF118` (`cuenta_id`),
  CONSTRAINT `FK_63A09DF29AEFF118` FOREIGN KEY (`cuenta_id`) REFERENCES `CuentaCorriente` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MovimientoCuentaCorriente`
--

LOCK TABLES `MovimientoCuentaCorriente` WRITE;
/*!40000 ALTER TABLE `MovimientoCuentaCorriente` DISABLE KEYS */;
INSERT INTO `MovimientoCuentaCorriente` VALUES (1,1,'2013-11-02 18:44:03',10.50,NULL,'movimientocuentacorrientedebe','activo'),(2,1,'2013-11-02 18:46:39',20.50,NULL,'movimientocuentacorrientedebe','activo'),(3,5,'2013-11-02 19:15:57',5.25,NULL,'movimientocuentacorrientedebe','activo'),(4,5,'2013-11-02 19:19:20',15.00,NULL,'movimientocuentacorrientedebe','activo'),(6,5,'2013-11-03 18:15:16',20.25,NULL,'movimientocuentacorrientehaber','activo'),(7,1,'2013-11-03 18:30:02',31.00,NULL,'movimientocuentacorrientehaber','activo'),(8,4,'2013-11-03 18:32:15',12.00,NULL,'movimientocuentacorrientedebe','activo'),(9,6,'2013-11-04 15:47:09',30.00,NULL,'movimientocuentacorrientedebe','activo'),(10,6,'2013-11-04 15:48:12',20.00,NULL,'movimientocuentacorrientehaber','activo'),(11,6,'2013-11-04 15:49:23',10.00,NULL,'movimientocuentacorrientehaber','activo'),(12,4,'2013-11-16 18:32:33',12.00,NULL,'movimientocuentacorrientehaber','activo'),(13,3,'2013-11-23 08:14:41',23.00,NULL,'movimientocuentacorrientedebe','activo');
/*!40000 ALTER TABLE `MovimientoCuentaCorriente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MovimientoCuentaCorrienteDebe`
--

DROP TABLE IF EXISTS `MovimientoCuentaCorrienteDebe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MovimientoCuentaCorrienteDebe` (
  `id` int(11) NOT NULL,
  `unaVenta_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_B225FCCBE35D31B` (`unaVenta_id`),
  CONSTRAINT `FK_B225FCCBBF396750` FOREIGN KEY (`id`) REFERENCES `MovimientoCuentaCorriente` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_B225FCCBE35D31B` FOREIGN KEY (`unaVenta_id`) REFERENCES `Venta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MovimientoCuentaCorrienteDebe`
--

LOCK TABLES `MovimientoCuentaCorrienteDebe` WRITE;
/*!40000 ALTER TABLE `MovimientoCuentaCorrienteDebe` DISABLE KEYS */;
INSERT INTO `MovimientoCuentaCorrienteDebe` VALUES (1,67),(2,68),(3,69),(4,70),(8,71),(9,76),(13,78);
/*!40000 ALTER TABLE `MovimientoCuentaCorrienteDebe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MovimientoCuentaCorrienteHaber`
--

DROP TABLE IF EXISTS `MovimientoCuentaCorrienteHaber`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MovimientoCuentaCorrienteHaber` (
  `id` int(11) NOT NULL,
  `unRecibo_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_2A9FBB0F63616B01` (`unRecibo_id`),
  CONSTRAINT `FK_2A9FBB0F63616B01` FOREIGN KEY (`unRecibo_id`) REFERENCES `Recibo` (`id`),
  CONSTRAINT `FK_2A9FBB0FBF396750` FOREIGN KEY (`id`) REFERENCES `MovimientoCuentaCorriente` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MovimientoCuentaCorrienteHaber`
--

LOCK TABLES `MovimientoCuentaCorrienteHaber` WRITE;
/*!40000 ALTER TABLE `MovimientoCuentaCorrienteHaber` DISABLE KEYS */;
INSERT INTO `MovimientoCuentaCorrienteHaber` VALUES (6,1),(7,2),(10,3),(11,4),(12,5);
/*!40000 ALTER TABLE `MovimientoCuentaCorrienteHaber` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NotaCredito`
--

DROP TABLE IF EXISTS `NotaCredito`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `NotaCredito` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `factura_id` int(11) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cuit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serie` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `numero` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `condicionIva_id` int(11) DEFAULT NULL,
  `condicionIvaEmpresa_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_799C85D7F04F795F` (`factura_id`),
  KEY `IDX_799C85D7DB38439E` (`usuario_id`),
  KEY `IDX_799C85D7DE734E51` (`cliente_id`),
  KEY `IDX_799C85D7F60CF12A` (`condicionIva_id`),
  KEY `IDX_799C85D75C25E126` (`condicionIvaEmpresa_id`),
  CONSTRAINT `FK_799C85D75C25E126` FOREIGN KEY (`condicionIvaEmpresa_id`) REFERENCES `CondicionIva` (`id`),
  CONSTRAINT `FK_799C85D7DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`),
  CONSTRAINT `FK_799C85D7DE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Cliente` (`id`),
  CONSTRAINT `FK_799C85D7F04F795F` FOREIGN KEY (`factura_id`) REFERENCES `Venta` (`id`),
  CONSTRAINT `FK_799C85D7F60CF12A` FOREIGN KEY (`condicionIva_id`) REFERENCES `CondicionIva` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NotaCredito`
--

LOCK TABLES `NotaCredito` WRITE;
/*!40000 ALTER TABLE `NotaCredito` DISABLE KEYS */;
INSERT INTO `NotaCredito` VALUES (1,1,1,56,'2013-10-27 00:00:00','Herrera, Fernando Martin','20-34366629-3',NULL,'0001','00000001',1,1),(2,1,2,57,'2013-10-27 00:00:00','Herrera, Horacio','20-3525526-3',NULL,'0001','00000001',1,1);
/*!40000 ALTER TABLE `NotaCredito` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Operacion`
--

DROP TABLE IF EXISTS `Operacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Operacion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `de_id` int(11) DEFAULT NULL,
  `a_id` int(11) DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipoOperacion_id` int(11) DEFAULT NULL,
  `tipoFactura_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_56BE4BE8957DD03D` (`tipoOperacion_id`),
  KEY `IDX_56BE4BE810E064DC` (`tipoFactura_id`),
  KEY `IDX_56BE4BE83F683D83` (`de_id`),
  KEY `IDX_56BE4BE83BDE5358` (`a_id`),
  CONSTRAINT `FK_56BE4BE810E064DC` FOREIGN KEY (`tipoFactura_id`) REFERENCES `TipoFactura` (`id`),
  CONSTRAINT `FK_56BE4BE83BDE5358` FOREIGN KEY (`a_id`) REFERENCES `CondicionIva` (`id`),
  CONSTRAINT `FK_56BE4BE83F683D83` FOREIGN KEY (`de_id`) REFERENCES `CondicionIva` (`id`),
  CONSTRAINT `FK_56BE4BE8957DD03D` FOREIGN KEY (`tipoOperacion_id`) REFERENCES `TipoOperacion` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Operacion`
--

LOCK TABLES `Operacion` WRITE;
/*!40000 ALTER TABLE `Operacion` DISABLE KEYS */;
INSERT INTO `Operacion` VALUES (1,1,1,'activo',1,1),(2,1,2,'activo',1,3),(3,2,3,'activo',1,3),(4,1,3,'activo',1,2),(5,2,1,'activo',1,3),(7,4,3,'inactivo',1,2);
/*!40000 ALTER TABLE `Operacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Pais`
--

DROP TABLE IF EXISTS `Pais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Pais` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Pais`
--

LOCK TABLES `Pais` WRITE;
/*!40000 ALTER TABLE `Pais` DISABLE KEYS */;
/*!40000 ALTER TABLE `Pais` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Pedido`
--

DROP TABLE IF EXISTS `Pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Pedido` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `tanda_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `direccion_id` int(11) DEFAULT NULL,
  `mesa_id` int(11) DEFAULT NULL,
  `cocina_id` int(11) DEFAULT NULL,
  `fechapedido` datetime DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `solicitante` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `motivoCancelacion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registroEnvio_id` int(11) DEFAULT NULL,
  `tipoPedido_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_C34013F8D0A7BD7` (`direccion_id`),
  UNIQUE KEY `UNIQ_C34013F88BDC7AE9` (`mesa_id`),
  KEY `IDX_C34013F8DE734E51` (`cliente_id`),
  KEY `IDX_C34013F8521E1991` (`empresa_id`),
  KEY `IDX_C34013F8242F34B1` (`tanda_id`),
  KEY `IDX_C34013F8C013411B` (`registroEnvio_id`),
  KEY `IDX_C34013F8DB38439E` (`usuario_id`),
  KEY `IDX_C34013F82311565A` (`cocina_id`),
  KEY `IDX_C34013F832A0F830` (`tipoPedido_id`),
  CONSTRAINT `FK_C34013F82311565A` FOREIGN KEY (`cocina_id`) REFERENCES `Pedido` (`id`),
  CONSTRAINT `FK_C34013F8242F34B1` FOREIGN KEY (`tanda_id`) REFERENCES `Tanda` (`id`),
  CONSTRAINT `FK_C34013F832A0F830` FOREIGN KEY (`tipoPedido_id`) REFERENCES `TipoPedido` (`id`),
  CONSTRAINT `FK_C34013F8521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_C34013F88BDC7AE9` FOREIGN KEY (`mesa_id`) REFERENCES `Mesa` (`id`),
  CONSTRAINT `FK_C34013F8C013411B` FOREIGN KEY (`registroEnvio_id`) REFERENCES `RegistroEnvio` (`id`),
  CONSTRAINT `FK_C34013F8D0A7BD7` FOREIGN KEY (`direccion_id`) REFERENCES `Direccion` (`id`),
  CONSTRAINT `FK_C34013F8DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`),
  CONSTRAINT `FK_C34013F8DE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Cliente` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Pedido`
--

LOCK TABLES `Pedido` WRITE;
/*!40000 ALTER TABLE `Pedido` DISABLE KEYS */;
INSERT INTO `Pedido` VALUES (1,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-19 18:35:03','Listo','Herrera, Fernando Martin',NULL,NULL,2),(2,NULL,NULL,NULL,1,NULL,NULL,NULL,'2013-10-19 19:16:14','Terminado',NULL,NULL,NULL,1),(3,1,NULL,NULL,1,3,NULL,NULL,'2013-10-19 19:17:04','Listo','Herrera, Fernando Martin',NULL,NULL,3),(4,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-20 11:24:13','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(5,2,NULL,NULL,1,NULL,NULL,NULL,'2013-10-20 18:48:30','Facturado','Herrera, Horacio',NULL,NULL,2),(6,2,NULL,NULL,1,NULL,NULL,NULL,'2013-10-20 18:53:24','Facturado','Herrera, Horacio',NULL,NULL,2),(7,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-20 19:24:45','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(8,2,NULL,NULL,1,NULL,NULL,NULL,'2013-10-20 19:41:40','Facturado','Herrera, Horacio',NULL,NULL,2),(9,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-20 19:43:39','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(10,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-20 19:55:54','Listo','Herrera, Fernando Martin',NULL,NULL,2),(11,1,NULL,NULL,1,5,NULL,NULL,'2013-10-21 01:09:55','Entregado','Herrera, Fernando Martin',NULL,1,3),(12,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-21 07:26:25','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(13,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-21 07:31:10','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(14,2,NULL,NULL,1,NULL,NULL,NULL,'2013-10-21 07:45:24','Facturado','Herrera, Horacio',NULL,NULL,2),(15,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-21 07:57:53','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(16,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-21 08:03:05','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(17,2,NULL,NULL,1,NULL,NULL,NULL,'2013-10-21 09:27:04','Facturado','Herrera, Horacio',NULL,NULL,2),(18,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-21 09:55:47','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(19,2,NULL,NULL,1,NULL,NULL,NULL,'2013-10-21 09:57:00','Facturado','Herrera, Horacio',NULL,NULL,2),(20,2,NULL,NULL,1,NULL,NULL,NULL,'2013-10-21 09:57:40','Listo','Herrera, Horacio',NULL,NULL,2),(21,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-21 10:01:18','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(22,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-21 17:54:06','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(23,NULL,NULL,NULL,1,NULL,NULL,NULL,'2013-10-21 19:26:03','Terminado',NULL,NULL,NULL,1),(24,3,NULL,NULL,1,9,NULL,NULL,'2013-10-21 19:39:58','Entregado','Aquino, Ramona',NULL,2,3),(25,3,NULL,NULL,1,NULL,NULL,NULL,'2013-10-22 09:35:18','Facturado','Aquino, Ramona',NULL,NULL,2),(26,3,NULL,NULL,1,NULL,NULL,NULL,'2013-10-22 10:34:30','Facturado','Aquino, Ramona',NULL,NULL,2),(27,3,NULL,NULL,1,NULL,NULL,NULL,'2013-10-22 10:40:02','Listo','Aquino, Ramona',NULL,NULL,2),(28,3,NULL,NULL,1,NULL,NULL,NULL,'2013-10-22 10:41:15','Facturado','Aquino, Ramona',NULL,NULL,2),(29,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-23 17:25:40','Listo','Herrera, Fernando Martin',NULL,NULL,2),(30,NULL,NULL,NULL,1,NULL,NULL,NULL,'2013-10-23 18:07:01','Terminado',NULL,NULL,NULL,1),(31,1,NULL,NULL,1,11,NULL,NULL,'2013-10-24 17:57:06','Listo','Herrera, Fernando Martin',NULL,NULL,3),(32,1,NULL,NULL,1,12,NULL,NULL,'2013-10-25 07:32:07','Listo','Herrera, Fernando Martin',NULL,NULL,3),(33,1,NULL,NULL,1,13,NULL,NULL,'2013-10-25 08:00:46','Listo','Herrera, Fernando Martin',NULL,NULL,3),(34,1,NULL,NULL,1,14,NULL,NULL,'2013-10-25 08:11:49','Listo','Herrera, Fernando Martin',NULL,NULL,3),(35,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-25 21:23:49','Listo','Herrera, Fernando Martin',NULL,NULL,2),(36,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-26 09:27:54','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(37,NULL,NULL,NULL,1,NULL,NULL,NULL,'2013-10-26 09:50:50','Terminado',NULL,NULL,NULL,1),(38,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-26 10:34:30','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(39,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-26 11:01:29','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(40,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-26 11:06:58','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(41,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-26 11:20:28','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(42,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-26 18:48:58','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(43,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-26 18:53:56','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(44,1,NULL,NULL,1,15,NULL,NULL,'2013-10-26 19:01:25','Facturado','Herrera Fernando Martin',NULL,NULL,2),(45,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-26 19:10:26','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(46,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-26 19:31:07','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(47,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-26 19:36:59','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(48,1,NULL,NULL,1,16,NULL,NULL,'2013-10-26 20:20:11','Entregado','Herrera, Fernando Martin',NULL,3,3),(49,1,NULL,NULL,1,17,NULL,NULL,'2013-10-26 20:22:18','Entregado','Herrera, Fernando Martin',NULL,3,3),(50,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-27 10:42:29','Listo','Herrera, Fernando Martin',NULL,NULL,2),(51,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-27 17:13:15','Listo','Herrera, Fernando Martin',NULL,NULL,2),(52,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-27 17:16:23','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(53,1,NULL,NULL,1,18,NULL,NULL,'2013-10-27 17:50:59','Entregado','Herrera, Fernando Martin',NULL,4,3),(54,2,NULL,NULL,1,NULL,NULL,NULL,'2013-10-27 22:30:40','Listo','Herrera, Horacio',NULL,NULL,2),(55,5,NULL,NULL,1,20,NULL,NULL,'2013-10-27 22:40:27','Entregado','Soley, Francisco',NULL,5,3),(56,NULL,NULL,NULL,1,NULL,8,NULL,'2013-10-27 22:44:41','Facturado',NULL,NULL,NULL,1),(57,1,NULL,NULL,1,21,NULL,NULL,'2013-10-27 22:46:51','Entregado','Herrera, Fernando Martin',NULL,6,3),(58,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-27 22:59:57','Listo','Herrera, Fernando Martin',NULL,NULL,2),(59,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-27 23:00:52','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(60,3,NULL,NULL,1,NULL,NULL,NULL,'2013-10-27 23:05:50','Listo','Aquino, Ramona',NULL,NULL,2),(61,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-27 23:06:22','Listo','Herrera, Fernando Martin',NULL,NULL,2),(62,2,NULL,NULL,1,22,NULL,NULL,'2013-10-27 23:07:04','Entregado','Herrera, Horacio',NULL,6,3),(63,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-27 23:08:01','Facturado','Herrera',NULL,NULL,2),(64,NULL,NULL,NULL,1,NULL,6,NULL,'2013-10-27 23:08:43','Listo',NULL,NULL,NULL,1),(65,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-27 23:10:16','Listo','Herrera, Fernando Martin',NULL,NULL,2),(66,1,NULL,NULL,1,NULL,NULL,NULL,'2013-10-28 15:15:51','Listo','Herrera, Fernando Martin',NULL,NULL,2),(67,12,NULL,NULL,1,NULL,NULL,NULL,'2013-11-02 11:19:17','Facturado','Aguero, Sergio',NULL,NULL,2),(68,1,NULL,NULL,1,NULL,NULL,NULL,'2013-11-02 17:19:59','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(69,1,NULL,NULL,1,NULL,NULL,NULL,'2013-11-02 17:57:52','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(70,12,NULL,NULL,1,NULL,NULL,NULL,'2013-11-02 18:40:07','Facturado','Aguero, Sergio',NULL,NULL,2),(71,12,NULL,NULL,1,NULL,NULL,NULL,'2013-11-02 18:43:47','Facturado','Aguero, Sergio',NULL,NULL,2),(72,12,NULL,NULL,1,NULL,NULL,NULL,'2013-11-02 18:45:33','Facturado','Aguero, Sergio',NULL,NULL,2),(73,1,NULL,NULL,1,NULL,NULL,NULL,'2013-11-02 19:15:41','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(74,1,NULL,NULL,1,NULL,NULL,NULL,'2013-11-02 19:19:02','Facturado','Herrera, Fernando Martin',NULL,NULL,2),(75,6,NULL,NULL,1,NULL,NULL,NULL,'2013-11-02 20:36:36','Facturado','Ayala, Agustín',NULL,NULL,2),(76,7,NULL,NULL,1,NULL,NULL,NULL,'2013-11-03 22:11:26','Facturado','Amarilla, Fernando',NULL,NULL,2),(77,9,NULL,NULL,1,NULL,NULL,NULL,'2013-11-04 11:55:20','Facturado','Blanco, Carlos Ezequiel',NULL,NULL,2),(78,7,NULL,NULL,1,NULL,NULL,NULL,'2013-11-04 15:32:17','Facturado','Amarilla, Fernando',NULL,NULL,2),(79,10,NULL,NULL,1,31,NULL,NULL,'2013-11-04 15:40:12','Entregado','Pirlo, Andrea',NULL,7,3),(80,3,NULL,NULL,1,NULL,NULL,NULL,'2013-11-04 15:45:49','Facturado','Aquino, Ramona',NULL,NULL,2),(81,1,NULL,NULL,1,NULL,NULL,NULL,'2013-11-05 21:23:15','Listo','Herrera, Fernando Martin',NULL,NULL,2),(82,NULL,NULL,NULL,1,NULL,15,NULL,'2013-11-06 17:48:50','Listo',NULL,NULL,NULL,1),(84,NULL,NULL,NULL,1,NULL,11,NULL,'2013-11-06 17:52:16','Listo',NULL,NULL,NULL,1),(85,NULL,NULL,NULL,1,NULL,10,NULL,'2013-11-06 17:53:19','Listo',NULL,NULL,NULL,1),(86,7,NULL,NULL,1,NULL,NULL,NULL,'2013-11-07 18:50:34','Listo','Amarilla, Fernando',NULL,NULL,2),(87,3,NULL,NULL,1,33,NULL,NULL,'2013-11-08 18:16:18','Listo','Aquino, Ramona',NULL,NULL,3),(88,12,NULL,NULL,1,NULL,NULL,NULL,'2013-11-25 01:03:32','Listo','Aguero, Sergio',NULL,NULL,2),(89,NULL,NULL,NULL,1,NULL,NULL,NULL,'2013-11-25 01:05:49','Terminado',NULL,NULL,NULL,1),(90,7,NULL,NULL,1,34,NULL,NULL,'2013-11-25 09:11:30','Listo','Amarilla, Fernando',NULL,NULL,3),(91,NULL,NULL,NULL,1,NULL,NULL,NULL,'2013-11-25 09:21:01','Facturado',NULL,NULL,NULL,1),(92,12,NULL,NULL,1,NULL,NULL,NULL,'2013-12-01 00:11:49','Facturado','Aguero, Sergio',NULL,NULL,2),(93,7,NULL,NULL,1,35,NULL,NULL,'2013-12-01 00:12:48','Entregado','Amarilla, Fernando',NULL,8,3),(94,7,NULL,NULL,1,NULL,NULL,NULL,'2013-12-01 00:26:46','Cancelado','Amarilla, Fernando',NULL,NULL,2),(95,9,NULL,NULL,1,36,NULL,NULL,'2013-12-01 00:37:59','Entregado','Blanco, Carlos Ezequiel',NULL,8,3),(96,3,NULL,NULL,1,NULL,NULL,NULL,'2013-12-01 00:57:09','Listo','Aquino, Ramona',NULL,NULL,2),(97,2,NULL,NULL,1,NULL,NULL,NULL,'2013-12-01 00:59:43','Listo','Herrera, Horacio',NULL,NULL,2);
/*!40000 ALTER TABLE `Pedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PedidoDelivery`
--

DROP TABLE IF EXISTS `PedidoDelivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PedidoDelivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fechapedido` datetime DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `solicitante` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `motivoCancelacion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PedidoDelivery`
--

LOCK TABLES `PedidoDelivery` WRITE;
/*!40000 ALTER TABLE `PedidoDelivery` DISABLE KEYS */;
/*!40000 ALTER TABLE `PedidoDelivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PedidoMesa`
--

DROP TABLE IF EXISTS `PedidoMesa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PedidoMesa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fechapedido` datetime DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `solicitante` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `motivoCancelacion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PedidoMesa`
--

LOCK TABLES `PedidoMesa` WRITE;
/*!40000 ALTER TABLE `PedidoMesa` DISABLE KEYS */;
/*!40000 ALTER TABLE `PedidoMesa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PedidoMostrador`
--

DROP TABLE IF EXISTS `PedidoMostrador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PedidoMostrador` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fechapedido` datetime DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `solicitante` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `motivoCancelacion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PedidoMostrador`
--

LOCK TABLES `PedidoMostrador` WRITE;
/*!40000 ALTER TABLE `PedidoMostrador` DISABLE KEYS */;
/*!40000 ALTER TABLE `PedidoMostrador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Permiso`
--

DROP TABLE IF EXISTS `Permiso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Permiso` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `objeto` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `otorgado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_32C79202D60322AC` (`role_id`),
  CONSTRAINT `FK_32C79202D60322AC` FOREIGN KEY (`role_id`) REFERENCES `Rol` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=207 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Permiso`
--

LOCK TABLES `Permiso` WRITE;
/*!40000 ALTER TABLE `Permiso` DISABLE KEYS */;
INSERT INTO `Permiso` VALUES (1,1,'agenda_gestionar_agenda',1),(2,1,'cargo_listar',1),(3,1,'cargo_nuevo',1),(4,1,'cargo_editar',1),(5,1,'cargo_borrar',1),(6,1,'categoriaProductoProduccion_listar',1),(7,1,'categoriaProductoProduccion_nuevo',1),(8,1,'categoriaProductoProduccion_editar',1),(9,1,'categoriaProductoProduccion_borrar',1),(10,1,'categoriaProductoVenta_listar',1),(11,1,'categoriaProductoVenta_nuevo',1),(12,1,'categoriaProductoVenta_editar',1),(13,1,'categoriaProductoVenta_borrar',1),(14,1,'chat_gestionar_chat',1),(15,1,'caja_apertura_y_cierre',1),(16,1,'cliente_listar',1),(17,1,'cliente_nuevo',1),(18,1,'cliente_editar',1),(19,1,'cliente_borrar',1),(20,1,'cocina_gestionar',1),(21,1,'empresa_ver',1),(22,1,'empresa_editar',1),(23,1,'pedido_listar',1),(24,1,'pedido_nuevo',1),(25,1,'pedido_editar',1),(26,1,'pedido_borrar',1),(27,1,'rol_listar',1),(28,1,'rol_nuevo',1),(29,1,'rol_editar',1),(30,1,'rol_borrar',1),(31,1,'tipoCobro_listar',1),(32,1,'tipoCobro_nuevo',1),(33,1,'tipoCobro_editar',1),(34,1,'tipoCobro_borrar',1),(35,1,'tipoDocumento_listar',1),(36,1,'tipoDocumento_nuevo',1),(37,1,'tipoDocumento_editar',1),(38,1,'tipoDocumento_borrar',1),(39,1,'usuario_listar',1),(40,1,'usuario_nuevo',1),(41,1,'usuario_editar',1),(42,1,'usuario_borrar',1),(43,1,'venta_listar',1),(44,1,'venta_nuevo',1),(45,1,'venta_editar',1),(46,1,'venta_borrar',1),(47,2,'auditoria_listar',1),(48,2,'auditoria_elegir_carpeta',1),(49,2,'auditoria_descargar_archivo',1),(50,2,'auditoria_imprimir',1),(51,2,'agenda_gestionar_agenda',1),(52,2,'backup_listar',1),(53,2,'backup_registrar',1),(54,2,'backup_descargar',1),(55,2,'backup_elegir_carpeta',1),(56,2,'backup_imprimir',1),(57,2,'cargo_listar',1),(58,2,'cargo_nuevo',1),(59,2,'cargo_editar',1),(60,2,'cargo_activar',1),(61,2,'cargo_borrar',1),(62,2,'categoriaProductoProduccion_listar',1),(63,2,'categoriaProductoProduccion_nuevo',1),(64,2,'categoriaProductoProduccion_editar',1),(65,2,'categoriaProductoProduccion_borrar',1),(66,2,'categoriaProductoVenta_listar',1),(67,2,'categoriaProductoVenta_nuevo',1),(68,2,'categoriaProductoVenta_editar',1),(69,2,'categoriaProductoVenta_borrar',1),(70,2,'chat_gestionar_chat',1),(71,2,'ciudad_listar',1),(72,2,'ciudad_nuevo',1),(73,2,'ciudad_editar',1),(74,2,'ciudad_borrar',1),(75,2,'compra_listar',1),(76,2,'compra_pago_por_proveedor',1),(77,2,'compra_pago_por_factura',1),(78,2,'compra_nuevo',1),(79,2,'compra_imprimir',1),(80,2,'condiciones IVA_listar',1),(81,2,'condiciones IVA_nuevo',1),(82,2,'condiciones IVA_editar',1),(83,2,'condiciones IVA_activar',1),(84,2,'condiciones IVA_borrar',1),(85,2,'empleado_listar',1),(86,2,'empleado_nuevo',1),(87,2,'empleado_editar',1),(88,2,'empleado_detalles-Acciones_de_pago',1),(89,2,'empleado_Gestión_y_acciones_de_pago',1),(90,2,'empleado_activar',1),(91,2,'empleado_borrar',1),(92,2,'empleado-Imprimir_lista_de_empleados',1),(93,2,'empleado-Imprimir_comprobante_de_pago',1),(94,2,'empleado-Imprimir_detalles-Acciones_de_pago',1),(95,2,'empresa_editar',1),(96,2,'facturaServicio_listar',1),(97,2,'facturaServicio_nuevo',1),(98,2,'facturaServicio_imprimir',1),(99,2,'IVA_listar',1),(100,2,'IVA_nuevo',1),(101,2,'IVA_editar',1),(102,2,'IVA_borrar',1),(103,2,'IVA_activar',1),(104,2,'ingrediente_nuevo',1),(105,2,'ingrediente_editar',1),(106,2,'ingrediente_borrar',1),(107,2,'LibroIVACompra_listar',1),(108,2,'LibroIVACompra_imprimir',1),(109,2,'mantenimiento_listar',1),(110,2,'mantenimiento_nuevo',1),(111,2,'mantenimiento_editar',1),(112,2,'mantenimiento_borrar',1),(113,2,'materiaPrima_listar',1),(114,2,'materiaPrima_nuevo',1),(115,2,'materiaPrima_editar',1),(116,2,'materiaPrima_borrar',1),(117,2,'mercaderia_listar',1),(118,2,'mercaderia_nuevo',1),(119,2,'mercaderia_editar',1),(120,2,'mercaderia_borrar',1),(121,2,'notaPedido_listar',1),(122,2,'notaPedido_nuevo',1),(123,2,'notaPedido_editar',1),(124,2,'notaPedido_imprimir',1),(125,2,'operaciones_listar',1),(126,2,'operaciones_nuevo',1),(127,2,'operaciones_editar',1),(128,2,'operaciones_activar',1),(129,2,'operaciones_borrar',1),(130,2,'pago_listar',1),(131,2,'pago_registrar_salidad_de_caja',1),(132,2,'pago_imprimir',1),(133,2,'plato_listar',1),(134,2,'plato_nuevo',1),(135,2,'plato_editar',1),(136,2,'plato_borrar',1),(137,2,'pre-Elaborado_listar',1),(138,2,'pre-Elaborado_nuevo',1),(139,2,'pre-Elaborado_editar',1),(140,2,'pre-Elaborado_borrar',1),(141,2,'producto_listar_producto_venta',1),(142,2,'producto_listar_producto_prodccion',1),(143,2,'producto_Gestión de menu',1),(144,2,'producto_activar',1),(145,2,'producto_imprimir',1),(146,2,'proveedor_listar',1),(147,2,'proveedor_nuevo',1),(148,2,'proveedor_editar',1),(149,2,'proveedor_borrar',1),(150,2,'proveedor_activar',1),(151,2,'proveedor_imprimir',1),(152,2,'provincia_listar',1),(153,2,'provincia_nuevo',1),(154,2,'provincia_editar',1),(155,2,'provincia_borrar',1),(156,2,'registro_listar',1),(157,2,'registro_registro_producción_por_cantidad',1),(158,2,'registro_registro_producción_por_ingredientes',1),(159,2,'registro_registro_pérdida_de_producción',1),(160,2,'registro_imprimir',1),(161,2,'servicio_listar',1),(162,2,'servicio_nuevo',1),(163,2,'servicio_editar',1),(164,2,'servicio_borrar',1),(165,2,'servicio_activar',1),(166,2,'servicio_imprimir',1),(167,2,'unidad de medida y tasas_listar',1),(168,2,'unidad de medida y tasas_Gestion',1),(169,2,'notificaciones de sistema_Mostrar',1),(170,2,'caja_apertura_y_cierre',1),(171,2,'cliente_listar',1),(172,2,'cliente_nuevo',1),(173,2,'cliente_editar',1),(174,2,'cliente_borrar',1),(175,2,'cocina_gestionar',1),(176,2,'pedido_listar',1),(177,2,'pedido_nuevo',1),(178,2,'pedido_editar',1),(179,2,'pedido_borrar',1),(180,2,'rol_listar',1),(181,2,'rol_nuevo',1),(182,2,'rol_editar',1),(183,2,'rol_borrar',1),(184,2,'rol_activar',1),(185,2,'tipoCobro_listar',1),(186,2,'tipoCobro_nuevo',1),(187,2,'tipoCobro_editar',1),(188,2,'tipoCobro_activar',1),(189,2,'tipoCobro_borrar',1),(190,2,'tipoDocumento_listar',1),(191,2,'tipoDocumento_nuevo',1),(192,2,'tipoDocumento_editar',1),(193,2,'tipoDocumento_borrar',1),(194,2,'usuario_listar',1),(195,2,'usuario_nuevo',1),(196,2,'usuario_editar',1),(197,2,'usuario_borrar',1),(198,2,'usuario_activar',1),(199,2,'usuario_ver_Perfil',1),(200,2,'usuario_cambiar_Contrseña',1),(201,2,'usuario_recuperar_Contrseña',1),(202,2,'usuario_imprimir',1),(203,2,'venta_listar',1),(204,2,'venta_nuevo',1),(205,2,'venta_editar',1),(206,2,'venta_borrar',1);
/*!40000 ALTER TABLE `Permiso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Persona`
--

DROP TABLE IF EXISTS `Persona`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Persona` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `direccion_id` int(11) DEFAULT NULL,
  `dni` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `apellido` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activo` tinyint(1) NOT NULL,
  `discr` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_9E588F07D0A7BD7` (`direccion_id`),
  CONSTRAINT `FK_9E588F07D0A7BD7` FOREIGN KEY (`direccion_id`) REFERENCES `Direccion` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Persona`
--

LOCK TABLES `Persona` WRITE;
/*!40000 ALTER TABLE `Persona` DISABLE KEYS */;
/*!40000 ALTER TABLE `Persona` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Plato`
--

DROP TABLE IF EXISTS `Plato`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Plato` (
  `id` int(11) NOT NULL,
  `imagen_id` int(11) DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `precioCosto` decimal(10,2) DEFAULT NULL,
  `cantidad` decimal(10,2) DEFAULT NULL,
  `precioVenta` decimal(10,2) DEFAULT NULL,
  `cantidadMinima` decimal(10,2) DEFAULT NULL,
  `margen` decimal(10,2) DEFAULT NULL,
  `margenMin` decimal(10,2) DEFAULT NULL,
  `supera` tinyint(1) DEFAULT NULL,
  `superaMin` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_508A1141763C8AA7` (`imagen_id`),
  CONSTRAINT `FK_508A1141763C8AA7` FOREIGN KEY (`imagen_id`) REFERENCES `Image` (`id`),
  CONSTRAINT `FK_508A1141BF396750` FOREIGN KEY (`id`) REFERENCES `Producto` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Plato`
--

LOCK TABLES `Plato` WRITE;
/*!40000 ALTER TABLE `Plato` DISABLE KEYS */;
INSERT INTO `Plato` VALUES (1,2,'Ravioles gigantes',11.00,10.00,11.00,5.00,0.00,0.00,0,0),(2,4,'Lomito con papas',26.60,20.00,12.00,5.00,0.00,10.00,0,0),(6,12,'Hamburguesa',17.00,1000.00,20.40,10.00,20.00,5.00,0,0),(7,14,'Pizza Mozzarela',15.00,1000.00,19.50,100.00,30.00,15.00,0,0),(8,16,'Docena de Empanadas',20.00,1000.00,23.00,100.00,15.00,10.00,0,0),(11,22,'Tallarines con queso',20.00,3000.00,23.00,20.00,15.00,10.00,0,0);
/*!40000 ALTER TABLE `Plato` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PreElaborado`
--

DROP TABLE IF EXISTS `PreElaborado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PreElaborado` (
  `id` int(11) NOT NULL,
  `ingrediente_id` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_E24F592F769E458D` (`ingrediente_id`),
  CONSTRAINT `FK_E24F592F769E458D` FOREIGN KEY (`ingrediente_id`) REFERENCES `Ingrediente` (`id`),
  CONSTRAINT `FK_E24F592FBF396750` FOREIGN KEY (`id`) REFERENCES `Producto` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PreElaborado`
--

LOCK TABLES `PreElaborado` WRITE;
/*!40000 ALTER TABLE `PreElaborado` DISABLE KEYS */;
/*!40000 ALTER TABLE `PreElaborado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Producto`
--

DROP TABLE IF EXISTS `Producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Producto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  `discr` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_5ECD6443521E1991` (`empresa_id`),
  CONSTRAINT `FK_5ECD6443521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Producto`
--

LOCK TABLES `Producto` WRITE;
/*!40000 ALTER TABLE `Producto` DISABLE KEYS */;
INSERT INTO `Producto` VALUES (1,1,'Ravioles',1,'plato'),(2,1,'Lomito',1,'plato'),(3,1,'Coca Cola 3Lts',1,'mercaderia'),(4,1,'Carne',1,'materiaprima'),(5,1,'Huevo',1,'materiaprima'),(6,1,'Hamburguesa',1,'plato'),(7,1,'Pizza Mozzarella',1,'plato'),(8,1,'Docena de Empanadas',1,'plato'),(9,1,'Cerveza Quilmes 1lt',1,'mercaderia'),(10,1,'Levite',1,'mercaderia'),(11,1,'Tallarines con Queso',1,'plato'),(12,1,'Tomate',1,'materiaprima');
/*!40000 ALTER TABLE `Producto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ProductoProduccion`
--

DROP TABLE IF EXISTS `ProductoProduccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ProductoProduccion` (
  `id` int(11) NOT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `iva_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_B73571113397707A` (`categoria_id`),
  KEY `IDX_B7357111F231661A` (`iva_id`),
  CONSTRAINT `FK_B73571113397707A` FOREIGN KEY (`categoria_id`) REFERENCES `CategoriaProductoProduccion` (`id`),
  CONSTRAINT `FK_B7357111BF396750` FOREIGN KEY (`id`) REFERENCES `Producto` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_B7357111F231661A` FOREIGN KEY (`iva_id`) REFERENCES `iva` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProductoProduccion`
--

LOCK TABLES `ProductoProduccion` WRITE;
/*!40000 ALTER TABLE `ProductoProduccion` DISABLE KEYS */;
INSERT INTO `ProductoProduccion` VALUES (4,1,1),(5,1,1),(12,2,1);
/*!40000 ALTER TABLE `ProductoProduccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ProductoVenta`
--

DROP TABLE IF EXISTS `ProductoVenta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ProductoVenta` (
  `id` int(11) NOT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `iva_id` int(11) DEFAULT NULL,
  `tasa_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_587EF6553397707A` (`categoria_id`),
  KEY `IDX_587EF655F231661A` (`iva_id`),
  KEY `IDX_587EF655E20BE1E2` (`tasa_id`),
  CONSTRAINT `FK_587EF6553397707A` FOREIGN KEY (`categoria_id`) REFERENCES `CategoriaProductoVenta` (`id`),
  CONSTRAINT `FK_587EF655BF396750` FOREIGN KEY (`id`) REFERENCES `Producto` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_587EF655E20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`),
  CONSTRAINT `FK_587EF655F231661A` FOREIGN KEY (`iva_id`) REFERENCES `iva` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProductoVenta`
--

LOCK TABLES `ProductoVenta` WRITE;
/*!40000 ALTER TABLE `ProductoVenta` DISABLE KEYS */;
INSERT INTO `ProductoVenta` VALUES (1,1,1,1),(2,3,1,1),(3,2,1,1),(6,3,1,1),(7,3,1,1),(8,3,1,4),(9,2,1,1),(10,2,1,1),(11,1,1,1);
/*!40000 ALTER TABLE `ProductoVenta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Provincia`
--

DROP TABLE IF EXISTS `Provincia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Provincia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa_id` int(11) DEFAULT NULL,
  `nombre` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `porDefecto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_516B70B03A909126` (`nombre`),
  KEY `IDX_516B70B0521E1991` (`empresa_id`),
  CONSTRAINT `FK_516B70B0521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Provincia`
--

LOCK TABLES `Provincia` WRITE;
/*!40000 ALTER TABLE `Provincia` DISABLE KEYS */;
INSERT INTO `Provincia` VALUES (1,NULL,'Misiones','activo',1),(2,NULL,'Corrientes','activo',0),(3,NULL,'Buenos Aires','activo',0),(4,NULL,'Entre Ríos','activo',0),(5,NULL,'Chaco','activo',0),(6,NULL,'Formosa','activo',0),(7,NULL,'Córdoba','activo',0),(8,NULL,'Catamarca','activo',0),(9,NULL,'La Rioja','activo',0),(10,NULL,'Chubut','activo',0),(11,NULL,'Jujuy','activo',0),(12,NULL,'La Pampa','activo',0),(13,NULL,'Mendoza','activo',0),(14,NULL,'Neuquén','activo',0),(15,NULL,'Salta','activo',0),(16,NULL,'San Juan','activo',0),(17,NULL,'San Luis','activo',0),(18,NULL,'Santa Cruz','activo',0),(19,NULL,'Santa Fe','activo',0),(20,NULL,'Santiago del Estero','activo',0),(21,NULL,'Tierra del Fuego','activo',0),(22,NULL,'Tucumán','activo',0),(23,NULL,'Río Negro','activo',0);
/*!40000 ALTER TABLE `Provincia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Recargo`
--

DROP TABLE IF EXISTS `Recargo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Recargo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `porcentaje` decimal(10,2) DEFAULT NULL,
  `importe` decimal(10,2) DEFAULT NULL,
  `tipoPorcentaje` tinyint(1) DEFAULT NULL,
  `tipoImporte` tinyint(1) DEFAULT NULL,
  `bonificacionImporte` decimal(10,2) DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `iva_id` int(11) DEFAULT NULL,
  `ivaIncluido` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_8CD31965F231661A` (`iva_id`),
  CONSTRAINT `FK_8CD31965F231661A` FOREIGN KEY (`iva_id`) REFERENCES `iva` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Recargo`
--

LOCK TABLES `Recargo` WRITE;
/*!40000 ALTER TABLE `Recargo` DISABLE KEYS */;
INSERT INTO `Recargo` VALUES (1,'Envio',NULL,30.00,0,1,0.00,'Recargo por envio','activo',1,NULL);
/*!40000 ALTER TABLE `Recargo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Recibo`
--

DROP TABLE IF EXISTS `Recibo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Recibo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `unCobro_id` int(11) DEFAULT NULL,
  `serie` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `numero` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_45052DCC81CC6317` (`unCobro_id`),
  KEY `IDX_45052DCCDB38439E` (`usuario_id`),
  KEY `IDX_45052DCCDE734E51` (`cliente_id`),
  CONSTRAINT `FK_45052DCC81CC6317` FOREIGN KEY (`unCobro_id`) REFERENCES `Cobro` (`id`),
  CONSTRAINT `FK_45052DCCDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`),
  CONSTRAINT `FK_45052DCCDE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Cliente` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Recibo`
--

LOCK TABLES `Recibo` WRITE;
/*!40000 ALTER TABLE `Recibo` DISABLE KEYS */;
INSERT INTO `Recibo` VALUES (1,NULL,1,'2013-11-03 00:00:00','Herrera, Fernando Martin',NULL,20.25,NULL,'0001','00000001'),(2,1,12,'2013-11-03 00:00:00','Aguero, Sergio',NULL,31.00,NULL,'0001','00000005'),(3,1,3,'2013-11-04 00:00:00','Aquino, Ramona',NULL,20.00,NULL,'0001','00000002'),(4,1,3,'2013-11-04 00:00:00','Aquino, Ramona',NULL,10.00,NULL,'0001','00000003'),(5,1,6,'2013-11-16 00:00:00','Ayala, Agustín',NULL,12.00,NULL,'0001','00000004');
/*!40000 ALTER TABLE `Recibo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Redireccion`
--

DROP TABLE IF EXISTS `Redireccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Redireccion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `parametros` longtext COLLATE utf8_unicode_ci COMMENT '(DC2Type:array)',
  `usuarioDe_id` int(11) DEFAULT NULL,
  `usuarioA_id` int(11) DEFAULT NULL,
  `visto` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_6916B006CAF6188C` (`usuarioDe_id`),
  KEY `IDX_6916B006AA3F0B0F` (`usuarioA_id`),
  CONSTRAINT `FK_6916B006AA3F0B0F` FOREIGN KEY (`usuarioA_id`) REFERENCES `Usuario` (`id`),
  CONSTRAINT `FK_6916B006CAF6188C` FOREIGN KEY (`usuarioDe_id`) REFERENCES `Usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Redireccion`
--

LOCK TABLES `Redireccion` WRITE;
/*!40000 ALTER TABLE `Redireccion` DISABLE KEYS */;
INSERT INTO `Redireccion` VALUES (2,'http://localhost/SisGG/web/app_dev.php/editarPedidoMesa?idMesa=2','b:0;',1,1,1),(3,'http://symfony.com/doc/current/reference/forms/types/entity.html','b:0;',1,1,1),(4,'http://symfony.com/doc/current/reference/forms/types/entity.html','b:0;',1,1,1),(5,'http://symfony.com/doc/current/reference/forms/types/entity.html','b:0;',1,1,1),(6,'http://symfony.com/doc/current/reference/forms/types/entity.html','b:0;',1,3,1),(7,'http://symfony.com/doc/current/reference/forms/types/entity.html','b:0;',1,3,1),(8,'http://symfony.com/doc/current/reference/forms/types/entity.html','b:0;',1,1,1),(9,'http://symfony.com/doc/current/reference/forms/types/entity.html','b:0;',1,1,1),(10,'http://symfony.com/doc/current/reference/forms/types/entity.html','b:0;',1,1,1),(11,'http://symfony.com/doc/current/reference/forms/types/entity.html','b:0;',1,1,1),(12,'http://symfony.com/doc/current/reference/forms/types/entity.html','b:0;',1,1,1),(13,'http://symfony.com/doc/current/reference/forms/types/entity.html','b:0;',1,1,1),(14,'http://symfony.com/doc/current/reference/forms/types/entity.html','b:0;',1,1,1),(15,'http://symfony.com/doc/current/reference/forms/types/entity.html','b:0;',1,1,1),(16,'http://symfony.com/doc/current/reference/forms/types/entity.html','b:0;',1,1,1),(17,'http://192.168.1.22/SisGG/web/app.php/editarPedidoMostrador?id=86','b:0;',1,1,1),(18,'http://192.168.1.22/SisGG/web/app.php/editarPedidoMostrador?id=86','b:0;',1,1,1),(19,'http://192.168.1.22/SisGG/web/app.php/editarPedidoMostrador?id=86','b:0;',1,1,1),(20,'http://192.168.1.22/SisGG/web/app.php/editarPedidoMostrador?id=86','b:0;',1,1,1),(21,'http://192.168.1.22/SisGG/web/app.php/editarPedidoMostrador?id=86','b:0;',1,1,1),(22,'/SisGG/web/app.php/detallesPedidoMostradorDelivery?idPedido=81','b:0;',1,1,1),(23,'/SisGG/web/app.php/detallesPedidoMostradorDelivery?idPedido=87','b:0;',1,1,1),(24,'/SisGG/web/app.php/detallesPedidoMostradorDelivery?idPedido=61','b:0;',1,1,1),(25,'http://192.168.1.140/SisGG/web/app.php/editarPedidoMostrador?id=86','b:0;',1,1,1),(26,'/SisGG/web/app.php/detallesPedidoMostradorDelivery?idPedido=60','b:0;',1,1,1),(27,'/SisGG/web/app.php/detallesPedidoMostradorDelivery?idPedido=60','b:0;',1,1,1),(28,'/SisGG/web/app.php/detallesPedidoMostradorDelivery?idPedido=60','b:0;',1,1,1),(29,'/SisGG/web/app.php/detallesPedidoMostradorDelivery?idPedido=60','b:0;',1,1,1),(30,'/SisGG/web/app.php/detallesPedidoMostradorDelivery?idPedido=60','b:0;',1,1,1),(31,'/SisGG/web/app.php/detallesPedidoMostradorDelivery?idPedido=60','b:0;',1,1,1),(32,'/SisGG/web/app.php/detallesPedidoMostradorDelivery?idPedido=60','b:0;',1,1,1),(33,'/SisGG/web/app.php/detallesPedidoMostradorDelivery?idPedido=60','b:0;',1,1,1);
/*!40000 ALTER TABLE `Redireccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RegistroEnvio`
--

DROP TABLE IF EXISTS `RegistroEnvio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RegistroEnvio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empleado_id` int(11) DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `totalPedidos` decimal(10,2) DEFAULT NULL,
  `totalRendido` decimal(10,2) DEFAULT NULL,
  `numero` int(11) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `fechaRendicion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_938B809A952BE730` (`empleado_id`),
  CONSTRAINT `FK_938B809A952BE730` FOREIGN KEY (`empleado_id`) REFERENCES `persona_empleado` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RegistroEnvio`
--

LOCK TABLES `RegistroEnvio` WRITE;
/*!40000 ALTER TABLE `RegistroEnvio` DISABLE KEYS */;
INSERT INTO `RegistroEnvio` VALUES (1,2,'activo',24.85,24.85,NULL,'2013-10-21 19:01:23','2013-11-03 22:18:55'),(2,2,'activo',59.00,59.00,NULL,'2013-10-21 19:42:10','2013-11-03 22:18:41'),(3,2,'activo',71.00,71.00,NULL,'2013-10-26 20:32:49','2013-10-27 19:42:50'),(4,2,'activo',24.00,24.00,NULL,'2013-10-27 18:55:30','2013-10-27 19:18:14'),(5,2,'activo',95.00,95.00,NULL,'2013-10-27 22:43:23','2013-10-27 22:43:52'),(6,2,'activo',88.00,88.00,NULL,'2013-10-28 14:15:21','2013-11-03 22:18:27'),(7,2,'activo',42.00,42.00,NULL,'2013-11-04 15:41:28','2013-11-04 15:43:06'),(8,2,'activo',83.00,NULL,NULL,'2013-12-01 00:40:49',NULL);
/*!40000 ALTER TABLE `RegistroEnvio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Rol`
--

DROP TABLE IF EXISTS `Rol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Rol` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Rol`
--

LOCK TABLES `Rol` WRITE;
/*!40000 ALTER TABLE `Rol` DISABLE KEYS */;
INSERT INTO `Rol` VALUES (1,'Administrador',0),(2,'Admin',1);
/*!40000 ALTER TABLE `Rol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Salida`
--

DROP TABLE IF EXISTS `Salida`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Salida` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `caja_id` int(11) DEFAULT NULL,
  `pago_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_9258C27E63FB8380` (`pago_id`),
  KEY `IDX_9258C27EDB38439E` (`usuario_id`),
  KEY `IDX_9258C27E2D82B651` (`caja_id`),
  CONSTRAINT `FK_9258C27E2D82B651` FOREIGN KEY (`caja_id`) REFERENCES `Caja` (`id`),
  CONSTRAINT `FK_9258C27E63FB8380` FOREIGN KEY (`pago_id`) REFERENCES `pago` (`id`),
  CONSTRAINT `FK_9258C27EBF396750` FOREIGN KEY (`id`) REFERENCES `Movimiento` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_9258C27EDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Salida`
--

LOCK TABLES `Salida` WRITE;
/*!40000 ALTER TABLE `Salida` DISABLE KEYS */;
INSERT INTO `Salida` VALUES (4,1,1,NULL),(6,1,1,NULL),(8,1,1,NULL),(10,1,1,NULL),(12,1,1,NULL),(14,1,1,NULL),(16,1,1,NULL),(18,1,1,NULL),(21,1,1,NULL),(23,1,1,NULL),(25,1,1,NULL),(29,1,1,NULL),(31,1,1,NULL),(33,1,1,NULL),(35,1,1,NULL),(37,1,1,NULL),(41,1,1,NULL),(43,1,1,NULL),(56,1,1,NULL),(58,1,1,NULL),(60,1,1,NULL),(62,1,1,NULL),(64,1,1,NULL),(66,1,1,NULL),(73,1,1,NULL),(80,1,1,NULL),(96,1,1,NULL);
/*!40000 ALTER TABLE `Salida` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Sector`
--

DROP TABLE IF EXISTS `Sector`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Sector` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Sector`
--

LOCK TABLES `Sector` WRITE;
/*!40000 ALTER TABLE `Sector` DISABLE KEYS */;
INSERT INTO `Sector` VALUES (1,'Principal','activo'),(2,'Nuevo','activo');
/*!40000 ALTER TABLE `Sector` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Solicitud`
--

DROP TABLE IF EXISTS `Solicitud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Solicitud` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `encabezado` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `respuesta` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Solicitud`
--

LOCK TABLES `Solicitud` WRITE;
/*!40000 ALTER TABLE `Solicitud` DISABLE KEYS */;
/*!40000 ALTER TABLE `Solicitud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SueldoEmpleado`
--

DROP TABLE IF EXISTS `SueldoEmpleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SueldoEmpleado` (
  `id` int(11) NOT NULL,
  `inicio` date NOT NULL,
  `fin` date NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_D96EAFE3BF396750` FOREIGN KEY (`id`) REFERENCES `mov_empleado` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SueldoEmpleado`
--

LOCK TABLES `SueldoEmpleado` WRITE;
/*!40000 ALTER TABLE `SueldoEmpleado` DISABLE KEYS */;
INSERT INTO `SueldoEmpleado` VALUES (1,'2013-10-01','2013-10-21');
/*!40000 ALTER TABLE `SueldoEmpleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tanda`
--

DROP TABLE IF EXISTS `Tanda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Tanda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cocina_id` int(11) DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_F14617372311565A` (`cocina_id`),
  CONSTRAINT `FK_F14617372311565A` FOREIGN KEY (`cocina_id`) REFERENCES `Cocina` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tanda`
--

LOCK TABLES `Tanda` WRITE;
/*!40000 ALTER TABLE `Tanda` DISABLE KEYS */;
INSERT INTO `Tanda` VALUES (1,1,'Vigente'),(2,NULL,'Vigente');
/*!40000 ALTER TABLE `Tanda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Telefono`
--

DROP TABLE IF EXISTS `Telefono`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Telefono` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) DEFAULT NULL,
  `persona_id` int(11) DEFAULT NULL,
  `empleado_id` int(11) DEFAULT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `nacional` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `caracteristica` int(11) NOT NULL,
  `numero` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_38916829DE734E51` (`cliente_id`),
  KEY `IDX_38916829F5F88DB9` (`persona_id`),
  KEY `IDX_38916829952BE730` (`empleado_id`),
  KEY `IDX_38916829CB305D73` (`proveedor_id`),
  KEY `IDX_38916829521E1991` (`empresa_id`),
  CONSTRAINT `FK_38916829521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_38916829952BE730` FOREIGN KEY (`empleado_id`) REFERENCES `persona_empleado` (`id`),
  CONSTRAINT `FK_38916829CB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedor` (`id`),
  CONSTRAINT `FK_38916829DE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Cliente` (`id`),
  CONSTRAINT `FK_38916829F5F88DB9` FOREIGN KEY (`persona_id`) REFERENCES `Persona` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Telefono`
--

LOCK TABLES `Telefono` WRITE;
/*!40000 ALTER TABLE `Telefono` DISABLE KEYS */;
INSERT INTO `Telefono` VALUES (1,NULL,NULL,NULL,NULL,NULL,'+54',376,4375872),(2,NULL,NULL,NULL,NULL,NULL,'+54',376,4570733),(3,NULL,NULL,NULL,NULL,NULL,'+54',376,4355883),(4,NULL,NULL,NULL,NULL,NULL,'+54',376,11211111),(5,NULL,NULL,NULL,NULL,NULL,'+54',376,45789887),(6,NULL,NULL,NULL,NULL,NULL,'+54',376,457874),(7,NULL,NULL,NULL,NULL,NULL,'+54',376,8888888),(8,NULL,NULL,NULL,NULL,NULL,'+54',376,4354111),(9,NULL,NULL,NULL,NULL,NULL,'+54',376,857445),(10,NULL,NULL,NULL,NULL,NULL,'+54',376,487454),(11,NULL,NULL,NULL,NULL,NULL,'+54',376,452524),(12,NULL,NULL,NULL,NULL,NULL,'+54',376,4254121),(13,NULL,NULL,NULL,NULL,NULL,'+54',376,425121),(14,NULL,NULL,NULL,NULL,1,'+54',376,4211511);
/*!40000 ALTER TABLE `Telefono` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TipoCobro`
--

DROP TABLE IF EXISTS `TipoCobro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TipoCobro` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `liquido` tinyint(1) DEFAULT NULL,
  `editable` tinyint(1) DEFAULT NULL,
  `darCambio` tinyint(1) DEFAULT NULL,
  `montoMinimo` decimal(10,2) DEFAULT NULL,
  `montoMaximo` decimal(10,2) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_E4986FDF521E1991` (`empresa_id`),
  CONSTRAINT `FK_E4986FDF521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TipoCobro`
--

LOCK TABLES `TipoCobro` WRITE;
/*!40000 ALTER TABLE `TipoCobro` DISABLE KEYS */;
INSERT INTO `TipoCobro` VALUES (1,1,'Efectivo registrable','Implica un movimiento en Caja',1,0,1,NULL,NULL,1),(2,1,'Efectivo no registrable','No implica un movimiento en caja',0,0,1,NULL,NULL,1),(3,1,'Tarjeta de Credito','Tarjeta de Credito',1,NULL,1,NULL,NULL,1),(4,NULL,'Cheque','Cheque',1,NULL,1,NULL,NULL,1);
/*!40000 ALTER TABLE `TipoCobro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TipoDocumento`
--

DROP TABLE IF EXISTS `TipoDocumento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TipoDocumento` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `abreviatura` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TipoDocumento`
--

LOCK TABLES `TipoDocumento` WRITE;
/*!40000 ALTER TABLE `TipoDocumento` DISABLE KEYS */;
INSERT INTO `TipoDocumento` VALUES (1,'Documento Nacional de Identidad','DNI','inactivo');
/*!40000 ALTER TABLE `TipoDocumento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TipoFactura`
--

DROP TABLE IF EXISTS `TipoFactura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TipoFactura` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nomenclatura` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `codigo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `discriminarIva` tinyint(1) DEFAULT NULL,
  `notaCreditoAnulacion` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TipoFactura`
--

LOCK TABLES `TipoFactura` WRITE;
/*!40000 ALTER TABLE `TipoFactura` DISABLE KEYS */;
INSERT INTO `TipoFactura` VALUES (1,'Factura A','Factura extendida por MONOTRIBUTISTA a RESPONSABLE INSCRIPTO, CONSUMIDOR FINAL, MONOTRIBUTISTA ó EXCENTO','A','001',1,1),(2,'Factura B',NULL,'B','006',0,1),(3,'Factura C',NULL,'C','011',0,0);
/*!40000 ALTER TABLE `TipoFactura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TipoOperacion`
--

DROP TABLE IF EXISTS `TipoOperacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TipoOperacion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TipoOperacion`
--

LOCK TABLES `TipoOperacion` WRITE;
/*!40000 ALTER TABLE `TipoOperacion` DISABLE KEYS */;
INSERT INTO `TipoOperacion` VALUES (1,'Venta','Operación que representa una venta por parte de la empresa a un cliente'),(2,'Compra','Operación que representa una compra por parte de la empresa a un proveedor');
/*!40000 ALTER TABLE `TipoOperacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TipoPedido`
--

DROP TABLE IF EXISTS `TipoPedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TipoPedido` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TipoPedido`
--

LOCK TABLES `TipoPedido` WRITE;
/*!40000 ALTER TABLE `TipoPedido` DISABLE KEYS */;
INSERT INTO `TipoPedido` VALUES (1,'mesa'),(2,'mostrador'),(3,'delivery');
/*!40000 ALTER TABLE `TipoPedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Usuario`
--

DROP TABLE IF EXISTS `Usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `apellido` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `salt` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `discr` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_EDD889C1D60322AC` (`role_id`),
  KEY `IDX_EDD889C1521E1991` (`empresa_id`),
  CONSTRAINT `FK_EDD889C1521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_EDD889C1D60322AC` FOREIGN KEY (`role_id`) REFERENCES `Rol` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Usuario`
--

LOCK TABLES `Usuario` WRITE;
/*!40000 ALTER TABLE `Usuario` DISABLE KEYS */;
INSERT INTO `Usuario` VALUES (1,1,NULL,'Example','Example','example@example.com','admin','549e5b2ca03325d5d5e202462be80bbe','b8c22ebeb3985016a61ad273288d947b9d8082a2',1,'usuario'),(2,1,1,'Herrea','Fernando','martinfer.69@gmail.com','herrea.fernando','64833ab9e4a4cfe535833a235a6b00f0','ad6b05612ae51d2520f23238fbecf2f7718aa1d0',1,'persona_empleado'),(3,1,1,'Sergio','Sanabria','sergio.sanabria@gmial.com','sergio.sanabria','97296572fc8ae54129dd0f264ddd49cd','07c03bb05905933b8691d7ba68b3b92a78ca622d',1,'persona_empleado'),(4,2,1,'ElLoco','Fabio','monito@gmail.com','elloco.fabio','1cc4e3f92f34501e1d1c60b01f3d9fa1','dbc3d6a46ae7817f77f2a7bcf75c8830594e12e7',1,'usuario');
/*!40000 ALTER TABLE `Usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Valor`
--

DROP TABLE IF EXISTS `Valor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Valor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campo_id` int(11) DEFAULT NULL,
  `cobro_id` int(11) DEFAULT NULL,
  `pago_id` int(11) DEFAULT NULL,
  `valor` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_EF48082CA17A385C` (`campo_id`),
  KEY `IDX_EF48082C7AD3A2B4` (`cobro_id`),
  KEY `IDX_EF48082C63FB8380` (`pago_id`),
  CONSTRAINT `FK_EF48082C63FB8380` FOREIGN KEY (`pago_id`) REFERENCES `pago` (`id`),
  CONSTRAINT `FK_EF48082C7AD3A2B4` FOREIGN KEY (`cobro_id`) REFERENCES `Cobro` (`id`),
  CONSTRAINT `FK_EF48082CA17A385C` FOREIGN KEY (`campo_id`) REFERENCES `Campo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Valor`
--

LOCK TABLES `Valor` WRITE;
/*!40000 ALTER TABLE `Valor` DISABLE KEYS */;
INSERT INTO `Valor` VALUES (1,1,NULL,NULL,'0001'),(2,1,NULL,NULL,'0002'),(3,1,19,NULL,'0001'),(4,1,36,NULL,'0003'),(5,1,43,NULL,'0012'),(6,1,51,NULL,'0015'),(7,1,53,NULL,'0003');
/*!40000 ALTER TABLE `Valor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Venta`
--

DROP TABLE IF EXISTS `Venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Venta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `pedido_id` int(11) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cuit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `serie` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `numero` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `tipoOperacion_id` int(11) DEFAULT NULL,
  `tipoFactura_id` int(11) DEFAULT NULL,
  `condicionIva_id` int(11) DEFAULT NULL,
  `operacion_id` int(11) DEFAULT NULL,
  `cambio` decimal(10,2) DEFAULT NULL,
  `condicionIvaEmpresa_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_4E26C1514854653A` (`pedido_id`),
  KEY `IDX_4E26C151DB38439E` (`usuario_id`),
  KEY `IDX_4E26C151DE734E51` (`cliente_id`),
  KEY `IDX_4E26C151957DD03D` (`tipoOperacion_id`),
  KEY `IDX_4E26C15110E064DC` (`tipoFactura_id`),
  KEY `IDX_4E26C151F60CF12A` (`condicionIva_id`),
  KEY `IDX_4E26C1515C25E126` (`condicionIvaEmpresa_id`),
  KEY `IDX_4E26C151E6D597C3` (`operacion_id`),
  CONSTRAINT `FK_4E26C15110E064DC` FOREIGN KEY (`tipoFactura_id`) REFERENCES `TipoFactura` (`id`),
  CONSTRAINT `FK_4E26C1514854653A` FOREIGN KEY (`pedido_id`) REFERENCES `Pedido` (`id`),
  CONSTRAINT `FK_4E26C1515C25E126` FOREIGN KEY (`condicionIvaEmpresa_id`) REFERENCES `CondicionIva` (`id`),
  CONSTRAINT `FK_4E26C151957DD03D` FOREIGN KEY (`tipoOperacion_id`) REFERENCES `TipoOperacion` (`id`),
  CONSTRAINT `FK_4E26C151DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`),
  CONSTRAINT `FK_4E26C151DE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Cliente` (`id`),
  CONSTRAINT `FK_4E26C151E6D597C3` FOREIGN KEY (`operacion_id`) REFERENCES `Operacion` (`id`),
  CONSTRAINT `FK_4E26C151F60CF12A` FOREIGN KEY (`condicionIva_id`) REFERENCES `CondicionIva` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Venta`
--

LOCK TABLES `Venta` WRITE;
/*!40000 ALTER TABLE `Venta` DISABLE KEYS */;
INSERT INTO `Venta` VALUES (1,NULL,1,10,'2013-10-21 00:00:00','Herrera, Fernando Martin',NULL,'Cobrado',NULL,'0001','00000001',NULL,1,1,NULL,NULL,NULL),(3,NULL,1,9,'2013-10-21 00:00:00','Herrera, Fernando Martin',NULL,'Cobrado',NULL,'0001','00000002',NULL,1,1,NULL,NULL,NULL),(5,NULL,1,7,'2013-10-21 00:00:00','Herrera, Fernando Martin',NULL,'Cobrado',NULL,'0001','00000003',NULL,1,1,NULL,NULL,NULL),(6,NULL,1,4,'2013-10-21 00:00:00','Herrera, Fernando Martin',NULL,'Cobrado',NULL,'0001','00000004',NULL,1,1,NULL,NULL,NULL),(7,NULL,2,8,'2013-10-21 00:00:00','Herrera, Horacio',NULL,'Cobrado',NULL,'0001','00000005',NULL,1,1,NULL,NULL,NULL),(9,NULL,2,5,'2013-10-21 00:00:00','Herrera, Horacio',NULL,'Cobrado',NULL,'0001','00000006',NULL,2,1,NULL,NULL,NULL),(10,NULL,2,6,'2013-10-21 00:00:00','Herrera, Horacio',NULL,'Cobrado',NULL,'0001','00000007',NULL,2,1,NULL,NULL,NULL),(11,NULL,1,12,'2013-10-21 00:00:00','Herrera, Fernando Martin',NULL,'Cobrado',145.05,'0001','00000008',NULL,1,1,NULL,NULL,NULL),(12,NULL,1,13,'2013-10-21 00:00:00','Herrera, Fernando Martin',NULL,'Cobrado',96.62,'0001','00000009',NULL,1,1,NULL,NULL,NULL),(13,NULL,2,14,'2013-10-21 00:00:00','Herrera, Horacio',NULL,'Cobrado',20.46,'0001','00000010',NULL,2,1,NULL,NULL,NULL),(14,NULL,1,15,'2013-10-21 00:00:00','Herrera, Fernando Martin',NULL,'Cobrado',113.10,'0001','00000011',NULL,2,1,NULL,NULL,NULL),(15,NULL,1,16,'2013-10-21 00:00:00','Herrera, Fernando Martin',NULL,'Cobrado',33.85,'0001','00000012',NULL,1,1,NULL,NULL,NULL),(17,NULL,NULL,2,'2013-10-21 00:00:00','Consumidor Final',NULL,'Cobrado',45.40,'0001','00000013',NULL,2,3,NULL,NULL,NULL),(18,NULL,2,17,'2013-10-21 00:00:00','Herrera, Horacio',NULL,'Cobrado',19.70,'0001','00000013',NULL,1,1,NULL,NULL,NULL),(19,NULL,1,21,'2013-10-21 00:00:00','Herrera, Fernando Martin',NULL,'Cobrado',18.00,'0001','00000013',NULL,1,1,NULL,NULL,NULL),(20,NULL,1,22,'2013-10-21 00:00:00','Herrera, Fernando Martin',NULL,'Cobrado',48.00,'0001','00000013',NULL,1,1,NULL,NULL,NULL),(21,NULL,2,NULL,'2013-10-21 00:00:00','Herrera, Horacio',NULL,'Anulado',360.00,'0001','00000013',NULL,3,1,NULL,NULL,NULL),(22,NULL,NULL,NULL,'2013-10-21 00:00:00','Consumidor Final',NULL,'Anulado',23.00,'0001','00000014',NULL,3,3,NULL,NULL,NULL),(23,NULL,2,19,'2013-10-21 00:00:00','Herrera, Horacio',NULL,'Cobrado',18.00,'0001','00000015',NULL,3,1,NULL,NULL,NULL),(24,NULL,1,18,'2013-10-22 00:00:00','Herrera, Fernando Martin',NULL,'Cobrado',260.00,'0001','00000016',NULL,3,1,NULL,NULL,NULL),(25,NULL,3,25,'2013-10-22 00:00:00','Aquino, Ramona',NULL,'Cobrado',53.00,'0001','00000017',NULL,3,3,NULL,NULL,NULL),(26,NULL,3,26,'2013-10-22 00:00:00','Aquino, Ramona',NULL,'',60.00,'0001','00000018',NULL,3,3,NULL,NULL,NULL),(27,NULL,3,27,'2013-10-22 00:00:00','Aquino, Ramona',NULL,'Anulado',59.00,'0001','00000019',NULL,3,3,NULL,NULL,NULL),(28,NULL,3,28,'2013-10-22 00:00:00','Aquino, Ramona',NULL,'Cobrado',66.00,'0001','00000020',NULL,3,3,NULL,NULL,NULL),(30,1,1,35,'2013-10-26 00:00:00','Herrera, Fernando Martin',NULL,NULL,44.50,'0001','00000021',1,3,1,5,NULL,2),(34,1,1,36,'2013-10-26 00:00:00','Herrera, Fernando Martin',NULL,NULL,79.50,'0001','00000021',1,3,1,5,NULL,2),(35,1,1,38,'2013-10-26 00:00:00','Herrera, Fernando Martin',NULL,NULL,72.00,'0001','00000020',1,3,1,5,NULL,2),(36,1,1,39,'2013-10-26 00:00:00','Herrera, Fernando Martin',NULL,NULL,79.50,'0001','00000020',1,3,1,5,NULL,2),(37,1,1,40,'2013-10-26 00:00:00','Herrera, Fernando Martin',NULL,NULL,79.50,'0001','00000022',1,3,1,5,NULL,2),(38,1,1,41,'2013-10-26 00:00:00','Herrera, Fernando Martin',NULL,NULL,79.50,'0001','00000014',1,1,1,1,NULL,1),(39,1,1,42,'2013-10-26 00:00:00','Herrera, Fernando Martin',NULL,NULL,106.50,'0001','00000015',1,1,1,1,NULL,1),(40,1,1,43,'2013-10-26 00:00:00','Herrera, Fernando Martin',NULL,NULL,71.00,'0001','00000016',1,1,1,1,NULL,1),(41,1,1,44,'2013-10-26 00:00:00','Herrera Fernando Martin',NULL,NULL,71.00,'0001','00000017',1,1,1,1,NULL,1),(42,1,1,45,'2013-10-26 00:00:00','Herrera, Fernando Martin',NULL,NULL,53.00,'0001','00000018',1,1,1,1,NULL,1),(43,1,1,46,'2013-10-26 00:00:00','Herrera, Fernando Martin',NULL,NULL,53.00,'0001','00000019',1,1,1,1,NULL,1),(44,1,1,47,'2013-10-26 00:00:00','Herrera, Fernando Martin',NULL,NULL,53.00,'0001','00000020',1,1,1,1,NULL,1),(45,1,1,48,'2013-10-26 00:00:00','Herrera, Fernando Martin',NULL,NULL,71.00,'0001','00000021',1,1,1,1,NULL,1),(47,1,1,49,'2013-10-26 00:00:00','Herrera, Fernando Martin',NULL,'Cobrado',71.00,'0001','00000022',1,1,1,1,NULL,1),(48,1,1,50,'2013-10-27 00:00:00','Herrera, Fernando Martin',NULL,'Anulado',71.00,'0001','00000023',1,3,1,5,NULL,2),(51,1,4,30,'2013-10-27 00:00:00','Herrera, Horacio',NULL,'Cobrado',66.00,'0001','00000024',1,3,1,3,NULL,2),(53,1,1,NULL,'2013-10-27 00:00:00','Herrera, Fernando Martin',NULL,'Anulado',66.00,'0001','00000023',1,1,1,1,NULL,1),(54,1,1,52,'2013-10-27 00:00:00','Herrera, Fernando Martin','20-34366629-3','Cobrado',66.00,'0001','00000024',1,1,1,1,NULL,1),(56,1,1,NULL,'2013-10-27 00:00:00','Herrera, Fernando Martin','20-34366629-3','Anulado',66.00,'0001','00000025',1,1,1,1,NULL,1),(57,1,2,NULL,'2013-10-27 00:00:00','Herrera, Horacio','20-3525526-3','Anulado',60.00,'0001','00000026',1,1,1,1,NULL,1),(58,1,5,55,'2013-10-27 00:00:00','Soley, Francisco',NULL,'Cobrado',95.00,'0001','00000014',1,2,3,4,NULL,1),(59,1,1,59,'2013-10-27 00:00:00','Herrera, Fernando Martin','20-34366629-3','Cobrado',57.95,'0001','00000027',1,1,1,1,NULL,1),(60,1,4,37,'2013-10-28 00:00:00','Consumidor Final',NULL,'Cobrado',23.00,'0001','00000025',1,3,3,3,NULL,2),(61,1,2,NULL,'2013-10-28 00:00:00','Herrera, Horacio',NULL,'Anulado',64.00,'0001','00000026',1,3,1,5,NULL,2),(62,1,1,NULL,'2013-10-28 00:00:00','Herrera, Fernando Martin','20-34366629-3','Anulado',24.00,'0001','00000027',1,3,1,5,NULL,2),(63,1,12,67,'2013-11-02 00:00:00','Aguero, Sergio',NULL,'Cobrado',40.50,'0001','00000028',1,3,3,3,NULL,2),(64,1,1,68,'2013-11-02 00:00:00','Herrera, Fernando Martin','20-34366629-3','Sin Cobrar',20.25,'0001','00000029',1,3,1,5,NULL,2),(65,1,1,69,'2013-11-02 00:00:00','Herrera, Fernando Martin','20-34366629-3','Sin Cobrar',20.25,'0001','00000030',1,3,1,5,NULL,2),(66,1,12,70,'2013-11-02 00:00:00','Aguero, Sergio',NULL,'Sin Cobrar',30.00,'0001','00000031',1,3,3,3,NULL,2),(67,1,12,71,'2013-11-02 00:00:00','Aguero, Sergio',NULL,'Sin Cobrar',10.50,'0001','00000032',1,3,3,3,NULL,2),(68,1,12,72,'2013-11-02 00:00:00','Aguero, Sergio',NULL,'Parcialmente Cobrado',40.50,'0001','00000033',1,3,3,3,NULL,2),(69,1,1,73,'2013-11-02 00:00:00','Herrera, Fernando Martin','20-34366629-3','Sin Cobrar',5.25,'0001','00000034',1,3,1,5,NULL,2),(70,1,1,74,'2013-11-02 00:00:00','Herrera, Fernando Martin','20-34366629-3','Sin Cobrar',15.00,'0001','00000035',1,3,1,5,NULL,2),(71,1,6,75,'2013-11-03 00:00:00','Ayala, Agustín',NULL,'Sin Cobrar',12.00,'0001','00000036',1,3,3,3,NULL,2),(72,1,7,76,'2013-11-03 00:00:00','Amarilla, Fernando',NULL,'Cobrado',12.00,'0001','00000037',1,3,3,3,NULL,2),(73,1,9,77,'2013-11-04 00:00:00','Blanco, Carlos Ezequiel',NULL,'Cobrado',32.40,'0001','00000038',1,3,3,3,NULL,2),(74,1,7,78,'2013-11-04 00:00:00','Amarilla, Fernando',NULL,'Cobrado',48.00,'0001','00000039',1,3,3,3,NULL,2),(75,1,4,63,'2013-11-04 00:00:00','Consumidor Final',NULL,'Cobrado',62.40,'0001','00000040',1,3,3,3,NULL,2),(76,1,3,80,'2013-11-04 00:00:00','Aquino, Ramona',NULL,'Sin Cobrar',30.00,'0001','00000041',1,3,3,3,NULL,2),(77,1,7,23,'2013-11-23 00:00:00','Amarilla Fernando',NULL,'Cobrado',23.00,'0001','00000015',1,2,3,4,NULL,1),(78,1,7,56,'2013-11-23 00:00:00','Amarilla Fernando',NULL,'Sin Cobrar',23.00,'0001','00000016',1,2,3,4,NULL,1),(79,1,4,89,'2013-11-25 00:00:00','Consumidor Final',NULL,'Cobrado',11.00,'0001','00000017',1,2,3,4,NULL,1),(80,1,4,91,'2013-11-30 00:00:00','Consumidor Final',NULL,'Cobrado',34.00,'0001','00000018',1,2,3,4,NULL,1),(81,1,12,92,'2013-12-01 00:00:00','Aguero, Sergio',NULL,'Cobrado',34.00,'0001','00000019',1,2,3,4,NULL,1);
/*!40000 ALTER TABLE `Venta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente_descuentocliente`
--

DROP TABLE IF EXISTS `cliente_descuentocliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente_descuentocliente` (
  `cliente_id` int(11) NOT NULL,
  `descuentocliente_id` int(11) NOT NULL,
  PRIMARY KEY (`cliente_id`,`descuentocliente_id`),
  KEY `IDX_281F7BF9DE734E51` (`cliente_id`),
  KEY `IDX_281F7BF96C53F65B` (`descuentocliente_id`),
  CONSTRAINT `FK_281F7BF96C53F65B` FOREIGN KEY (`descuentocliente_id`) REFERENCES `DescuentoCliente` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_281F7BF9DE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Cliente` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente_descuentocliente`
--

LOCK TABLES `cliente_descuentocliente` WRITE;
/*!40000 ALTER TABLE `cliente_descuentocliente` DISABLE KEYS */;
/*!40000 ALTER TABLE `cliente_descuentocliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compra`
--

DROP TABLE IF EXISTS `compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `compra` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proveedor_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `fechaFactura` date DEFAULT NULL,
  `fechaEmision` datetime NOT NULL,
  `estado` tinyint(1) DEFAULT NULL,
  `total` decimal(10,3) DEFAULT NULL,
  `subTotal` decimal(10,3) DEFAULT NULL,
  `descuento` decimal(10,3) DEFAULT NULL,
  `otrosImp` decimal(10,3) DEFAULT NULL,
  `tipo` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `serie` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `numero` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `notaPedido_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9EC131FFCB305D73` (`proveedor_id`),
  KEY `IDX_9EC131FFFDD5DE1D` (`notaPedido_id`),
  KEY `IDX_9EC131FF521E1991` (`empresa_id`),
  CONSTRAINT `FK_9EC131FF521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_9EC131FFCB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedor` (`id`),
  CONSTRAINT `FK_9EC131FFFDD5DE1D` FOREIGN KEY (`notaPedido_id`) REFERENCES `nota_pedido` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compra`
--

LOCK TABLES `compra` WRITE;
/*!40000 ALTER TABLE `compra` DISABLE KEYS */;
/*!40000 ALTER TABLE `compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cuenta_empleado`
--

DROP TABLE IF EXISTS `cuenta_empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cuenta_empleado` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ultimoLote` date DEFAULT NULL,
  `pendiente` tinyint(1) DEFAULT NULL,
  `saldo` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cuenta_empleado`
--

LOCK TABLES `cuenta_empleado` WRITE;
/*!40000 ALTER TABLE `cuenta_empleado` DISABLE KEYS */;
INSERT INTO `cuenta_empleado` VALUES (1,'2013-10-21',0,1000.00),(2,NULL,1,0.00);
/*!40000 ALTER TABLE `cuenta_empleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cuit`
--

DROP TABLE IF EXISTS `cuit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cuit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipoglobal` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `numero` int(11) NOT NULL,
  `verificador` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cuit`
--

LOCK TABLES `cuit` WRITE;
/*!40000 ALTER TABLE `cuit` DISABLE KEYS */;
/*!40000 ALTER TABLE `cuit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `descuentoproductoventa_categoriaproductoventa`
--

DROP TABLE IF EXISTS `descuentoproductoventa_categoriaproductoventa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `descuentoproductoventa_categoriaproductoventa` (
  `descuentoproductoventa_id` int(11) NOT NULL,
  `categoriaproductoventa_id` int(11) NOT NULL,
  PRIMARY KEY (`descuentoproductoventa_id`,`categoriaproductoventa_id`),
  KEY `IDX_5F3A2E1AF0E0CFEB` (`descuentoproductoventa_id`),
  KEY `IDX_5F3A2E1AC46C9C95` (`categoriaproductoventa_id`),
  CONSTRAINT `FK_5F3A2E1AC46C9C95` FOREIGN KEY (`categoriaproductoventa_id`) REFERENCES `CategoriaProductoVenta` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_5F3A2E1AF0E0CFEB` FOREIGN KEY (`descuentoproductoventa_id`) REFERENCES `DescuentoProductoVenta` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `descuentoproductoventa_categoriaproductoventa`
--

LOCK TABLES `descuentoproductoventa_categoriaproductoventa` WRITE;
/*!40000 ALTER TABLE `descuentoproductoventa_categoriaproductoventa` DISABLE KEYS */;
/*!40000 ALTER TABLE `descuentoproductoventa_categoriaproductoventa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `descuentoproductoventa_productoventa`
--

DROP TABLE IF EXISTS `descuentoproductoventa_productoventa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `descuentoproductoventa_productoventa` (
  `descuentoproductoventa_id` int(11) NOT NULL,
  `productoventa_id` int(11) NOT NULL,
  PRIMARY KEY (`descuentoproductoventa_id`,`productoventa_id`),
  KEY `IDX_A4FD0665F0E0CFEB` (`descuentoproductoventa_id`),
  KEY `IDX_A4FD066517242A18` (`productoventa_id`),
  CONSTRAINT `FK_A4FD066517242A18` FOREIGN KEY (`productoventa_id`) REFERENCES `ProductoVenta` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_A4FD0665F0E0CFEB` FOREIGN KEY (`descuentoproductoventa_id`) REFERENCES `DescuentoProductoVenta` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `descuentoproductoventa_productoventa`
--

LOCK TABLES `descuentoproductoventa_productoventa` WRITE;
/*!40000 ALTER TABLE `descuentoproductoventa_productoventa` DISABLE KEYS */;
INSERT INTO `descuentoproductoventa_productoventa` VALUES (2,1);
/*!40000 ALTER TABLE `descuentoproductoventa_productoventa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ext_log_entries`
--

DROP TABLE IF EXISTS `ext_log_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ext_log_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `logged_at` datetime NOT NULL,
  `object_id` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `object_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `version` int(11) NOT NULL,
  `data` longtext COLLATE utf8_unicode_ci COMMENT '(DC2Type:array)',
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `log_class_lookup_idx` (`object_class`),
  KEY `log_date_lookup_idx` (`logged_at`),
  KEY `log_user_lookup_idx` (`username`),
  KEY `log_version_lookup_idx` (`object_id`,`object_class`,`version`)
) ENGINE=InnoDB AUTO_INCREMENT=1484 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ext_log_entries`
--

LOCK TABLES `ext_log_entries` WRITE;
/*!40000 ALTER TABLE `ext_log_entries` DISABLE KEYS */;
INSERT INTO `ext_log_entries` VALUES (1,'create','2013-10-19 10:59:34','1','SisGG\\FinalBundle\\Entity\\CondicionIva',1,'N;',NULL),(2,'create','2013-10-19 10:59:34','2','SisGG\\FinalBundle\\Entity\\CondicionIva',1,'N;',NULL),(3,'create','2013-10-19 10:59:34','3','SisGG\\FinalBundle\\Entity\\CondicionIva',1,'N;',NULL),(4,'create','2013-10-19 10:59:34','4','SisGG\\FinalBundle\\Entity\\CondicionIva',1,'N;',NULL),(5,'create','2013-10-19 10:59:34','1','SisGG\\FinalBundle\\Entity\\IVA',1,'N;',NULL),(6,'create','2013-10-19 10:59:34','1','SisGG\\FinalBundle\\Entity\\Rol',1,'N;',NULL),(7,'create','2013-10-19 10:59:34','1','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(8,'create','2013-10-19 10:59:34','2','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(9,'create','2013-10-19 10:59:34','3','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(10,'create','2013-10-19 10:59:34','4','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(11,'create','2013-10-19 10:59:34','5','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(12,'create','2013-10-19 10:59:34','6','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(13,'create','2013-10-19 10:59:34','7','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(14,'create','2013-10-19 10:59:34','8','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(15,'create','2013-10-19 10:59:34','9','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(16,'create','2013-10-19 10:59:34','10','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(17,'create','2013-10-19 10:59:34','11','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(18,'create','2013-10-19 10:59:34','12','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(19,'create','2013-10-19 10:59:34','13','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(20,'create','2013-10-19 10:59:34','14','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(21,'create','2013-10-19 10:59:34','15','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(22,'create','2013-10-19 10:59:34','16','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(23,'create','2013-10-19 10:59:34','17','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(24,'create','2013-10-19 10:59:34','18','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(25,'create','2013-10-19 10:59:34','19','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(26,'create','2013-10-19 10:59:34','20','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(27,'create','2013-10-19 10:59:34','21','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(28,'create','2013-10-19 10:59:34','22','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(29,'create','2013-10-19 10:59:34','23','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(30,'create','2013-10-19 10:59:34','24','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(31,'create','2013-10-19 10:59:34','25','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(32,'create','2013-10-19 10:59:34','26','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(33,'create','2013-10-19 10:59:34','27','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(34,'create','2013-10-19 10:59:34','28','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(35,'create','2013-10-19 10:59:34','29','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(36,'create','2013-10-19 10:59:34','30','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(37,'create','2013-10-19 10:59:34','31','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(38,'create','2013-10-19 10:59:34','32','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(39,'create','2013-10-19 10:59:34','33','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(40,'create','2013-10-19 10:59:34','34','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(41,'create','2013-10-19 10:59:34','35','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(42,'create','2013-10-19 10:59:34','36','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(43,'create','2013-10-19 10:59:34','37','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(44,'create','2013-10-19 10:59:34','38','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(45,'create','2013-10-19 10:59:34','39','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(46,'create','2013-10-19 10:59:34','40','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(47,'create','2013-10-19 10:59:34','41','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(48,'create','2013-10-19 10:59:34','42','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(49,'create','2013-10-19 10:59:34','43','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(50,'create','2013-10-19 10:59:34','44','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(51,'create','2013-10-19 10:59:34','45','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(52,'create','2013-10-19 10:59:34','46','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;',NULL),(53,'create','2013-10-19 10:59:34','1','SisGG\\FinalBundle\\Entity\\Concepto',1,'a:2:{s:6:\"nombre\";s:15:\"Pago por compra\";s:11:\"descripcion\";s:34:\"Pago de una compra a un proveedor.\";}',NULL),(54,'create','2013-10-19 10:59:34','2','SisGG\\FinalBundle\\Entity\\Concepto',1,'a:2:{s:6:\"nombre\";s:15:\"Cobro por venta\";s:11:\"descripcion\";s:32:\"Cobro de una venta a un cliente.\";}',NULL),(55,'create','2013-10-19 10:59:34','3','SisGG\\FinalBundle\\Entity\\Concepto',1,'a:2:{s:6:\"nombre\";s:18:\"Pago a un empleado\";s:11:\"descripcion\";s:32:\"Pago a un empleado por servicio.\";}',NULL),(56,'create','2013-10-19 10:59:34','1','SisGG\\FinalBundle\\Entity\\TipoCobro',1,'N;',NULL),(57,'create','2013-10-19 10:59:34','2','SisGG\\FinalBundle\\Entity\\TipoCobro',1,'N;',NULL),(58,'create','2013-10-19 10:59:34','3','SisGG\\FinalBundle\\Entity\\TipoCobro',1,'N;',NULL),(59,'create','2013-10-19 10:59:34','1','SisGG\\FinalBundle\\Entity\\Campo',1,'N;',NULL),(60,'create','2013-10-19 10:59:34','1','SisGG\\FinalBundle\\Entity\\TipoPedido',1,'N;',NULL),(61,'create','2013-10-19 10:59:34','2','SisGG\\FinalBundle\\Entity\\TipoPedido',1,'N;',NULL),(62,'create','2013-10-19 10:59:34','3','SisGG\\FinalBundle\\Entity\\TipoPedido',1,'N;',NULL),(63,'create','2013-10-19 10:59:34','1','SisGG\\FinalBundle\\Entity\\TipoFactura',1,'N;',NULL),(64,'create','2013-10-19 10:59:34','2','SisGG\\FinalBundle\\Entity\\TipoFactura',1,'N;',NULL),(65,'create','2013-10-19 10:59:34','3','SisGG\\FinalBundle\\Entity\\TipoFactura',1,'N;',NULL),(66,'create','2013-10-19 10:59:34','1','SisGG\\FinalBundle\\Entity\\TipoOperacion',1,'N;',NULL),(67,'create','2013-10-19 10:59:34','2','SisGG\\FinalBundle\\Entity\\TipoOperacion',1,'N;',NULL),(68,'create','2013-10-19 10:59:34','1','SisGG\\FinalBundle\\Entity\\Caja',1,'N;',NULL),(69,'create','2013-10-19 10:59:34','4','SisGG\\FinalBundle\\Entity\\Concepto',1,'a:2:{s:6:\"nombre\";s:15:\"Cobro por Venta\";s:11:\"descripcion\";s:15:\"Cobro por Venta\";}',NULL),(70,'create','2013-10-19 10:59:34','1','SisGG\\FinalBundle\\Entity\\TipoDocumento',1,'N;',NULL),(71,'create','2013-10-19 17:14:31','1','SisGG\\FinalBundle\\Entity\\Cliente',1,'a:6:{s:5:\"email\";N;s:6:\"estado\";s:6:\"activo\";s:9:\"documento\";N;s:8:\"apellido\";s:7:\"Herrera\";s:8:\"telefono\";a:1:{s:2:\"id\";i:1;}s:13:\"tipoDocumento\";N;}','admin'),(72,'create','2013-10-19 17:14:31','1','SisGG\\FinalBundle\\Entity\\Telefono',1,'N;','admin'),(73,'create','2013-10-19 17:16:02','1','SisGG\\FinalBundle\\Entity\\Tasa',1,'N;','admin'),(74,'create','2013-10-19 17:16:19','2','SisGG\\FinalBundle\\Entity\\Tasa',1,'N;','admin'),(75,'create','2013-10-19 17:16:44','1','SisGG\\FinalBundle\\Entity\\Plato',1,'N;','admin'),(76,'create','2013-10-19 17:17:52','1','SisGG\\FinalBundle\\Entity\\DescuentoCliente',1,'N;','admin'),(77,'create','2013-10-19 17:18:43','2','SisGG\\FinalBundle\\Entity\\DescuentoProductoVenta',1,'N;','admin'),(78,'create','2013-10-19 17:19:27','1','SisGG\\FinalBundle\\Entity\\GrupoCliente',1,'N;','admin'),(79,'create','2013-10-19 17:20:33','1','SisGG\\FinalBundle\\Entity\\Recargo',1,'N;','admin'),(80,'create','2013-10-19 18:35:03','1','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-19 18:35:03\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(81,'create','2013-10-19 18:35:03','1','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(82,'create','2013-10-19 18:35:03','1','SisGG\\FinalBundle\\Entity\\ItemDescuentoPedido',1,'N;','admin'),(83,'create','2013-10-19 18:35:03','1','SisGG\\FinalBundle\\Entity\\ItemRecargoPedido',1,'N;','admin'),(84,'create','2013-10-19 18:35:19','1','SisGG\\FinalBundle\\Entity\\Tanda',1,'N;','admin'),(85,'create','2013-10-19 18:35:33','1','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(86,'create','2013-10-19 18:35:43','1','SisGG\\FinalBundle\\Entity\\Lote',1,'N;','admin'),(87,'create','2013-10-19 18:35:43','1','SisGG\\FinalBundle\\Entity\\Apertura',1,'N;','admin'),(88,'create','2013-10-19 18:59:32','1','SisGG\\FinalBundle\\Entity\\Operacion',1,'N;','admin'),(89,'create','2013-10-19 19:08:23','1','SisGG\\FinalBundle\\Entity\\Sector',1,'N;','admin'),(90,'create','2013-10-19 19:08:23','1','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(91,'create','2013-10-19 19:08:23','2','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(92,'create','2013-10-19 19:08:23','3','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(93,'create','2013-10-19 19:08:23','4','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(94,'create','2013-10-19 19:08:23','5','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(95,'create','2013-10-19 19:08:23','6','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(96,'create','2013-10-19 19:08:23','7','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(97,'create','2013-10-19 19:08:23','8','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(98,'create','2013-10-19 19:08:23','9','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(99,'create','2013-10-19 19:08:23','10','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(100,'create','2013-10-19 19:16:14','2','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-19 19:16:14\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(101,'create','2013-10-19 19:16:14','2','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(102,'create','2013-10-19 19:16:14','3','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(103,'create','2013-10-19 19:16:14','2','SisGG\\FinalBundle\\Entity\\ItemRecargoPedido',1,'N;','admin'),(104,'create','2013-10-19 19:17:04','3','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-19 19:17:04\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(105,'create','2013-10-19 19:17:04','4','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(106,'create','2013-10-19 19:17:04','2','SisGG\\FinalBundle\\Entity\\ItemDescuentoPedido',1,'N;','admin'),(107,'create','2013-10-19 19:17:04','3','SisGG\\FinalBundle\\Entity\\ItemRecargoPedido',1,'N;','admin'),(108,'create','2013-10-20 11:22:41','5','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(109,'create','2013-10-20 11:23:02','2','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(110,'create','2013-10-20 11:23:40','6','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(111,'create','2013-10-20 11:23:40','7','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(112,'create','2013-10-20 11:24:13','4','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-20 11:24:13\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(113,'create','2013-10-20 11:24:13','8','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(114,'create','2013-10-20 11:24:13','9','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(115,'create','2013-10-20 11:24:13','10','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(116,'create','2013-10-20 11:24:13','3','SisGG\\FinalBundle\\Entity\\ItemDescuentoPedido',1,'N;','admin'),(117,'create','2013-10-20 11:24:13','4','SisGG\\FinalBundle\\Entity\\ItemRecargoPedido',1,'N;','admin'),(118,'create','2013-10-20 11:24:25','3','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(119,'create','2013-10-20 18:48:01','2','SisGG\\FinalBundle\\Entity\\Cliente',1,'a:6:{s:5:\"email\";N;s:6:\"estado\";s:6:\"activo\";s:9:\"documento\";N;s:8:\"apellido\";s:7:\"Herrera\";s:8:\"telefono\";a:1:{s:2:\"id\";i:2;}s:13:\"tipoDocumento\";N;}','admin'),(120,'create','2013-10-20 18:48:01','2','SisGG\\FinalBundle\\Entity\\Telefono',1,'N;','admin'),(121,'create','2013-10-20 18:48:30','5','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-20 18:48:30\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(122,'create','2013-10-20 18:48:30','11','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(123,'create','2013-10-20 18:48:30','12','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(124,'create','2013-10-20 18:48:30','13','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(125,'create','2013-10-20 18:48:44','4','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(126,'create','2013-10-20 18:53:24','6','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-20 18:53:24\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(127,'create','2013-10-20 18:53:24','14','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(128,'create','2013-10-20 18:53:24','15','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(129,'create','2013-10-20 18:53:24','16','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(130,'create','2013-10-20 18:55:50','5','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(131,'create','2013-10-20 19:24:45','7','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-20 19:24:45\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(132,'create','2013-10-20 19:24:45','17','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(133,'create','2013-10-20 19:24:45','4','SisGG\\FinalBundle\\Entity\\ItemDescuentoPedido',1,'N;','admin'),(134,'create','2013-10-20 19:24:57','6','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(135,'create','2013-10-20 19:39:54','2','SisGG\\FinalBundle\\Entity\\IVA',1,'N;','admin'),(136,'create','2013-10-20 19:41:02','2','SisGG\\FinalBundle\\Entity\\Plato',1,'N;','admin'),(137,'create','2013-10-20 19:41:40','8','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-20 19:41:40\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(138,'create','2013-10-20 19:41:40','18','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(139,'create','2013-10-20 19:41:40','19','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(140,'create','2013-10-20 19:41:54','7','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(141,'create','2013-10-20 19:43:39','9','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-20 19:43:39\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(142,'create','2013-10-20 19:43:39','20','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(143,'create','2013-10-20 19:43:39','21','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(144,'create','2013-10-20 19:43:39','5','SisGG\\FinalBundle\\Entity\\ItemDescuentoPedido',1,'N;','admin'),(145,'create','2013-10-20 19:43:52','8','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(146,'create','2013-10-20 19:55:54','10','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-20 19:55:54\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(147,'create','2013-10-20 19:55:54','22','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(148,'create','2013-10-20 19:55:54','23','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(149,'create','2013-10-20 19:55:54','6','SisGG\\FinalBundle\\Entity\\ItemDescuentoPedido',1,'N;','admin'),(150,'create','2013-10-20 19:56:55','9','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(151,'create','2013-10-20 20:19:47','2','SisGG\\FinalBundle\\Entity\\Operacion',1,'N;','admin'),(152,'create','2013-10-20 20:22:31','3','SisGG\\FinalBundle\\Entity\\Operacion',1,'N;','admin'),(153,'create','2013-10-21 00:40:08','1','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(154,'create','2013-10-21 00:40:08','1','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(155,'create','2013-10-21 00:40:08','2','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(156,'create','2013-10-21 00:40:08','1','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(157,'create','2013-10-21 00:40:08','1','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(163,'create','2013-10-21 00:46:26','3','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(164,'create','2013-10-21 00:46:26','3','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(165,'create','2013-10-21 00:46:26','4','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(166,'create','2013-10-21 00:46:26','2','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(167,'create','2013-10-21 00:46:26','2','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(173,'create','2013-10-21 00:48:04','5','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(174,'create','2013-10-21 00:48:04','5','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(175,'create','2013-10-21 00:48:04','3','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(176,'create','2013-10-21 00:48:04','3','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(177,'create','2013-10-21 00:48:04','2','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(178,'create','2013-10-21 00:49:08','6','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(179,'create','2013-10-21 00:49:08','6','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(180,'create','2013-10-21 00:49:08','1','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(181,'create','2013-10-21 00:49:08','4','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(182,'create','2013-10-21 00:51:23','7','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(183,'create','2013-10-21 00:51:23','7','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(184,'create','2013-10-21 00:51:23','8','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(185,'create','2013-10-21 00:51:23','4','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(186,'create','2013-10-21 00:51:24','3','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(187,'create','2013-10-21 00:51:24','4','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(188,'create','2013-10-21 01:09:55','11','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-21 01:09:55\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(189,'create','2013-10-21 01:09:55','24','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(190,'create','2013-10-21 01:09:55','25','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(191,'create','2013-10-21 01:09:55','7','SisGG\\FinalBundle\\Entity\\ItemDescuentoPedido',1,'N;','admin'),(192,'create','2013-10-21 01:09:55','5','SisGG\\FinalBundle\\Entity\\ItemRecargoPedido',1,'N;','admin'),(193,'create','2013-10-21 01:10:19','10','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(199,'create','2013-10-21 07:12:56','9','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(200,'create','2013-10-21 07:12:56','9','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(201,'create','2013-10-21 07:12:56','5','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(202,'create','2013-10-21 07:12:56','5','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(203,'create','2013-10-21 07:12:56','6','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(204,'create','2013-10-21 07:14:18','10','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(205,'create','2013-10-21 07:14:18','10','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(206,'create','2013-10-21 07:14:18','6','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(207,'create','2013-10-21 07:14:18','1','SisGG\\FinalBundle\\Entity\\Valor',1,'N;','admin'),(208,'create','2013-10-21 07:14:18','7','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(209,'create','2013-10-21 07:14:18','8','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(210,'create','2013-10-21 07:26:25','12','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-21 07:26:25\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(211,'create','2013-10-21 07:26:25','26','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(212,'create','2013-10-21 07:26:25','27','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(213,'create','2013-10-21 07:26:25','8','SisGG\\FinalBundle\\Entity\\ItemDescuentoPedido',1,'N;','admin'),(214,'create','2013-10-21 07:26:38','11','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(215,'create','2013-10-21 07:27:46','11','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(216,'create','2013-10-21 07:27:46','11','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(217,'create','2013-10-21 07:27:46','12','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(218,'create','2013-10-21 07:27:46','7','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(219,'create','2013-10-21 07:27:46','5','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(220,'create','2013-10-21 07:27:46','9','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(221,'create','2013-10-21 07:27:46','10','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(222,'create','2013-10-21 07:31:10','13','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-21 07:31:10\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(223,'create','2013-10-21 07:31:10','28','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(224,'create','2013-10-21 07:31:10','29','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(225,'create','2013-10-21 07:31:10','9','SisGG\\FinalBundle\\Entity\\ItemDescuentoPedido',1,'N;','admin'),(226,'create','2013-10-21 07:31:54','12','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(227,'create','2013-10-21 07:33:09','12','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(228,'create','2013-10-21 07:33:09','13','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(229,'create','2013-10-21 07:33:09','14','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(230,'create','2013-10-21 07:33:09','8','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(231,'create','2013-10-21 07:33:09','11','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(232,'create','2013-10-21 07:33:09','12','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(233,'create','2013-10-21 07:45:24','14','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-21 07:45:24\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(234,'create','2013-10-21 07:45:24','30','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(235,'create','2013-10-21 07:45:24','31','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(236,'create','2013-10-21 07:45:46','13','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(237,'create','2013-10-21 07:54:51','13','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(238,'create','2013-10-21 07:54:51','15','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(239,'create','2013-10-21 07:54:51','16','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(240,'create','2013-10-21 07:54:51','9','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(241,'create','2013-10-21 07:54:51','13','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(242,'create','2013-10-21 07:54:52','14','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(243,'create','2013-10-21 07:57:53','15','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-21 07:57:53\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(244,'create','2013-10-21 07:57:53','32','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(245,'create','2013-10-21 07:57:53','33','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(246,'create','2013-10-21 07:57:53','34','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(247,'create','2013-10-21 07:57:53','10','SisGG\\FinalBundle\\Entity\\ItemDescuentoPedido',1,'N;','admin'),(248,'create','2013-10-21 07:58:21','14','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(249,'create','2013-10-21 08:01:45','14','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(250,'create','2013-10-21 08:01:45','17','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(251,'create','2013-10-21 08:01:45','18','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(252,'create','2013-10-21 08:01:45','10','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(253,'create','2013-10-21 08:01:45','6','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(254,'create','2013-10-21 08:01:45','15','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(255,'create','2013-10-21 08:01:45','16','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(256,'create','2013-10-21 08:03:05','16','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-21 08:03:05\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(257,'create','2013-10-21 08:03:05','35','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(258,'create','2013-10-21 08:03:05','36','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(259,'create','2013-10-21 08:03:05','11','SisGG\\FinalBundle\\Entity\\ItemDescuentoPedido',1,'N;','admin'),(260,'create','2013-10-21 08:03:21','15','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(261,'create','2013-10-21 08:04:23','15','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(262,'create','2013-10-21 08:04:23','19','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(263,'create','2013-10-21 08:04:23','20','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(264,'create','2013-10-21 08:04:23','11','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(265,'create','2013-10-21 08:04:23','7','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(266,'create','2013-10-21 08:04:24','17','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(267,'create','2013-10-21 08:04:24','18','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(268,'create','2013-10-21 08:07:01','19','SisGG\\FinalBundle\\Entity\\Cierre',1,'N;','admin'),(269,'create','2013-10-21 08:07:01','1','SisGG\\FinalBundle\\Entity\\ItemCierre',1,'N;','admin'),(270,'create','2013-10-21 08:07:01','2','SisGG\\FinalBundle\\Entity\\ItemCierre',1,'N;','admin'),(271,'create','2013-10-21 08:09:40','2','SisGG\\FinalBundle\\Entity\\Lote',1,'N;','admin'),(272,'create','2013-10-21 08:09:40','20','SisGG\\FinalBundle\\Entity\\Apertura',1,'N;','admin'),(273,'create','2013-10-21 08:10:41','21','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(274,'create','2013-10-21 08:12:05','16','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(275,'create','2013-10-21 08:12:09','17','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(276,'create','2013-10-21 08:12:12','18','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(282,'create','2013-10-21 08:26:15','4','SisGG\\FinalBundle\\Entity\\Operacion',1,'N;','admin'),(283,'create','2013-10-21 08:32:12','17','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(284,'create','2013-10-21 08:32:12','21','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(285,'create','2013-10-21 08:32:12','12','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(286,'create','2013-10-21 08:32:12','2','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(287,'create','2013-10-21 08:32:12','22','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(288,'create','2013-10-21 08:32:12','23','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(289,'create','2013-10-21 09:27:04','17','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-21 09:27:04\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(290,'create','2013-10-21 09:27:04','37','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(291,'create','2013-10-21 09:27:04','38','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(292,'create','2013-10-21 09:27:21','19','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(293,'create','2013-10-21 09:27:43','18','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(294,'create','2013-10-21 09:27:43','22','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(295,'create','2013-10-21 09:27:43','23','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(296,'create','2013-10-21 09:27:43','13','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(297,'create','2013-10-21 09:27:43','24','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(298,'create','2013-10-21 09:27:43','25','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(299,'create','2013-10-21 09:29:19','26','SisGG\\FinalBundle\\Entity\\Cierre',1,'N;','admin'),(300,'create','2013-10-21 09:29:19','3','SisGG\\FinalBundle\\Entity\\ItemCierre',1,'N;','admin'),(301,'create','2013-10-21 09:29:19','4','SisGG\\FinalBundle\\Entity\\ItemCierre',1,'N;','admin'),(302,'create','2013-10-21 09:54:40','3','SisGG\\FinalBundle\\Entity\\Mercaderia',1,'N;','admin'),(303,'create','2013-10-21 09:55:47','18','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-21 09:55:47\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(304,'create','2013-10-21 09:55:47','39','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(305,'create','2013-10-21 09:55:47','40','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(306,'create','2013-10-21 09:55:47','41','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(307,'create','2013-10-21 09:55:47','12','SisGG\\FinalBundle\\Entity\\ItemDescuentoPedido',1,'N;','admin'),(308,'create','2013-10-21 09:57:00','19','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-21 09:57:00\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(309,'create','2013-10-21 09:57:00','42','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(310,'create','2013-10-21 09:57:40','20','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-21 09:57:40\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(311,'create','2013-10-21 09:57:40','43','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(312,'create','2013-10-21 10:01:18','21','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-21 10:01:18\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(313,'create','2013-10-21 10:01:18','44','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(314,'create','2013-10-21 10:01:18','45','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(315,'create','2013-10-21 10:01:18','13','SisGG\\FinalBundle\\Entity\\ItemDescuentoPedido',1,'N;','admin'),(316,'create','2013-10-21 14:28:06','3','SisGG\\FinalBundle\\Entity\\Lote',1,'N;','admin'),(317,'create','2013-10-21 14:28:06','27','SisGG\\FinalBundle\\Entity\\Apertura',1,'N;','admin'),(318,'create','2013-10-21 17:03:22','19','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(319,'create','2013-10-21 17:03:22','24','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(320,'create','2013-10-21 17:03:22','14','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(321,'create','2013-10-21 17:03:22','8','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(322,'create','2013-10-21 17:03:22','28','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(323,'create','2013-10-21 17:03:22','29','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(324,'create','2013-10-21 17:54:06','22','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-21 17:54:06\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(325,'create','2013-10-21 17:54:06','46','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(326,'create','2013-10-21 17:54:06','47','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(327,'create','2013-10-21 17:54:06','14','SisGG\\FinalBundle\\Entity\\ItemDescuentoPedido',1,'N;','admin'),(328,'create','2013-10-21 17:54:06','6','SisGG\\FinalBundle\\Entity\\ItemRecargoPedido',1,'N;','admin'),(329,'create','2013-10-21 17:54:27','20','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(330,'create','2013-10-21 17:54:27','25','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(331,'create','2013-10-21 17:54:27','15','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(332,'create','2013-10-21 17:54:27','3','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(333,'create','2013-10-21 17:54:27','9','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(334,'create','2013-10-21 17:54:27','30','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(335,'create','2013-10-21 17:54:27','31','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(336,'create','2013-10-21 18:19:45','5','SisGG\\FinalBundle\\Entity\\Operacion',1,'N;','admin'),(337,'create','2013-10-21 18:21:28','21','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(338,'create','2013-10-21 18:21:28','26','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(339,'create','2013-10-21 18:21:28','16','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(340,'create','2013-10-21 18:21:28','32','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(341,'create','2013-10-21 18:21:28','33','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(342,'create','2013-10-21 19:01:23','1','SisGG\\FinalBundle\\Entity\\RegistroEnvio',1,'N;','admin'),(343,'create','2013-10-21 19:26:03','23','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-21 19:26:03\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(344,'create','2013-10-21 19:26:03','48','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(345,'create','2013-10-21 19:26:03','49','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(346,'create','2013-10-21 19:27:32','20','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(347,'create','2013-10-21 19:30:34','22','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(348,'create','2013-10-21 19:30:34','27','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(349,'create','2013-10-21 19:30:34','28','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(350,'create','2013-10-21 19:30:34','17','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(351,'create','2013-10-21 19:30:34','34','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(352,'create','2013-10-21 19:30:34','35','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(353,'create','2013-10-21 19:33:07','23','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(354,'create','2013-10-21 19:33:07','29','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(355,'create','2013-10-21 19:33:07','18','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(356,'create','2013-10-21 19:33:07','2','SisGG\\FinalBundle\\Entity\\Valor',1,'N;','admin'),(357,'create','2013-10-21 19:33:07','36','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(358,'create','2013-10-21 19:33:07','37','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(359,'create','2013-10-21 19:35:15','38','SisGG\\FinalBundle\\Entity\\Cierre',1,'N;','admin'),(360,'create','2013-10-21 19:35:15','5','SisGG\\FinalBundle\\Entity\\ItemCierre',1,'N;','admin'),(361,'create','2013-10-21 19:35:15','6','SisGG\\FinalBundle\\Entity\\ItemCierre',1,'N;','admin'),(362,'create','2013-10-21 19:36:29','4','SisGG\\FinalBundle\\Entity\\Lote',1,'N;','admin'),(363,'create','2013-10-21 19:36:29','39','SisGG\\FinalBundle\\Entity\\Apertura',1,'N;','admin'),(364,'create','2013-10-21 19:37:51','3','SisGG\\FinalBundle\\Entity\\Cliente',1,'a:6:{s:5:\"email\";N;s:6:\"estado\";s:6:\"activo\";s:9:\"documento\";N;s:8:\"apellido\";s:6:\"Aquino\";s:8:\"telefono\";a:1:{s:2:\"id\";i:3;}s:13:\"tipoDocumento\";N;}','admin'),(365,'create','2013-10-21 19:37:51','3','SisGG\\FinalBundle\\Entity\\Telefono',1,'N;','admin'),(366,'create','2013-10-21 19:39:59','24','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-21 19:39:58\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(367,'create','2013-10-21 19:39:59','50','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(368,'create','2013-10-21 19:39:59','51','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(369,'create','2013-10-21 19:39:59','7','SisGG\\FinalBundle\\Entity\\ItemRecargoPedido',1,'N;','admin'),(370,'create','2013-10-21 19:40:18','21','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(371,'create','2013-10-21 19:42:10','2','SisGG\\FinalBundle\\Entity\\RegistroEnvio',1,'N;','admin'),(372,'create','2013-10-22 08:19:59','24','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(373,'create','2013-10-22 08:19:59','30','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(374,'create','2013-10-22 08:19:59','19','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(375,'create','2013-10-22 08:19:59','3','SisGG\\FinalBundle\\Entity\\Valor',1,'N;','admin'),(376,'create','2013-10-22 08:19:59','10','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(377,'create','2013-10-22 08:20:00','40','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(378,'create','2013-10-22 08:20:00','41','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(379,'create','2013-10-22 09:35:18','25','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-22 09:35:18\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(380,'create','2013-10-22 09:35:18','52','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(381,'create','2013-10-22 09:35:18','53','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(382,'create','2013-10-22 09:35:18','8','SisGG\\FinalBundle\\Entity\\ItemRecargoPedido',1,'N;','admin'),(383,'create','2013-10-22 10:30:26','22','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(384,'create','2013-10-22 10:30:46','25','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(385,'create','2013-10-22 10:30:46','31','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(386,'create','2013-10-22 10:30:46','32','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(387,'create','2013-10-22 10:30:46','4','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(388,'create','2013-10-22 10:34:30','26','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-22 10:34:30\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(389,'create','2013-10-22 10:34:30','54','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(390,'create','2013-10-22 10:34:30','55','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(391,'create','2013-10-22 10:34:30','9','SisGG\\FinalBundle\\Entity\\ItemRecargoPedido',1,'N;','admin'),(392,'create','2013-10-22 10:34:39','23','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(401,'create','2013-10-22 10:37:07','26','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(402,'create','2013-10-22 10:37:07','33','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(403,'create','2013-10-22 10:37:07','34','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(404,'create','2013-10-22 10:37:07','5','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(405,'create','2013-10-22 10:40:02','27','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-22 10:40:02\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(406,'create','2013-10-22 10:40:02','56','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(407,'create','2013-10-22 10:40:02','57','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(408,'create','2013-10-22 10:40:02','10','SisGG\\FinalBundle\\Entity\\ItemRecargoPedido',1,'N;','admin'),(409,'create','2013-10-22 10:40:14','24','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(410,'create','2013-10-22 10:40:41','27','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(411,'create','2013-10-22 10:40:41','35','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(412,'create','2013-10-22 10:40:41','36','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(413,'create','2013-10-22 10:40:41','6','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(414,'create','2013-10-22 10:41:15','28','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-22 10:41:15\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(415,'create','2013-10-22 10:41:15','58','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(416,'create','2013-10-22 10:41:15','59','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(417,'create','2013-10-22 10:41:15','11','SisGG\\FinalBundle\\Entity\\ItemRecargoPedido',1,'N;','admin'),(418,'create','2013-10-22 10:41:47','28','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(419,'create','2013-10-22 10:41:47','37','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(420,'create','2013-10-22 10:41:47','20','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(421,'create','2013-10-22 10:41:47','7','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(422,'create','2013-10-22 10:41:47','42','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(423,'create','2013-10-22 10:41:47','43','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(424,'update','2013-10-23 12:03:31','1','SisGG\\FinalBundle\\Entity\\Cliente',2,'a:1:{s:6:\"estado\";s:8:\"inactivo\";}','admin'),(425,'update','2013-10-23 12:23:50','1','SisGG\\FinalBundle\\Entity\\Cliente',3,'a:1:{s:6:\"estado\";s:6:\"activo\";}','admin'),(426,'create','2013-10-23 12:25:10','4','SisGG\\FinalBundle\\Entity\\Cliente',1,'a:6:{s:5:\"email\";N;s:6:\"estado\";s:6:\"activo\";s:9:\"documento\";N;s:8:\"apellido\";s:10:\"Consumidor\";s:8:\"telefono\";a:1:{s:2:\"id\";i:4;}s:13:\"tipoDocumento\";N;}','admin'),(427,'create','2013-10-23 12:25:10','4','SisGG\\FinalBundle\\Entity\\Telefono',1,'N;','admin'),(428,'create','2013-10-23 17:25:40','29','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-23 17:25:40\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(429,'create','2013-10-23 17:25:40','60','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(430,'create','2013-10-23 17:25:40','12','SisGG\\FinalBundle\\Entity\\ItemRecargoPedido',1,'N;','admin'),(431,'create','2013-10-23 18:07:01','30','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-23 18:07:01\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(432,'create','2013-10-23 18:07:01','61','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(433,'create','2013-10-23 18:07:01','62','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(434,'create','2013-10-24 16:31:21','15','SisGG\\FinalBundle\\Entity\\ItemDescuentoPedido',1,'N;','admin'),(435,'create','2013-10-24 17:57:06','31','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-24 17:57:06\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(436,'create','2013-10-24 17:57:06','63','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(437,'create','2013-10-24 17:57:06','64','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(438,'create','2013-10-25 07:32:07','32','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-25 07:32:07\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(439,'create','2013-10-25 07:32:07','65','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(440,'create','2013-10-25 07:32:07','66','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(441,'create','2013-10-25 08:00:46','33','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-25 08:00:46\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(442,'create','2013-10-25 08:00:46','67','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(443,'create','2013-10-25 08:00:46','68','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(444,'create','2013-10-25 08:11:49','34','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-25 08:11:49\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(445,'create','2013-10-25 08:11:49','69','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(446,'create','2013-10-25 08:17:14','25','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(447,'create','2013-10-25 08:39:08','70','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(448,'create','2013-10-25 21:23:49','35','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-25 21:23:49\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(449,'create','2013-10-25 21:23:49','71','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(450,'create','2013-10-25 21:23:49','72','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(451,'create','2013-10-25 21:24:20','26','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(452,'create','2013-10-25 23:14:24','73','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(453,'create','2013-10-25 23:14:24','74','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(454,'create','2013-10-25 23:16:33','75','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(455,'create','2013-10-25 23:16:51','27','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(456,'create','2013-10-25 23:17:11','28','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(457,'create','2013-10-25 23:17:49','76','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(458,'create','2013-10-25 23:17:59','29','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(482,'create','2013-10-26 01:56:19','30','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(483,'create','2013-10-26 01:56:19','41','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(484,'create','2013-10-26 01:56:19','42','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(485,'create','2013-10-26 01:56:19','43','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(486,'create','2013-10-26 01:56:19','22','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(487,'create','2013-10-26 01:56:19','8','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(488,'create','2013-10-26 01:56:19','11','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(489,'create','2013-10-26 01:56:19','1','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(498,'create','2013-10-26 09:27:54','36','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-26 09:27:54\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(499,'create','2013-10-26 09:27:54','77','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(500,'create','2013-10-26 09:27:54','78','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(501,'create','2013-10-26 09:28:04','30','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(502,'create','2013-10-26 09:28:38','44','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(503,'create','2013-10-26 09:29:11','45','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(504,'create','2013-10-26 09:30:39','46','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(505,'create','2013-10-26 09:31:51','47','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(506,'create','2013-10-26 09:32:31','48','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(507,'create','2013-10-26 09:32:31','34','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(508,'create','2013-10-26 09:32:31','48','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(509,'create','2013-10-26 09:32:31','49','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(510,'create','2013-10-26 09:32:31','25','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(511,'create','2013-10-26 09:32:31','13','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(512,'create','2013-10-26 09:32:31','14','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(513,'create','2013-10-26 09:32:31','14','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(514,'create','2013-10-26 09:32:31','15','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(515,'create','2013-10-26 09:32:31','2','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(516,'create','2013-10-26 09:50:50','37','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-26 09:50:50\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(517,'create','2013-10-26 09:50:50','79','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(518,'create','2013-10-26 09:50:50','80','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(519,'create','2013-10-26 09:51:04','31','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(520,'create','2013-10-26 10:34:30','38','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-26 10:34:30\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(521,'create','2013-10-26 10:34:30','81','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(522,'create','2013-10-26 10:43:56','49','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(523,'create','2013-10-26 10:43:56','35','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(524,'create','2013-10-26 10:43:56','50','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(525,'create','2013-10-26 10:43:56','26','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(526,'create','2013-10-26 10:43:56','15','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(527,'create','2013-10-26 10:43:56','16','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(528,'create','2013-10-26 10:43:56','16','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(529,'create','2013-10-26 10:43:56','17','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(530,'create','2013-10-26 10:43:56','3','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(531,'create','2013-10-26 11:01:29','39','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-26 11:01:29\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(532,'create','2013-10-26 11:01:29','82','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(533,'create','2013-10-26 11:01:29','83','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(534,'create','2013-10-26 11:01:53','32','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(535,'create','2013-10-26 11:03:29','50','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(536,'create','2013-10-26 11:03:29','36','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(537,'create','2013-10-26 11:03:29','51','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(538,'create','2013-10-26 11:03:29','52','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(539,'create','2013-10-26 11:03:29','27','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(540,'create','2013-10-26 11:03:29','17','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(541,'create','2013-10-26 11:03:29','18','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(542,'create','2013-10-26 11:03:29','18','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(543,'create','2013-10-26 11:03:29','19','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(544,'create','2013-10-26 11:03:29','4','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(545,'create','2013-10-26 11:06:58','40','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-26 11:06:58\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(546,'create','2013-10-26 11:06:58','84','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(547,'create','2013-10-26 11:06:58','85','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(548,'create','2013-10-26 11:07:12','33','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(549,'create','2013-10-26 11:15:36','51','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(550,'create','2013-10-26 11:15:36','37','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(551,'create','2013-10-26 11:15:36','53','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(552,'create','2013-10-26 11:15:36','54','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(553,'create','2013-10-26 11:15:36','28','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(554,'create','2013-10-26 11:15:36','19','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(555,'create','2013-10-26 11:15:36','20','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(556,'create','2013-10-26 11:15:36','20','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(557,'create','2013-10-26 11:15:36','21','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(558,'create','2013-10-26 11:15:36','5','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(559,'create','2013-10-26 11:20:28','41','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-26 11:20:28\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(560,'create','2013-10-26 11:20:28','86','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(561,'create','2013-10-26 11:20:28','87','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(562,'create','2013-10-26 11:20:43','34','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(563,'create','2013-10-26 11:24:07','52','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(564,'create','2013-10-26 11:25:29','53','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(565,'create','2013-10-26 11:25:52','54','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(566,'create','2013-10-26 11:25:52','38','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(567,'create','2013-10-26 11:25:52','55','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(568,'create','2013-10-26 11:25:52','56','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(569,'create','2013-10-26 11:25:52','29','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(570,'create','2013-10-26 11:25:52','21','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(571,'create','2013-10-26 11:25:52','22','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(572,'create','2013-10-26 11:25:52','22','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(573,'create','2013-10-26 11:25:52','23','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(574,'create','2013-10-26 11:25:52','6','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(575,'create','2013-10-26 18:48:58','42','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-26 18:48:58\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(576,'create','2013-10-26 18:48:58','88','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(577,'create','2013-10-26 18:48:58','89','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(578,'create','2013-10-26 18:48:58','90','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(579,'create','2013-10-26 18:49:10','35','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(580,'create','2013-10-26 18:51:42','55','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(581,'create','2013-10-26 18:51:42','56','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(582,'create','2013-10-26 18:51:42','39','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(583,'create','2013-10-26 18:51:42','57','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(584,'create','2013-10-26 18:51:42','58','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(585,'create','2013-10-26 18:51:42','59','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(586,'create','2013-10-26 18:51:42','30','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(587,'create','2013-10-26 18:51:42','23','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(588,'create','2013-10-26 18:51:42','24','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(589,'create','2013-10-26 18:51:42','24','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(590,'create','2013-10-26 18:51:42','25','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(591,'create','2013-10-26 18:51:42','7','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(592,'create','2013-10-26 18:53:56','43','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-26 18:53:56\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(593,'create','2013-10-26 18:53:56','91','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(594,'create','2013-10-26 18:53:56','92','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(595,'create','2013-10-26 18:53:56','93','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(596,'create','2013-10-26 18:54:32','36','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(597,'create','2013-10-26 18:55:12','57','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(598,'create','2013-10-26 18:55:12','58','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(599,'create','2013-10-26 18:55:13','40','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(600,'create','2013-10-26 18:55:13','60','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(601,'create','2013-10-26 18:55:13','61','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(602,'create','2013-10-26 18:55:13','62','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(603,'create','2013-10-26 18:55:13','31','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(604,'create','2013-10-26 18:55:13','25','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(605,'create','2013-10-26 18:55:13','26','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(606,'create','2013-10-26 18:55:13','8','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(607,'create','2013-10-26 19:01:25','44','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-26 19:01:25\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(608,'create','2013-10-26 19:01:25','94','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(609,'create','2013-10-26 19:01:25','95','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(610,'create','2013-10-26 19:01:25','96','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(611,'create','2013-10-26 19:03:11','37','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(612,'create','2013-10-26 19:03:55','59','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(613,'create','2013-10-26 19:03:55','60','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(614,'create','2013-10-26 19:03:55','41','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(615,'create','2013-10-26 19:03:55','63','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(616,'create','2013-10-26 19:03:55','64','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(617,'create','2013-10-26 19:03:55','65','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(618,'create','2013-10-26 19:03:55','32','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(619,'create','2013-10-26 19:03:55','27','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(620,'create','2013-10-26 19:03:55','28','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(621,'create','2013-10-26 19:03:55','9','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(622,'create','2013-10-26 19:10:26','45','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-26 19:10:26\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(623,'create','2013-10-26 19:10:26','97','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(624,'create','2013-10-26 19:10:26','98','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(625,'create','2013-10-26 19:10:34','38','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(626,'create','2013-10-26 19:10:56','61','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(627,'create','2013-10-26 19:10:56','62','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(628,'create','2013-10-26 19:10:56','42','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(629,'create','2013-10-26 19:10:56','66','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(630,'create','2013-10-26 19:10:56','67','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(631,'create','2013-10-26 19:10:56','33','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(632,'create','2013-10-26 19:10:56','29','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(633,'create','2013-10-26 19:10:56','10','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(634,'create','2013-10-26 19:31:07','46','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-26 19:31:07\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(635,'create','2013-10-26 19:31:07','99','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(636,'create','2013-10-26 19:31:07','100','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(637,'create','2013-10-26 19:31:21','39','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(638,'create','2013-10-26 19:31:57','63','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(639,'create','2013-10-26 19:31:57','64','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(640,'create','2013-10-26 19:31:57','43','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(641,'create','2013-10-26 19:31:57','68','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(642,'create','2013-10-26 19:31:57','69','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(643,'create','2013-10-26 19:31:57','34','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(644,'create','2013-10-26 19:31:57','30','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(645,'create','2013-10-26 19:31:57','11','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(646,'create','2013-10-26 19:36:59','47','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-26 19:36:59\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(647,'create','2013-10-26 19:36:59','101','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(648,'create','2013-10-26 19:36:59','102','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(649,'create','2013-10-26 19:37:19','40','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(650,'create','2013-10-26 19:38:28','65','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(651,'create','2013-10-26 19:38:28','66','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(652,'create','2013-10-26 19:38:28','44','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(653,'create','2013-10-26 19:38:28','70','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(654,'create','2013-10-26 19:38:28','71','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(655,'create','2013-10-26 19:38:28','35','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(656,'create','2013-10-26 19:38:28','31','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(657,'create','2013-10-26 19:38:28','12','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(658,'create','2013-10-26 20:20:11','48','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-26 20:20:11\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(659,'create','2013-10-26 20:20:11','103','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(660,'create','2013-10-26 20:20:11','104','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(661,'create','2013-10-26 20:20:11','105','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(662,'create','2013-10-26 20:20:20','41','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(663,'create','2013-10-26 20:20:38','45','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(664,'create','2013-10-26 20:20:38','72','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(665,'create','2013-10-26 20:20:38','73','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(666,'create','2013-10-26 20:20:38','74','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(667,'create','2013-10-26 20:20:38','32','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(668,'create','2013-10-26 20:20:38','13','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(669,'create','2013-10-26 20:22:18','49','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-26 20:22:18\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(670,'create','2013-10-26 20:22:18','106','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(671,'create','2013-10-26 20:22:18','107','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(672,'create','2013-10-26 20:22:18','108','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(673,'create','2013-10-26 20:22:26','42','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(674,'create','2013-10-26 20:22:51','67','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(675,'create','2013-10-26 20:23:28','68','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(676,'create','2013-10-26 20:23:28','47','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(677,'create','2013-10-26 20:23:28','75','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(678,'create','2013-10-26 20:23:28','76','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(679,'create','2013-10-26 20:23:28','77','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(680,'create','2013-10-26 20:23:28','36','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(681,'create','2013-10-26 20:23:28','4','SisGG\\FinalBundle\\Entity\\Valor',1,'N;','admin'),(682,'create','2013-10-26 20:23:28','33','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(683,'create','2013-10-26 20:23:28','14','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(684,'create','2013-10-26 20:32:49','3','SisGG\\FinalBundle\\Entity\\RegistroEnvio',1,'N;','admin'),(685,'create','2013-10-26 20:52:10','6','SisGG\\FinalBundle\\Entity\\Operacion',1,'N;','admin'),(686,'create','2013-10-26 21:04:59','7','SisGG\\FinalBundle\\Entity\\Operacion',1,'N;','admin'),(687,'create','2013-10-27 10:42:29','50','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-27 10:42:29\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(688,'create','2013-10-27 10:42:29','109','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(689,'create','2013-10-27 10:42:29','110','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(690,'create','2013-10-27 10:42:29','111','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(691,'create','2013-10-27 10:42:50','43','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(692,'create','2013-10-27 10:43:50','69','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(693,'create','2013-10-27 10:43:50','48','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(694,'create','2013-10-27 10:43:50','78','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(695,'create','2013-10-27 10:43:50','79','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(696,'create','2013-10-27 10:43:50','80','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(697,'create','2013-10-27 10:43:50','37','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(698,'create','2013-10-27 10:43:50','34','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(699,'create','2013-10-27 10:43:50','15','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(706,'create','2013-10-27 14:04:27','70','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(707,'create','2013-10-27 16:02:39','71','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(708,'create','2013-10-27 16:02:39','51','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(709,'create','2013-10-27 16:02:39','81','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(710,'create','2013-10-27 16:02:39','38','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(711,'create','2013-10-27 16:02:39','35','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(712,'create','2013-10-27 16:02:39','16','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(713,'create','2013-10-27 17:12:40','72','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(714,'create','2013-10-27 17:12:40','73','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(715,'create','2013-10-27 17:13:15','51','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-27 17:13:15\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(716,'create','2013-10-27 17:13:15','112','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(717,'create','2013-10-27 17:13:15','113','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(718,'create','2013-10-27 17:13:41','74','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(719,'create','2013-10-27 17:13:41','53','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(720,'create','2013-10-27 17:13:41','82','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(721,'create','2013-10-27 17:13:41','39','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(722,'create','2013-10-27 17:13:41','36','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(723,'create','2013-10-27 17:13:41','17','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(724,'create','2013-10-27 17:16:23','52','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-27 17:16:23\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(725,'create','2013-10-27 17:16:23','114','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(726,'create','2013-10-27 17:16:23','115','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(727,'create','2013-10-27 17:16:58','75','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(728,'create','2013-10-27 17:16:58','54','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(729,'create','2013-10-27 17:16:58','83','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(730,'create','2013-10-27 17:16:58','40','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(731,'create','2013-10-27 17:16:58','37','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(732,'create','2013-10-27 17:16:58','18','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(733,'create','2013-10-27 17:50:27','76','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(734,'create','2013-10-27 17:50:59','53','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-27 17:50:59\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(735,'create','2013-10-27 17:50:59','116','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(736,'create','2013-10-27 17:52:48','77','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(737,'create','2013-10-27 17:52:48','56','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(738,'create','2013-10-27 17:52:48','84','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(739,'create','2013-10-27 17:52:48','41','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(740,'create','2013-10-27 17:52:48','38','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(741,'create','2013-10-27 17:52:48','19','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(742,'create','2013-10-27 17:53:20','1','SisGG\\FinalBundle\\Entity\\NotaCredito',1,'N;','admin'),(743,'create','2013-10-27 18:55:31','4','SisGG\\FinalBundle\\Entity\\RegistroEnvio',1,'N;','admin'),(744,'create','2013-10-27 19:42:51','78','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(745,'create','2013-10-27 22:26:48','3','SisGG\\FinalBundle\\Entity\\Tasa',1,'N;','admin'),(746,'create','2013-10-27 22:27:21','4','SisGG\\FinalBundle\\Entity\\MateriaPrima',1,'N;','admin'),(747,'create','2013-10-27 22:27:51','1','SisGG\\FinalBundle\\Entity\\Ingrediente',1,'N;','admin'),(748,'create','2013-10-27 22:28:57','5','SisGG\\FinalBundle\\Entity\\MateriaPrima',1,'N;','admin'),(749,'create','2013-10-27 22:29:57','2','SisGG\\FinalBundle\\Entity\\Ingrediente',1,'N;','admin'),(750,'create','2013-10-27 22:30:40','54','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-27 22:30:40\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(751,'create','2013-10-27 22:30:40','117','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(752,'create','2013-10-27 22:30:57','44','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(753,'create','2013-10-27 22:31:19','45','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(754,'create','2013-10-27 22:31:23','46','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(755,'create','2013-10-27 22:31:26','47','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(756,'create','2013-10-27 22:31:30','48','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(757,'create','2013-10-27 22:32:01','118','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(758,'create','2013-10-27 22:32:14','49','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(759,'create','2013-10-27 22:34:54','79','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(760,'create','2013-10-27 22:34:55','80','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(761,'create','2013-10-27 22:34:55','57','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(762,'create','2013-10-27 22:34:55','85','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(763,'create','2013-10-27 22:34:55','86','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(764,'create','2013-10-27 22:34:55','42','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(765,'create','2013-10-27 22:34:55','39','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(766,'create','2013-10-27 22:34:55','20','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(767,'create','2013-10-27 22:35:59','2','SisGG\\FinalBundle\\Entity\\NotaCredito',1,'N;','admin'),(768,'create','2013-10-27 22:39:32','5','SisGG\\FinalBundle\\Entity\\Cliente',1,'a:6:{s:5:\"email\";N;s:6:\"estado\";s:6:\"activo\";s:9:\"documento\";N;s:8:\"apellido\";s:5:\"Soley\";s:8:\"telefono\";a:1:{s:2:\"id\";i:5;}s:13:\"tipoDocumento\";N;}','admin'),(769,'create','2013-10-27 22:39:32','5','SisGG\\FinalBundle\\Entity\\Telefono',1,'N;','admin'),(770,'create','2013-10-27 22:40:27','55','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-27 22:40:27\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(771,'create','2013-10-27 22:40:27','119','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(772,'create','2013-10-27 22:40:27','120','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(773,'create','2013-10-27 22:40:27','121','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(774,'create','2013-10-27 22:40:55','50','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(775,'create','2013-10-27 22:41:55','81','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(776,'create','2013-10-27 22:41:55','58','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(777,'create','2013-10-27 22:41:55','87','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(778,'create','2013-10-27 22:41:55','88','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(779,'create','2013-10-27 22:41:55','89','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(780,'create','2013-10-27 22:41:55','43','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(781,'create','2013-10-27 22:41:55','5','SisGG\\FinalBundle\\Entity\\Valor',1,'N;','admin'),(782,'create','2013-10-27 22:41:55','40','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(783,'create','2013-10-27 22:41:55','21','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(784,'create','2013-10-27 22:43:23','5','SisGG\\FinalBundle\\Entity\\RegistroEnvio',1,'N;','admin'),(785,'create','2013-10-27 22:43:52','82','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(786,'create','2013-10-27 22:44:41','56','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-27 22:44:41\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(787,'create','2013-10-27 22:44:41','122','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(788,'create','2013-10-27 22:44:41','123','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(789,'create','2013-10-27 22:44:52','51','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(790,'create','2013-10-27 22:46:51','57','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-27 22:46:51\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(791,'create','2013-10-27 22:46:51','124','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(792,'create','2013-10-27 22:49:49','6','SisGG\\FinalBundle\\Entity\\Plato',1,'N;','admin'),(793,'create','2013-10-27 22:51:15','7','SisGG\\FinalBundle\\Entity\\Plato',1,'N;','admin'),(794,'create','2013-10-27 22:52:37','8','SisGG\\FinalBundle\\Entity\\Plato',1,'N;','admin'),(795,'create','2013-10-27 22:53:53','9','SisGG\\FinalBundle\\Entity\\Mercaderia',1,'N;','admin'),(796,'create','2013-10-27 22:55:12','10','SisGG\\FinalBundle\\Entity\\Mercaderia',1,'N;','admin'),(797,'create','2013-10-27 22:58:31','11','SisGG\\FinalBundle\\Entity\\Plato',1,'N;','admin'),(798,'create','2013-10-27 22:59:57','58','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-27 22:59:57\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(799,'create','2013-10-27 22:59:57','125','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(800,'create','2013-10-27 22:59:57','126','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(801,'create','2013-10-27 23:00:52','59','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-27 23:00:52\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(802,'create','2013-10-27 23:00:52','127','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(803,'create','2013-10-27 23:00:52','128','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(804,'create','2013-10-27 23:00:52','129','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(805,'create','2013-10-27 23:00:52','130','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(806,'create','2013-10-27 23:00:52','131','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(807,'create','2013-10-27 23:00:52','132','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(808,'create','2013-10-27 23:00:52','133','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(809,'create','2013-10-27 23:01:27','52','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(810,'create','2013-10-27 23:01:46','83','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(811,'create','2013-10-27 23:01:47','59','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(812,'create','2013-10-27 23:01:47','90','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(813,'create','2013-10-27 23:01:47','91','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(814,'create','2013-10-27 23:01:47','92','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(815,'create','2013-10-27 23:01:47','93','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(816,'create','2013-10-27 23:01:47','94','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(817,'create','2013-10-27 23:01:47','95','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(818,'create','2013-10-27 23:01:47','96','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(819,'create','2013-10-27 23:01:47','44','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(820,'create','2013-10-27 23:01:47','26','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(821,'create','2013-10-27 23:01:47','27','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(822,'create','2013-10-27 23:01:47','22','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(823,'create','2013-10-27 23:03:57','53','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(824,'create','2013-10-27 23:05:50','60','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-27 23:05:50\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(825,'create','2013-10-27 23:05:50','134','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(826,'create','2013-10-27 23:05:50','135','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(827,'create','2013-10-27 23:06:22','61','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-27 23:06:22\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(828,'create','2013-10-27 23:06:22','136','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(829,'create','2013-10-27 23:06:22','137','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(830,'create','2013-10-27 23:07:04','62','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-27 23:07:04\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(831,'create','2013-10-27 23:07:04','138','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(832,'create','2013-10-27 23:07:04','139','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(833,'create','2013-10-27 23:08:01','63','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-27 23:08:01\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(834,'create','2013-10-27 23:08:01','140','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(835,'create','2013-10-27 23:08:01','141','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(836,'create','2013-10-27 23:08:01','142','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(837,'create','2013-10-27 23:08:43','64','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-27 23:08:43\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(838,'create','2013-10-27 23:08:43','143','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(839,'create','2013-10-27 23:08:43','144','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(840,'create','2013-10-27 23:10:16','65','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-27 23:10:16\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(841,'create','2013-10-27 23:10:16','145','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(842,'create','2013-10-27 23:10:16','146','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(843,'create','2013-10-27 23:10:16','147','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(844,'create','2013-10-27 23:10:42','54','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(845,'create','2013-10-28 13:58:15','84','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(846,'create','2013-10-28 13:58:15','60','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(847,'create','2013-10-28 13:58:15','97','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(848,'create','2013-10-28 13:58:15','98','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(849,'create','2013-10-28 13:58:15','45','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(850,'create','2013-10-28 13:58:15','23','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(851,'create','2013-10-28 14:13:31','55','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(852,'create','2013-10-28 14:13:55','61','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(853,'create','2013-10-28 14:13:55','99','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(854,'create','2013-10-28 14:13:55','100','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(855,'create','2013-10-28 14:13:55','41','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(856,'create','2013-10-28 14:13:55','24','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(857,'create','2013-10-28 14:14:48','62','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(858,'create','2013-10-28 14:14:48','101','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(859,'create','2013-10-28 14:14:48','42','SisGG\\FinalBundle\\Entity\\ItemRecargoVenta',1,'N;','admin'),(860,'create','2013-10-28 14:14:48','28','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(861,'create','2013-10-28 14:14:48','29','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(862,'create','2013-10-28 14:14:48','25','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(863,'create','2013-10-28 14:15:21','6','SisGG\\FinalBundle\\Entity\\RegistroEnvio',1,'N;','admin'),(864,'create','2013-10-28 14:40:05','85','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(865,'create','2013-10-28 14:42:11','4','SisGG\\FinalBundle\\Entity\\TipoCobro',1,'N;','admin'),(866,'create','2013-10-28 14:42:11','2','SisGG\\FinalBundle\\Entity\\Campo',1,'N;','admin'),(867,'create','2013-10-28 15:15:52','66','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-28 15:15:51\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(868,'create','2013-10-28 15:15:52','148','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(869,'create','2013-10-28 15:15:52','149','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(870,'create','2013-10-29 20:38:44','6','SisGG\\FinalBundle\\Entity\\Cliente',1,'a:6:{s:5:\"email\";N;s:6:\"estado\";s:6:\"activo\";s:9:\"documento\";N;s:8:\"apellido\";s:5:\"Ayala\";s:8:\"telefono\";a:1:{s:2:\"id\";i:6;}s:13:\"tipoDocumento\";N;}','admin'),(871,'create','2013-10-29 20:38:44','6','SisGG\\FinalBundle\\Entity\\Telefono',1,'N;','admin'),(872,'create','2013-10-29 20:55:35','7','SisGG\\FinalBundle\\Entity\\Cliente',1,'a:6:{s:5:\"email\";N;s:6:\"estado\";s:6:\"activo\";s:9:\"documento\";N;s:8:\"apellido\";s:8:\"Amarilla\";s:8:\"telefono\";a:1:{s:2:\"id\";i:7;}s:13:\"tipoDocumento\";N;}','admin'),(873,'create','2013-10-29 20:55:35','7','SisGG\\FinalBundle\\Entity\\Telefono',1,'N;','admin'),(874,'create','2013-10-30 16:00:19','8','SisGG\\FinalBundle\\Entity\\Cliente',1,'a:6:{s:5:\"email\";N;s:6:\"estado\";s:6:\"activo\";s:9:\"documento\";N;s:8:\"apellido\";s:6:\"Acosta\";s:8:\"telefono\";a:1:{s:2:\"id\";i:8;}s:13:\"tipoDocumento\";N;}','admin'),(875,'create','2013-10-30 16:00:19','8','SisGG\\FinalBundle\\Entity\\Telefono',1,'N;','admin'),(876,'create','2013-10-30 16:02:51','9','SisGG\\FinalBundle\\Entity\\Cliente',1,'a:6:{s:5:\"email\";N;s:6:\"estado\";s:6:\"activo\";s:9:\"documento\";N;s:8:\"apellido\";s:6:\"Blanco\";s:8:\"telefono\";a:1:{s:2:\"id\";i:9;}s:13:\"tipoDocumento\";N;}','admin'),(877,'create','2013-10-30 16:02:51','9','SisGG\\FinalBundle\\Entity\\Telefono',1,'N;','admin'),(878,'create','2013-10-30 16:09:01','10','SisGG\\FinalBundle\\Entity\\Cliente',1,'a:6:{s:5:\"email\";N;s:6:\"estado\";s:6:\"activo\";s:9:\"documento\";N;s:8:\"apellido\";s:5:\"Pirlo\";s:8:\"telefono\";a:1:{s:2:\"id\";i:10;}s:13:\"tipoDocumento\";N;}','admin'),(879,'create','2013-10-30 16:09:01','10','SisGG\\FinalBundle\\Entity\\Telefono',1,'N;','admin'),(880,'create','2013-10-30 16:10:55','11','SisGG\\FinalBundle\\Entity\\Cliente',1,'a:6:{s:5:\"email\";N;s:6:\"estado\";s:6:\"activo\";s:9:\"documento\";N;s:8:\"apellido\";s:5:\"Tevez\";s:8:\"telefono\";a:1:{s:2:\"id\";i:11;}s:13:\"tipoDocumento\";N;}','admin'),(881,'create','2013-10-30 16:10:55','11','SisGG\\FinalBundle\\Entity\\Telefono',1,'N;','admin'),(882,'create','2013-10-30 16:12:38','12','SisGG\\FinalBundle\\Entity\\Cliente',1,'a:6:{s:5:\"email\";N;s:6:\"estado\";s:6:\"activo\";s:9:\"documento\";N;s:8:\"apellido\";s:6:\"Aguero\";s:8:\"telefono\";a:1:{s:2:\"id\";i:12;}s:13:\"tipoDocumento\";N;}','admin'),(883,'create','2013-10-30 16:12:38','12','SisGG\\FinalBundle\\Entity\\Telefono',1,'N;','admin'),(884,'create','2013-10-30 16:14:34','13','SisGG\\FinalBundle\\Entity\\Cliente',1,'a:6:{s:5:\"email\";N;s:6:\"estado\";s:6:\"activo\";s:9:\"documento\";N;s:8:\"apellido\";s:9:\"Gigliotti\";s:8:\"telefono\";a:1:{s:2:\"id\";i:13;}s:13:\"tipoDocumento\";N;}','admin'),(885,'create','2013-10-30 16:14:34','13','SisGG\\FinalBundle\\Entity\\Telefono',1,'N;','admin'),(886,'create','2013-10-30 17:05:01','2','SisGG\\FinalBundle\\Entity\\Provincia',1,'N;','admin'),(887,'create','2013-10-30 17:05:23','3','SisGG\\FinalBundle\\Entity\\Provincia',1,'N;','admin'),(888,'create','2013-10-30 17:05:48','4','SisGG\\FinalBundle\\Entity\\Provincia',1,'N;','admin'),(889,'create','2013-10-30 17:06:00','5','SisGG\\FinalBundle\\Entity\\Provincia',1,'N;','admin'),(890,'create','2013-10-30 17:06:09','6','SisGG\\FinalBundle\\Entity\\Provincia',1,'N;','admin'),(891,'create','2013-10-30 17:06:19','7','SisGG\\FinalBundle\\Entity\\Provincia',1,'N;','admin'),(892,'create','2013-10-30 17:06:55','8','SisGG\\FinalBundle\\Entity\\Provincia',1,'N;','admin'),(893,'create','2013-10-30 17:07:07','9','SisGG\\FinalBundle\\Entity\\Provincia',1,'N;','admin'),(894,'create','2013-10-30 17:07:23','10','SisGG\\FinalBundle\\Entity\\Provincia',1,'N;','admin'),(895,'create','2013-10-30 17:07:43','11','SisGG\\FinalBundle\\Entity\\Provincia',1,'N;','admin'),(896,'create','2013-10-30 17:08:04','12','SisGG\\FinalBundle\\Entity\\Provincia',1,'N;','admin'),(897,'create','2013-10-30 17:08:34','13','SisGG\\FinalBundle\\Entity\\Provincia',1,'N;','admin'),(898,'create','2013-10-30 17:08:49','14','SisGG\\FinalBundle\\Entity\\Provincia',1,'N;','admin'),(899,'create','2013-10-30 17:09:03','15','SisGG\\FinalBundle\\Entity\\Provincia',1,'N;','admin'),(900,'create','2013-10-30 17:09:21','16','SisGG\\FinalBundle\\Entity\\Provincia',1,'N;','admin'),(901,'create','2013-10-30 17:09:32','17','SisGG\\FinalBundle\\Entity\\Provincia',1,'N;','admin'),(902,'create','2013-10-30 17:09:46','18','SisGG\\FinalBundle\\Entity\\Provincia',1,'N;','admin'),(903,'create','2013-10-30 17:10:00','19','SisGG\\FinalBundle\\Entity\\Provincia',1,'N;','admin'),(904,'create','2013-10-30 17:10:19','20','SisGG\\FinalBundle\\Entity\\Provincia',1,'N;','admin'),(905,'create','2013-10-30 17:10:41','21','SisGG\\FinalBundle\\Entity\\Provincia',1,'N;','admin'),(906,'create','2013-10-30 17:10:56','22','SisGG\\FinalBundle\\Entity\\Provincia',1,'N;','admin'),(907,'create','2013-10-30 17:11:51','23','SisGG\\FinalBundle\\Entity\\Provincia',1,'N;','admin'),(908,'update','2013-10-31 16:39:24','8','SisGG\\FinalBundle\\Entity\\Cliente',2,'a:1:{s:6:\"estado\";s:8:\"inactivo\";}','admin'),(909,'create','2013-10-31 22:28:34','1','SisGG\\FinalBundle\\Entity\\CuentaCorriente',1,'N;','admin'),(910,'create','2013-11-02 11:01:29','2','SisGG\\FinalBundle\\Entity\\CuentaCorriente',1,'N;','admin'),(911,'create','2013-11-02 11:01:50','3','SisGG\\FinalBundle\\Entity\\CuentaCorriente',1,'N;','admin'),(912,'create','2013-11-02 11:17:50','4','SisGG\\FinalBundle\\Entity\\CuentaCorriente',1,'N;','admin'),(913,'create','2013-11-02 11:19:17','67','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-02 11:19:17\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(914,'create','2013-11-02 11:19:17','150','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(915,'create','2013-11-02 11:19:17','151','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(916,'create','2013-11-02 11:19:17','152','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(917,'create','2013-11-02 17:19:32','86','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(918,'create','2013-11-02 17:19:32','63','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(919,'create','2013-11-02 17:19:32','102','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(920,'create','2013-11-02 17:19:32','103','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(921,'create','2013-11-02 17:19:32','104','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(922,'create','2013-11-02 17:19:32','46','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(923,'create','2013-11-02 17:19:32','26','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(924,'create','2013-11-02 17:19:59','68','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-02 17:19:59\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(925,'create','2013-11-02 17:19:59','153','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(926,'create','2013-11-02 17:19:59','154','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(927,'create','2013-11-02 17:19:59','155','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(928,'create','2013-11-02 17:57:23','64','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(929,'create','2013-11-02 17:57:23','105','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(930,'create','2013-11-02 17:57:23','106','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(931,'create','2013-11-02 17:57:23','107','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(932,'create','2013-11-02 17:57:23','30','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(933,'create','2013-11-02 17:57:23','31','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(934,'create','2013-11-02 17:57:23','27','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(935,'create','2013-11-02 17:57:52','69','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-02 17:57:52\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(936,'create','2013-11-02 17:57:52','156','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(937,'create','2013-11-02 17:57:52','157','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(938,'create','2013-11-02 17:57:52','158','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(939,'create','2013-11-02 18:03:27','5','SisGG\\FinalBundle\\Entity\\CuentaCorriente',1,'N;','admin'),(940,'create','2013-11-02 18:06:54','65','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(941,'create','2013-11-02 18:06:54','108','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(942,'create','2013-11-02 18:06:54','109','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(943,'create','2013-11-02 18:06:54','110','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(944,'create','2013-11-02 18:06:54','32','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(945,'create','2013-11-02 18:06:54','33','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(946,'create','2013-11-02 18:06:54','28','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(947,'create','2013-11-02 18:40:07','70','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-02 18:40:07\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(948,'create','2013-11-02 18:40:07','159','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(949,'create','2013-11-02 18:40:07','160','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(950,'create','2013-11-02 18:42:10','66','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(951,'create','2013-11-02 18:42:10','111','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(952,'create','2013-11-02 18:42:10','112','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(953,'create','2013-11-02 18:42:10','29','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(955,'create','2013-11-02 18:43:47','71','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-02 18:43:47\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(956,'create','2013-11-02 18:43:47','161','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(957,'create','2013-11-02 18:44:03','67','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(958,'create','2013-11-02 18:44:03','113','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(959,'create','2013-11-02 18:44:03','30','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(960,'create','2013-11-02 18:44:03','1','SisGG\\FinalBundle\\Entity\\MovimientoCuentaCorrienteDebe',1,'N;','admin'),(961,'create','2013-11-02 18:45:33','72','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-02 18:45:33\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(962,'create','2013-11-02 18:45:33','162','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(963,'create','2013-11-02 18:45:33','163','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(964,'create','2013-11-02 18:45:33','164','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(965,'create','2013-11-02 18:46:39','87','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(966,'create','2013-11-02 18:46:39','68','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(967,'create','2013-11-02 18:46:39','114','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(968,'create','2013-11-02 18:46:39','115','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(969,'create','2013-11-02 18:46:39','116','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(970,'create','2013-11-02 18:46:39','47','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(971,'create','2013-11-02 18:46:39','31','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(972,'create','2013-11-02 18:46:39','2','SisGG\\FinalBundle\\Entity\\MovimientoCuentaCorrienteDebe',1,'N;','admin'),(973,'create','2013-11-02 19:15:41','73','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-02 19:15:41\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(974,'create','2013-11-02 19:15:41','165','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(975,'create','2013-11-02 19:15:57','69','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(976,'create','2013-11-02 19:15:57','117','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(977,'create','2013-11-02 19:15:57','34','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(978,'create','2013-11-02 19:15:57','35','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(979,'create','2013-11-02 19:15:57','32','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(980,'create','2013-11-02 19:15:57','3','SisGG\\FinalBundle\\Entity\\MovimientoCuentaCorrienteDebe',1,'N;','admin'),(981,'create','2013-11-02 19:19:02','74','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-02 19:19:02\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(982,'create','2013-11-02 19:19:02','166','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(983,'create','2013-11-02 19:19:02','167','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(984,'create','2013-11-02 19:19:20','70','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(985,'create','2013-11-02 19:19:20','118','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(986,'create','2013-11-02 19:19:20','119','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(987,'create','2013-11-02 19:19:20','36','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(988,'create','2013-11-02 19:19:20','37','SisGG\\FinalBundle\\Entity\\ItemDescuentoVenta',1,'N;','admin'),(989,'create','2013-11-02 19:19:20','33','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(990,'create','2013-11-02 19:19:20','4','SisGG\\FinalBundle\\Entity\\MovimientoCuentaCorrienteDebe',1,'N;','admin'),(991,'create','2013-11-02 20:36:36','75','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-02 20:36:36\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(992,'create','2013-11-02 20:36:36','168','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(995,'create','2013-11-03 10:35:25','5','SisGG\\FinalBundle\\Entity\\MovimientoCuentaCorrienteHaber',1,'N;','admin'),(996,'create','2013-11-03 10:35:25','49','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(997,'create','2013-11-03 18:15:16','88','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(998,'create','2013-11-03 18:15:16','1','SisGG\\FinalBundle\\Entity\\Recibo',1,'N;','admin'),(999,'create','2013-11-03 18:15:16','6','SisGG\\FinalBundle\\Entity\\MovimientoCuentaCorrienteHaber',1,'N;','admin'),(1000,'create','2013-11-03 18:30:02','89','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(1001,'create','2013-11-03 18:30:02','2','SisGG\\FinalBundle\\Entity\\Recibo',1,'N;','admin'),(1002,'create','2013-11-03 18:30:02','7','SisGG\\FinalBundle\\Entity\\MovimientoCuentaCorrienteHaber',1,'N;','admin'),(1003,'create','2013-11-03 18:32:15','71','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(1004,'create','2013-11-03 18:32:15','120','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(1005,'create','2013-11-03 18:32:15','34','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(1006,'create','2013-11-03 18:32:15','8','SisGG\\FinalBundle\\Entity\\MovimientoCuentaCorrienteDebe',1,'N;','admin'),(1007,'create','2013-11-03 20:44:08','2','SisGG\\FinalBundle\\Entity\\Sector',1,'N;','admin'),(1008,'create','2013-11-03 20:44:08','11','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1009,'create','2013-11-03 20:44:08','12','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1010,'create','2013-11-03 20:44:08','13','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1011,'create','2013-11-03 20:44:08','14','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1012,'create','2013-11-03 20:44:08','15','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1013,'create','2013-11-03 20:44:08','16','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1014,'create','2013-11-03 20:44:08','17','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1015,'create','2013-11-03 20:44:08','18','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1016,'create','2013-11-03 20:44:08','19','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1017,'create','2013-11-03 20:44:08','20','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1018,'create','2013-11-03 20:44:08','21','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1019,'create','2013-11-03 20:44:08','22','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1020,'create','2013-11-03 20:44:08','23','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1021,'create','2013-11-03 20:44:08','24','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1022,'create','2013-11-03 20:44:08','25','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1023,'create','2013-11-03 20:44:08','26','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1024,'create','2013-11-03 20:44:08','27','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1025,'create','2013-11-03 20:44:08','28','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1026,'create','2013-11-03 20:44:08','29','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1027,'create','2013-11-03 20:44:08','30','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1028,'create','2013-11-03 20:44:08','31','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1029,'create','2013-11-03 20:44:08','32','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1030,'create','2013-11-03 20:44:08','33','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1031,'create','2013-11-03 20:44:08','34','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1032,'create','2013-11-03 20:44:08','35','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1033,'create','2013-11-03 20:44:08','36','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1034,'create','2013-11-03 20:44:08','37','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1035,'create','2013-11-03 20:44:08','38','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1036,'create','2013-11-03 20:44:08','39','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1037,'create','2013-11-03 20:44:08','40','SisGG\\FinalBundle\\Entity\\Mesa',1,'N;','admin'),(1038,'remove','2013-11-03 21:08:38','55','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1039,'remove','2013-11-03 21:08:45','54','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1040,'remove','2013-11-03 21:08:46','53','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1041,'remove','2013-11-03 21:08:48','52','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1042,'remove','2013-11-03 21:08:50','51','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1043,'remove','2013-11-03 21:08:54','50','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1044,'remove','2013-11-03 21:08:55','49','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1045,'remove','2013-11-03 21:08:56','48','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1046,'remove','2013-11-03 21:09:06','47','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1047,'remove','2013-11-03 21:09:12','46','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1048,'remove','2013-11-03 21:09:19','45','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1049,'remove','2013-11-03 21:09:20','44','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1050,'remove','2013-11-03 21:09:27','43','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1051,'remove','2013-11-03 21:09:30','42','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1052,'remove','2013-11-03 21:09:31','41','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1053,'remove','2013-11-03 21:09:34','40','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1054,'remove','2013-11-03 21:09:35','39','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1055,'remove','2013-11-03 21:09:39','38','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1056,'remove','2013-11-03 21:09:40','37','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1057,'remove','2013-11-03 21:09:44','36','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1058,'remove','2013-11-03 21:09:46','35','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1059,'remove','2013-11-03 21:09:48','34','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1060,'remove','2013-11-03 21:09:52','33','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1061,'remove','2013-11-03 21:09:54','32','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1062,'remove','2013-11-03 21:09:55','31','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1063,'remove','2013-11-03 21:09:59','30','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1064,'remove','2013-11-03 21:10:01','29','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1065,'remove','2013-11-03 21:10:03','28','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1066,'remove','2013-11-03 21:10:06','27','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1067,'remove','2013-11-03 21:10:08','26','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1068,'remove','2013-11-03 21:10:10','25','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1069,'remove','2013-11-03 21:10:12','24','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1070,'remove','2013-11-03 21:10:14','23','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1071,'remove','2013-11-03 21:10:15','22','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1072,'remove','2013-11-03 21:10:21','21','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1073,'remove','2013-11-03 21:10:24','20','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1074,'create','2013-11-03 21:56:13','12','SisGG\\FinalBundle\\Entity\\MateriaPrima',1,'N;','admin'),(1075,'create','2013-11-03 21:58:16','3','SisGG\\FinalBundle\\Entity\\Ingrediente',1,'N;','admin'),(1076,'create','2013-11-03 22:06:14','4','SisGG\\FinalBundle\\Entity\\Tasa',1,'N;','admin'),(1077,'create','2013-11-03 22:11:26','76','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-03 22:11:26\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(1078,'create','2013-11-03 22:11:26','169','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1079,'create','2013-11-03 22:12:08','56','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(1080,'create','2013-11-03 22:13:02','90','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(1081,'create','2013-11-03 22:13:02','72','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(1082,'create','2013-11-03 22:13:02','121','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(1083,'create','2013-11-03 22:13:02','50','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(1084,'create','2013-11-03 22:13:02','35','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(1085,'create','2013-11-03 22:18:27','91','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(1086,'create','2013-11-03 22:18:41','92','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(1087,'create','2013-11-03 22:18:55','93','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(1088,'remove','2013-11-03 22:19:47','56','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1089,'create','2013-11-04 11:53:19','2','SisGG\\FinalBundle\\Entity\\Tanda',1,'N;','admin'),(1090,'create','2013-11-04 11:55:20','77','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-04 11:55:20\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(1091,'create','2013-11-04 11:55:20','170','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1092,'create','2013-11-04 11:55:20','171','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1093,'create','2013-11-04 11:56:14','1','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(1094,'create','2013-11-04 11:56:48','94','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(1095,'create','2013-11-04 11:56:48','73','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(1096,'create','2013-11-04 11:56:48','122','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(1097,'create','2013-11-04 11:56:48','123','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(1098,'create','2013-11-04 11:56:48','51','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(1099,'create','2013-11-04 11:56:48','6','SisGG\\FinalBundle\\Entity\\Valor',1,'N;','admin'),(1100,'create','2013-11-04 11:56:48','36','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(1101,'create','2013-11-04 15:32:17','78','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-04 15:32:17\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(1102,'create','2013-11-04 15:32:17','172','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1103,'create','2013-11-04 15:32:17','173','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1104,'create','2013-11-04 15:32:17','174','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1105,'create','2013-11-04 15:33:56','2','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(1106,'create','2013-11-04 15:35:41','95','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(1107,'create','2013-11-04 15:35:41','96','SisGG\\FinalBundle\\Entity\\Salida',1,'N;','admin'),(1108,'create','2013-11-04 15:35:41','74','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(1109,'create','2013-11-04 15:35:41','124','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(1110,'create','2013-11-04 15:35:41','125','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(1111,'create','2013-11-04 15:35:41','52','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(1112,'create','2013-11-04 15:35:41','37','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(1113,'create','2013-11-04 15:40:12','79','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-04 15:40:12\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(1114,'create','2013-11-04 15:40:12','175','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1115,'create','2013-11-04 15:41:28','7','SisGG\\FinalBundle\\Entity\\RegistroEnvio',1,'N;','admin'),(1116,'create','2013-11-04 15:43:06','97','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(1117,'create','2013-11-04 15:44:13','176','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1118,'create','2013-11-04 15:44:45','3','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(1119,'create','2013-11-04 15:45:29','98','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(1120,'create','2013-11-04 15:45:29','75','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(1121,'create','2013-11-04 15:45:29','126','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(1122,'create','2013-11-04 15:45:29','127','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(1123,'create','2013-11-04 15:45:29','128','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(1124,'create','2013-11-04 15:45:29','129','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(1125,'create','2013-11-04 15:45:29','53','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(1126,'create','2013-11-04 15:45:29','7','SisGG\\FinalBundle\\Entity\\Valor',1,'N;','admin'),(1127,'create','2013-11-04 15:45:29','38','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(1128,'create','2013-11-04 15:45:49','80','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-04 15:45:49\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(1129,'create','2013-11-04 15:45:49','177','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1130,'create','2013-11-04 15:45:49','178','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1131,'create','2013-11-04 15:47:00','6','SisGG\\FinalBundle\\Entity\\CuentaCorriente',1,'N;','admin'),(1132,'create','2013-11-04 15:47:09','76','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(1133,'create','2013-11-04 15:47:09','130','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(1134,'create','2013-11-04 15:47:09','131','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(1135,'create','2013-11-04 15:47:09','39','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(1136,'create','2013-11-04 15:47:09','9','SisGG\\FinalBundle\\Entity\\MovimientoCuentaCorrienteDebe',1,'N;','admin'),(1137,'create','2013-11-04 15:48:12','99','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(1138,'create','2013-11-04 15:48:12','3','SisGG\\FinalBundle\\Entity\\Recibo',1,'N;','admin'),(1139,'create','2013-11-04 15:48:12','10','SisGG\\FinalBundle\\Entity\\MovimientoCuentaCorrienteHaber',1,'N;','admin'),(1140,'create','2013-11-04 15:49:23','100','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(1141,'create','2013-11-04 15:49:23','4','SisGG\\FinalBundle\\Entity\\Recibo',1,'N;','admin'),(1142,'create','2013-11-04 15:49:23','11','SisGG\\FinalBundle\\Entity\\MovimientoCuentaCorrienteHaber',1,'N;','admin'),(1143,'create','2013-11-05 21:23:15','81','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-05 21:23:15\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(1144,'create','2013-11-05 21:23:15','179','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1145,'create','2013-11-05 21:23:15','180','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1146,'create','2013-11-06 16:05:37','1','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1147,'create','2013-11-06 16:40:10','2','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1148,'create','2013-11-06 16:54:50','3','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1149,'create','2013-11-06 17:42:44','4','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1150,'create','2013-11-06 17:48:50','82','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-06 17:48:50\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(1151,'create','2013-11-06 17:48:50','181','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1152,'create','2013-11-06 17:48:50','182','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1153,'create','2013-11-06 17:48:50','183','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1158,'create','2013-11-06 17:52:16','84','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-06 17:52:16\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(1159,'create','2013-11-06 17:52:16','184','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1160,'create','2013-11-06 17:53:19','85','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-06 17:53:19\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(1161,'create','2013-11-06 17:53:19','185','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1162,'create','2013-11-06 18:06:53','186','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1163,'create','2013-11-06 18:06:53','187','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1164,'create','2013-11-06 18:06:53','188','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1165,'create','2013-11-06 18:06:53','189','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1166,'create','2013-11-06 18:06:53','190','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1167,'create','2013-11-06 18:06:53','191','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1168,'create','2013-11-06 18:06:53','192','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1169,'create','2013-11-06 18:06:53','193','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1170,'create','2013-11-06 18:06:53','194','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1171,'create','2013-11-06 18:06:53','195','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1172,'create','2013-11-06 18:06:53','196','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1173,'create','2013-11-06 18:06:53','197','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1174,'create','2013-11-06 18:06:53','198','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1175,'create','2013-11-06 18:06:53','199','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1176,'create','2013-11-06 18:06:53','200','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1177,'create','2013-11-06 18:06:53','201','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1178,'create','2013-11-06 18:09:08','5','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1179,'create','2013-11-06 18:15:46','6','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1180,'create','2013-11-06 18:16:54','7','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1181,'create','2013-11-07 18:50:34','86','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-07 18:50:34\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(1182,'create','2013-11-07 18:50:34','202','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1183,'create','2013-11-07 18:50:34','203','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1184,'create','2013-11-07 18:53:43','8','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1185,'create','2013-11-07 18:57:07','9','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1186,'create','2013-11-07 18:57:42','10','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1187,'create','2013-11-07 19:05:20','11','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1188,'create','2013-11-07 19:15:30','12','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1189,'create','2013-11-07 19:15:43','13','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1190,'create','2013-11-07 19:31:14','14','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1191,'create','2013-11-07 22:05:50','15','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1192,'create','2013-11-07 22:12:11','16','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1193,'create','2013-11-07 22:13:49','17','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1194,'create','2013-11-07 22:21:40','18','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1195,'create','2013-11-07 22:22:26','19','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1196,'create','2013-11-07 22:22:41','20','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1197,'create','2013-11-07 22:24:00','21','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1198,'create','2013-11-08 18:16:18','87','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-08 18:16:18\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(1199,'create','2013-11-08 18:16:18','204','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1200,'create','2013-11-08 18:38:16','22','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1201,'create','2013-11-08 18:45:37','4','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(1202,'create','2013-11-08 18:55:22','23','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1203,'create','2013-11-08 18:57:11','24','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1204,'create','2013-11-16 18:32:33','101','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(1205,'create','2013-11-16 18:32:33','5','SisGG\\FinalBundle\\Entity\\Recibo',1,'N;','admin'),(1206,'create','2013-11-16 18:32:33','12','SisGG\\FinalBundle\\Entity\\MovimientoCuentaCorrienteHaber',1,'N;','admin'),(1207,'create','2013-11-16 18:39:05','25','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1208,'create','2013-11-23 08:09:16','102','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(1209,'create','2013-11-23 08:09:16','77','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(1210,'create','2013-11-23 08:09:16','132','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(1211,'create','2013-11-23 08:09:16','133','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(1212,'create','2013-11-23 08:09:16','54','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(1213,'create','2013-11-23 08:09:16','40','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(1214,'create','2013-11-23 08:11:34','5','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(1215,'create','2013-11-23 08:11:42','6','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(1216,'create','2013-11-23 08:11:46','7','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(1217,'create','2013-11-23 08:12:36','8','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(1218,'create','2013-11-23 08:12:39','9','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(1219,'create','2013-11-23 08:12:44','10','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(1220,'create','2013-11-23 08:12:48','11','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(1221,'create','2013-11-23 08:14:41','78','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(1222,'create','2013-11-23 08:14:41','134','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(1223,'create','2013-11-23 08:14:41','135','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(1224,'create','2013-11-23 08:14:41','41','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(1225,'create','2013-11-23 08:14:41','13','SisGG\\FinalBundle\\Entity\\MovimientoCuentaCorrienteDebe',1,'N;','admin'),(1226,'create','2013-11-25 01:03:32','88','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-25 01:03:32\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(1227,'create','2013-11-25 01:03:32','205','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1228,'create','2013-11-25 01:03:32','206','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1229,'create','2013-11-25 01:03:32','207','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1230,'create','2013-11-25 01:05:49','89','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-25 01:05:49\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(1231,'create','2013-11-25 01:05:49','208','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1232,'create','2013-11-25 01:06:13','12','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(1233,'create','2013-11-25 09:11:30','90','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-25 09:11:30\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(1234,'create','2013-11-25 09:11:30','209','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1235,'create','2013-11-25 09:11:30','210','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1236,'create','2013-11-25 09:19:38','103','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(1237,'create','2013-11-25 09:19:39','79','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(1238,'create','2013-11-25 09:19:39','136','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(1239,'create','2013-11-25 09:19:39','55','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(1240,'create','2013-11-25 09:19:39','42','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(1241,'create','2013-11-25 09:21:01','91','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-11-25 09:21:01\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(1242,'create','2013-11-25 09:21:01','211','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1243,'create','2013-11-25 09:21:01','212','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1244,'remove','2013-11-27 14:06:52','12','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1245,'remove','2013-11-27 14:06:59','11','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1246,'remove','2013-11-27 14:07:01','10','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1247,'remove','2013-11-27 14:07:05','9','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1248,'remove','2013-11-27 14:07:07','8','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1249,'remove','2013-11-27 14:07:09','7','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1250,'remove','2013-11-27 14:07:11','6','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1251,'remove','2013-11-27 14:07:15','5','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1252,'remove','2013-11-27 14:07:17','4','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1253,'remove','2013-11-27 14:07:19','3','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1254,'remove','2013-11-27 14:07:21','2','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1255,'remove','2013-11-27 14:07:22','1','SisGG\\FinalBundle\\Entity\\Mensaje',2,'N;','admin'),(1256,'create','2013-11-27 14:45:48','26','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1257,'create','2013-11-27 14:46:53','27','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1258,'create','2013-11-27 14:47:00','28','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1259,'create','2013-11-27 14:47:39','29','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1260,'create','2013-11-27 14:54:09','30','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1261,'create','2013-11-27 14:54:36','31','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1262,'create','2013-11-27 14:54:54','32','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1263,'create','2013-11-27 14:55:15','33','SisGG\\FinalBundle\\Entity\\Redireccion',1,'N;','admin'),(1264,'create','2013-11-27 15:57:19','2','SisGG\\FinalBundle\\Entity\\Rol',1,'a:2:{s:4:\"role\";s:5:\"Admin\";s:6:\"activo\";b:1;}','admin'),(1265,'create','2013-11-27 15:57:19','47','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1266,'create','2013-11-27 15:57:19','48','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1267,'create','2013-11-27 15:57:19','49','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1268,'create','2013-11-27 15:57:19','50','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1269,'create','2013-11-27 15:57:19','51','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1270,'create','2013-11-27 15:57:19','52','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1271,'create','2013-11-27 15:57:19','53','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1272,'create','2013-11-27 15:57:19','54','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1273,'create','2013-11-27 15:57:19','55','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1274,'create','2013-11-27 15:57:19','56','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1275,'create','2013-11-27 15:57:19','57','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1276,'create','2013-11-27 15:57:19','58','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1277,'create','2013-11-27 15:57:19','59','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1278,'create','2013-11-27 15:57:19','60','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1279,'create','2013-11-27 15:57:19','61','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1280,'create','2013-11-27 15:57:19','62','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1281,'create','2013-11-27 15:57:19','63','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1282,'create','2013-11-27 15:57:19','64','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1283,'create','2013-11-27 15:57:19','65','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1284,'create','2013-11-27 15:57:19','66','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1285,'create','2013-11-27 15:57:19','67','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1286,'create','2013-11-27 15:57:19','68','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1287,'create','2013-11-27 15:57:19','69','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1288,'create','2013-11-27 15:57:19','70','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1289,'create','2013-11-27 15:57:19','71','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1290,'create','2013-11-27 15:57:19','72','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1291,'create','2013-11-27 15:57:19','73','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1292,'create','2013-11-27 15:57:19','74','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1293,'create','2013-11-27 15:57:19','75','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1294,'create','2013-11-27 15:57:19','76','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1295,'create','2013-11-27 15:57:19','77','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1296,'create','2013-11-27 15:57:19','78','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1297,'create','2013-11-27 15:57:19','79','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1298,'create','2013-11-27 15:57:19','80','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1299,'create','2013-11-27 15:57:19','81','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1300,'create','2013-11-27 15:57:19','82','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1301,'create','2013-11-27 15:57:19','83','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1302,'create','2013-11-27 15:57:19','84','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1303,'create','2013-11-27 15:57:19','85','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1304,'create','2013-11-27 15:57:19','86','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1305,'create','2013-11-27 15:57:19','87','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1306,'create','2013-11-27 15:57:19','88','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1307,'create','2013-11-27 15:57:19','89','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1308,'create','2013-11-27 15:57:19','90','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1309,'create','2013-11-27 15:57:19','91','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1310,'create','2013-11-27 15:57:19','92','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1311,'create','2013-11-27 15:57:19','93','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1312,'create','2013-11-27 15:57:19','94','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1313,'create','2013-11-27 15:57:19','95','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1314,'create','2013-11-27 15:57:19','96','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1315,'create','2013-11-27 15:57:19','97','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1316,'create','2013-11-27 15:57:19','98','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1317,'create','2013-11-27 15:57:19','99','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1318,'create','2013-11-27 15:57:19','100','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1319,'create','2013-11-27 15:57:19','101','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1320,'create','2013-11-27 15:57:19','102','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1321,'create','2013-11-27 15:57:19','103','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1322,'create','2013-11-27 15:57:19','104','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1323,'create','2013-11-27 15:57:19','105','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1324,'create','2013-11-27 15:57:19','106','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1325,'create','2013-11-27 15:57:19','107','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1326,'create','2013-11-27 15:57:19','108','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1327,'create','2013-11-27 15:57:19','109','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1328,'create','2013-11-27 15:57:19','110','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1329,'create','2013-11-27 15:57:19','111','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1330,'create','2013-11-27 15:57:19','112','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1331,'create','2013-11-27 15:57:19','113','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1332,'create','2013-11-27 15:57:19','114','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1333,'create','2013-11-27 15:57:19','115','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1334,'create','2013-11-27 15:57:19','116','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1335,'create','2013-11-27 15:57:19','117','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1336,'create','2013-11-27 15:57:19','118','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1337,'create','2013-11-27 15:57:19','119','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1338,'create','2013-11-27 15:57:19','120','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1339,'create','2013-11-27 15:57:19','121','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1340,'create','2013-11-27 15:57:19','122','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1341,'create','2013-11-27 15:57:19','123','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1342,'create','2013-11-27 15:57:19','124','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1343,'create','2013-11-27 15:57:19','125','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1344,'create','2013-11-27 15:57:19','126','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1345,'create','2013-11-27 15:57:19','127','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1346,'create','2013-11-27 15:57:19','128','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1347,'create','2013-11-27 15:57:19','129','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1348,'create','2013-11-27 15:57:19','130','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1349,'create','2013-11-27 15:57:19','131','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1350,'create','2013-11-27 15:57:19','132','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1351,'create','2013-11-27 15:57:19','133','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1352,'create','2013-11-27 15:57:19','134','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1353,'create','2013-11-27 15:57:19','135','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1354,'create','2013-11-27 15:57:19','136','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1355,'create','2013-11-27 15:57:19','137','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1356,'create','2013-11-27 15:57:19','138','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1357,'create','2013-11-27 15:57:19','139','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1358,'create','2013-11-27 15:57:19','140','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1359,'create','2013-11-27 15:57:19','141','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1360,'create','2013-11-27 15:57:19','142','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1361,'create','2013-11-27 15:57:19','143','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1362,'create','2013-11-27 15:57:19','144','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1363,'create','2013-11-27 15:57:19','145','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1364,'create','2013-11-27 15:57:19','146','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1365,'create','2013-11-27 15:57:19','147','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1366,'create','2013-11-27 15:57:19','148','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1367,'create','2013-11-27 15:57:19','149','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1368,'create','2013-11-27 15:57:19','150','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1369,'create','2013-11-27 15:57:19','151','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1370,'create','2013-11-27 15:57:19','152','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1371,'create','2013-11-27 15:57:19','153','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1372,'create','2013-11-27 15:57:19','154','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1373,'create','2013-11-27 15:57:19','155','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1374,'create','2013-11-27 15:57:19','156','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1375,'create','2013-11-27 15:57:19','157','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1376,'create','2013-11-27 15:57:19','158','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1377,'create','2013-11-27 15:57:19','159','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1378,'create','2013-11-27 15:57:19','160','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1379,'create','2013-11-27 15:57:19','161','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1380,'create','2013-11-27 15:57:19','162','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1381,'create','2013-11-27 15:57:19','163','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1382,'create','2013-11-27 15:57:19','164','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1383,'create','2013-11-27 15:57:19','165','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1384,'create','2013-11-27 15:57:19','166','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1385,'create','2013-11-27 15:57:19','167','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1386,'create','2013-11-27 15:57:19','168','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1387,'create','2013-11-27 15:57:19','169','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1388,'create','2013-11-27 15:57:19','170','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1389,'create','2013-11-27 15:57:19','171','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1390,'create','2013-11-27 15:57:19','172','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1391,'create','2013-11-27 15:57:19','173','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1392,'create','2013-11-27 15:57:19','174','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1393,'create','2013-11-27 15:57:19','175','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1394,'create','2013-11-27 15:57:19','176','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1395,'create','2013-11-27 15:57:19','177','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1396,'create','2013-11-27 15:57:19','178','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1397,'create','2013-11-27 15:57:19','179','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1398,'create','2013-11-27 15:57:19','180','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1399,'create','2013-11-27 15:57:19','181','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1400,'create','2013-11-27 15:57:19','182','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1401,'create','2013-11-27 15:57:19','183','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1402,'create','2013-11-27 15:57:19','184','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1403,'create','2013-11-27 15:57:19','185','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1404,'create','2013-11-27 15:57:19','186','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1405,'create','2013-11-27 15:57:19','187','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1406,'create','2013-11-27 15:57:19','188','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1407,'create','2013-11-27 15:57:19','189','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1408,'create','2013-11-27 15:57:19','190','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1409,'create','2013-11-27 15:57:19','191','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1410,'create','2013-11-27 15:57:19','192','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1411,'create','2013-11-27 15:57:19','193','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1412,'create','2013-11-27 15:57:19','194','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1413,'create','2013-11-27 15:57:19','195','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1414,'create','2013-11-27 15:57:19','196','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1415,'create','2013-11-27 15:57:19','197','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1416,'create','2013-11-27 15:57:19','198','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1417,'create','2013-11-27 15:57:19','199','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1418,'create','2013-11-27 15:57:19','200','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1419,'create','2013-11-27 15:57:19','201','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1420,'create','2013-11-27 15:57:19','202','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1421,'create','2013-11-27 15:57:19','203','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1422,'create','2013-11-27 15:57:19','204','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1423,'create','2013-11-27 15:57:19','205','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1424,'create','2013-11-27 15:57:19','206','SisGG\\FinalBundle\\Entity\\Permiso',1,'N;','admin'),(1425,'create','2013-11-27 15:58:36','4','SisGG\\FinalBundle\\Entity\\Usuario',1,'a:8:{s:8:\"apellido\";s:6:\"ElLoco\";s:6:\"nombre\";s:5:\"Fabio\";s:5:\"email\";s:16:\"monito@gmail.com\";s:8:\"username\";s:12:\"elloco.fabio\";s:4:\"salt\";s:32:\"1cc4e3f92f34501e1d1c60b01f3d9fa1\";s:8:\"password\";s:40:\"dbc3d6a46ae7817f77f2a7bcf75c8830594e12e7\";s:8:\"isActive\";b:1;s:4:\"role\";a:1:{s:2:\"id\";i:2;}}','admin'),(1426,'create','2013-11-30 23:23:19','1','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(1427,'create','2013-11-30 23:23:23','2','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(1428,'create','2013-11-30 23:23:27','3','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(1429,'create','2013-11-30 23:23:30','4','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(1430,'create','2013-11-30 23:23:33','5','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(1431,'create','2013-11-30 23:28:08','104','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(1432,'create','2013-11-30 23:28:08','80','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(1433,'create','2013-11-30 23:28:08','137','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(1434,'create','2013-11-30 23:28:08','138','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(1435,'create','2013-11-30 23:28:08','56','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(1436,'create','2013-11-30 23:28:08','43','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(1437,'remove','2013-11-30 23:34:58','5','SisGG\\FinalBundle\\Entity\\Mensaje',3,'N;','admin'),(1438,'remove','2013-11-30 23:35:01','4','SisGG\\FinalBundle\\Entity\\Mensaje',3,'N;','admin'),(1439,'remove','2013-11-30 23:35:03','3','SisGG\\FinalBundle\\Entity\\Mensaje',3,'N;','admin'),(1440,'remove','2013-11-30 23:35:05','2','SisGG\\FinalBundle\\Entity\\Mensaje',3,'N;','admin'),(1441,'remove','2013-11-30 23:35:07','1','SisGG\\FinalBundle\\Entity\\Mensaje',3,'N;','admin'),(1442,'create','2013-12-01 00:11:49','92','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-12-01 00:11:49\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(1443,'create','2013-12-01 00:11:49','213','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1444,'create','2013-12-01 00:11:49','214','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1445,'create','2013-12-01 00:12:48','93','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-12-01 00:12:48\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(1446,'create','2013-12-01 00:12:48','215','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1447,'create','2013-12-01 00:16:19','6','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(1448,'create','2013-12-01 00:17:06','105','SisGG\\FinalBundle\\Entity\\Entrada',1,'N;','admin'),(1449,'create','2013-12-01 00:17:06','81','SisGG\\FinalBundle\\Entity\\Venta',1,'N;','admin'),(1450,'create','2013-12-01 00:17:06','139','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(1451,'create','2013-12-01 00:17:06','140','SisGG\\FinalBundle\\Entity\\LineaVenta',1,'N;','admin'),(1452,'create','2013-12-01 00:17:06','57','SisGG\\FinalBundle\\Entity\\Cobro',1,'N;','admin'),(1453,'create','2013-12-01 00:17:06','44','SisGG\\FinalBundle\\Entity\\ItemIvaVenta',1,'N;','admin'),(1454,'create','2013-12-01 00:26:46','94','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-12-01 00:26:46\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(1455,'create','2013-12-01 00:26:46','216','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1456,'create','2013-12-01 00:26:46','217','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1457,'create','2013-12-01 00:27:12','7','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(1458,'create','2013-12-01 00:36:19','8','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(1459,'create','2013-12-01 00:37:59','95','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-12-01 00:37:59\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(1460,'create','2013-12-01 00:37:59','218','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1461,'create','2013-12-01 00:38:50','9','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(1462,'create','2013-12-01 00:40:49','8','SisGG\\FinalBundle\\Entity\\RegistroEnvio',1,'N;','admin'),(1463,'create','2013-12-01 00:57:09','96','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-12-01 00:57:09\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(1464,'create','2013-12-01 00:57:09','219','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1465,'create','2013-12-01 00:57:09','220','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1466,'create','2013-12-01 00:57:09','221','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1467,'create','2013-12-01 00:57:22','10','SisGG\\FinalBundle\\Entity\\Mensaje',1,'N;','admin'),(1468,'create','2013-12-01 00:59:43','97','SisGG\\FinalBundle\\Entity\\Pedido',1,'a:1:{s:11:\"fechapedido\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-12-01 00:59:43\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','admin'),(1469,'create','2013-12-01 00:59:43','222','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1470,'create','2013-12-01 00:59:43','223','SisGG\\FinalBundle\\Entity\\ItemPedido',1,'N;','admin'),(1471,'create','2013-12-01 10:26:56','14','SisGG\\FinalBundle\\Entity\\Telefono',1,'N;','elloco.fabio'),(1472,'update','2013-12-01 10:26:56','1','SisGG\\FinalBundle\\Entity\\Empresa',1,'a:3:{s:4:\"edad\";i:10;s:2:\"ip\";s:12:\"192.168.1.22\";s:9:\"inicioAct\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-10-01 00:00:00\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','elloco.fabio'),(1473,'update','2013-12-01 10:26:56','1','SisGG\\FinalBundle\\Entity\\Direccion',1,'a:1:{s:6:\"numero\";s:4:\"3118\";}','elloco.fabio'),(1474,'create','2013-12-01 11:37:28','106','SisGG\\FinalBundle\\Entity\\Cierre',1,'a:11:{s:7:\"importe\";N;s:10:\"aclaracion\";N;s:5:\"fecha\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-12-01 11:37:28\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}s:4:\"lote\";a:1:{s:2:\"id\";i:4;}s:4:\"tipo\";N;s:8:\"concepto\";N;s:11:\"conformidad\";N;s:12:\"extraerTotal\";N;s:12:\"numeroCierre\";i:4;s:7:\"usuario\";a:1:{s:2:\"id\";i:4;}s:4:\"caja\";a:1:{s:2:\"id\";i:1;}}','elloco.fabio'),(1475,'create','2013-12-01 11:37:28','7','SisGG\\FinalBundle\\Entity\\ItemCierre',1,'a:3:{s:14:\"importeSistema\";s:7:\"3072.65\";s:11:\"importeReal\";d:3072;s:9:\"tipoCobro\";a:1:{s:2:\"id\";i:1;}}','elloco.fabio'),(1476,'create','2013-12-01 11:37:28','8','SisGG\\FinalBundle\\Entity\\ItemCierre',1,'a:3:{s:14:\"importeSistema\";s:5:\"529.8\";s:11:\"importeReal\";d:529.79999999999995;s:9:\"tipoCobro\";a:1:{s:2:\"id\";i:3;}}','elloco.fabio'),(1477,'create','2013-12-01 11:37:28','9','SisGG\\FinalBundle\\Entity\\ItemCierre',1,'a:3:{s:14:\"importeSistema\";s:1:\"0\";s:11:\"importeReal\";d:0;s:9:\"tipoCobro\";a:1:{s:2:\"id\";i:4;}}','elloco.fabio'),(1478,'update','2013-12-01 11:37:28','1','SisGG\\FinalBundle\\Entity\\Caja',2,'a:1:{s:7:\"abierta\";b:0;}','elloco.fabio'),(1479,'update','2013-12-01 11:37:28','4','SisGG\\FinalBundle\\Entity\\Lote',2,'a:1:{s:11:\"fechaCierre\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-12-01 11:37:28\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}}','elloco.fabio'),(1480,'create','2013-12-01 22:27:59','5','SisGG\\FinalBundle\\Entity\\Lote',1,'a:5:{s:13:\"fechaApertura\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-12-01 22:27:59\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}s:11:\"fechaCierre\";N;s:5:\"saldo\";N;s:7:\"usuario\";a:1:{s:2:\"id\";i:4;}s:4:\"caja\";a:1:{s:2:\"id\";i:1;}}','elloco.fabio'),(1481,'create','2013-12-01 22:27:59','107','SisGG\\FinalBundle\\Entity\\Apertura',1,'a:8:{s:7:\"importe\";d:3.0720000000000001;s:10:\"aclaracion\";N;s:5:\"fecha\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2013-12-01 22:27:59\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:30:\"America/Argentina/Buenos_Aires\";}s:4:\"lote\";a:1:{s:2:\"id\";i:5;}s:4:\"tipo\";a:1:{s:2:\"id\";i:1;}s:8:\"concepto\";N;s:7:\"usuario\";a:1:{s:2:\"id\";i:4;}s:4:\"caja\";a:1:{s:2:\"id\";i:1;}}','elloco.fabio'),(1482,'update','2013-12-01 22:27:59','1','SisGG\\FinalBundle\\Entity\\Caja',3,'a:2:{s:7:\"abierta\";b:1;s:5:\"saldo\";d:3.0720000000000001;}','elloco.fabio'),(1483,'update','2013-12-01 23:03:42','1','SisGG\\FinalBundle\\Entity\\Empresa',2,'a:1:{s:7:\"carpeta\";s:13:\"/var/backups/\";}','elloco.fabio');
/*!40000 ALTER TABLE `ext_log_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ext_translations`
--

DROP TABLE IF EXISTS `ext_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ext_translations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `locale` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `object_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `field` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `foreign_key` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lookup_unique_idx` (`locale`,`object_class`,`field`,`foreign_key`),
  KEY `translations_lookup_idx` (`locale`,`object_class`,`foreign_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ext_translations`
--

LOCK TABLES `ext_translations` WRITE;
/*!40000 ALTER TABLE `ext_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `ext_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factura_servicio`
--

DROP TABLE IF EXISTS `factura_servicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factura_servicio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `servicio_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `fechaFactura` date DEFAULT NULL,
  `periodo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaEmision` datetime NOT NULL,
  `total` decimal(10,3) DEFAULT NULL,
  `serie` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `numero` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D0925CA171CAA3E7` (`servicio_id`),
  KEY `IDX_D0925CA1521E1991` (`empresa_id`),
  CONSTRAINT `FK_D0925CA1521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_D0925CA171CAA3E7` FOREIGN KEY (`servicio_id`) REFERENCES `servicio` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura_servicio`
--

LOCK TABLES `factura_servicio` WRITE;
/*!40000 ALTER TABLE `factura_servicio` DISABLE KEYS */;
/*!40000 ALTER TABLE `factura_servicio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fondo`
--

DROP TABLE IF EXISTS `fondo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fondo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_2DC0A6E53DA5256D` (`image_id`),
  CONSTRAINT `FK_2DC0A6E53DA5256D` FOREIGN KEY (`image_id`) REFERENCES `Image` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fondo`
--

LOCK TABLES `fondo` WRITE;
/*!40000 ALTER TABLE `fondo` DISABLE KEYS */;
/*!40000 ALTER TABLE `fondo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grupocliente_cliente`
--

DROP TABLE IF EXISTS `grupocliente_cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grupocliente_cliente` (
  `grupocliente_id` int(11) NOT NULL,
  `cliente_id` int(11) NOT NULL,
  PRIMARY KEY (`grupocliente_id`,`cliente_id`),
  KEY `IDX_F11CB89378A9344C` (`grupocliente_id`),
  KEY `IDX_F11CB893DE734E51` (`cliente_id`),
  CONSTRAINT `FK_F11CB89378A9344C` FOREIGN KEY (`grupocliente_id`) REFERENCES `GrupoCliente` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_F11CB893DE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Cliente` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grupocliente_cliente`
--

LOCK TABLES `grupocliente_cliente` WRITE;
/*!40000 ALTER TABLE `grupocliente_cliente` DISABLE KEYS */;
INSERT INTO `grupocliente_cliente` VALUES (1,1),(1,5);
/*!40000 ALTER TABLE `grupocliente_cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grupocliente_descuentocliente`
--

DROP TABLE IF EXISTS `grupocliente_descuentocliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grupocliente_descuentocliente` (
  `grupocliente_id` int(11) NOT NULL,
  `descuentocliente_id` int(11) NOT NULL,
  PRIMARY KEY (`grupocliente_id`,`descuentocliente_id`),
  KEY `IDX_D6BF80EA78A9344C` (`grupocliente_id`),
  KEY `IDX_D6BF80EA6C53F65B` (`descuentocliente_id`),
  CONSTRAINT `FK_D6BF80EA6C53F65B` FOREIGN KEY (`descuentocliente_id`) REFERENCES `DescuentoCliente` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_D6BF80EA78A9344C` FOREIGN KEY (`grupocliente_id`) REFERENCES `GrupoCliente` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grupocliente_descuentocliente`
--

LOCK TABLES `grupocliente_descuentocliente` WRITE;
/*!40000 ALTER TABLE `grupocliente_descuentocliente` DISABLE KEYS */;
INSERT INTO `grupocliente_descuentocliente` VALUES (1,1);
/*!40000 ALTER TABLE `grupocliente_descuentocliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `itemRegistroProduccion`
--

DROP TABLE IF EXISTS `itemRegistroProduccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `itemRegistroProduccion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `producto` int(11) DEFAULT NULL,
  `tasa_id` int(11) DEFAULT NULL,
  `cantidad` decimal(10,2) DEFAULT NULL,
  `utilizado` tinyint(1) NOT NULL,
  `costo` decimal(10,2) DEFAULT NULL,
  `registroProduccion` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_95218525A7BB0615` (`producto`),
  KEY `IDX_95218525E20BE1E2` (`tasa_id`),
  KEY `IDX_9521852589F2E403` (`registroProduccion`),
  CONSTRAINT `FK_9521852589F2E403` FOREIGN KEY (`registroProduccion`) REFERENCES `registroProduccion` (`id`),
  CONSTRAINT `FK_95218525A7BB0615` FOREIGN KEY (`producto`) REFERENCES `ProductoProduccion` (`id`),
  CONSTRAINT `FK_95218525E20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `itemRegistroProduccion`
--

LOCK TABLES `itemRegistroProduccion` WRITE;
/*!40000 ALTER TABLE `itemRegistroProduccion` DISABLE KEYS */;
/*!40000 ALTER TABLE `itemRegistroProduccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_LIC`
--

DROP TABLE IF EXISTS `item_LIC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_LIC` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lic` int(11) DEFAULT NULL,
  `tasa` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `gravado` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_AFBA32E2DE080B5A` (`lic`),
  CONSTRAINT `FK_AFBA32E2DE080B5A` FOREIGN KEY (`lic`) REFERENCES `libro_iva_compra` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_LIC`
--

LOCK TABLES `item_LIC` WRITE;
/*!40000 ALTER TABLE `item_LIC` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_LIC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_compra`
--

DROP TABLE IF EXISTS `item_compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_compra` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `producto` int(11) DEFAULT NULL,
  `tasa_id` int(11) DEFAULT NULL,
  `compra` int(11) DEFAULT NULL,
  `cantidad` decimal(10,3) DEFAULT NULL,
  `precioCosto` decimal(10,3) DEFAULT NULL,
  `total` decimal(10,3) DEFAULT NULL,
  `pIVA` decimal(10,3) DEFAULT NULL,
  `gIVA` tinyint(1) DEFAULT NULL,
  `tIVA` decimal(10,3) DEFAULT NULL,
  `bonificacion` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_18384430A7BB0615` (`producto`),
  KEY `IDX_18384430E20BE1E2` (`tasa_id`),
  KEY `IDX_183844309EC131FF` (`compra`),
  CONSTRAINT `FK_183844309EC131FF` FOREIGN KEY (`compra`) REFERENCES `compra` (`id`),
  CONSTRAINT `FK_18384430A7BB0615` FOREIGN KEY (`producto`) REFERENCES `Producto` (`id`),
  CONSTRAINT `FK_18384430E20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_compra`
--

LOCK TABLES `item_compra` WRITE;
/*!40000 ALTER TABLE `item_compra` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_especies`
--

DROP TABLE IF EXISTS `item_especies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_especies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `producto` int(11) DEFAULT NULL,
  `tasa_id` int(11) DEFAULT NULL,
  `especies` int(11) DEFAULT NULL,
  `cantidad` decimal(10,2) DEFAULT NULL,
  `precioCosto` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_A9479111A7BB0615` (`producto`),
  KEY `IDX_A9479111E20BE1E2` (`tasa_id`),
  KEY `IDX_A9479111C54A59DA` (`especies`),
  CONSTRAINT `FK_A9479111A7BB0615` FOREIGN KEY (`producto`) REFERENCES `Producto` (`id`),
  CONSTRAINT `FK_A9479111C54A59DA` FOREIGN KEY (`especies`) REFERENCES `EspeciesEmpleado` (`id`),
  CONSTRAINT `FK_A9479111E20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_especies`
--

LOCK TABLES `item_especies` WRITE;
/*!40000 ALTER TABLE `item_especies` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_especies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_nota_pedido`
--

DROP TABLE IF EXISTS `item_nota_pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_nota_pedido` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `producto` int(11) DEFAULT NULL,
  `tasa_id` int(11) DEFAULT NULL,
  `cantidad` decimal(10,2) DEFAULT NULL,
  `precioCosto` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `notaPedido` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_B81C17D6A7BB0615` (`producto`),
  KEY `IDX_B81C17D6E20BE1E2` (`tasa_id`),
  KEY `IDX_B81C17D6D82778A0` (`notaPedido`),
  CONSTRAINT `FK_B81C17D6A7BB0615` FOREIGN KEY (`producto`) REFERENCES `Producto` (`id`),
  CONSTRAINT `FK_B81C17D6D82778A0` FOREIGN KEY (`notaPedido`) REFERENCES `nota_pedido` (`id`),
  CONSTRAINT `FK_B81C17D6E20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_nota_pedido`
--

LOCK TABLES `item_nota_pedido` WRITE;
/*!40000 ALTER TABLE `item_nota_pedido` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_nota_pedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `itempedido_ingrediente`
--

DROP TABLE IF EXISTS `itempedido_ingrediente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `itempedido_ingrediente` (
  `itempedido_id` int(11) NOT NULL,
  `ingrediente_id` int(11) NOT NULL,
  PRIMARY KEY (`itempedido_id`,`ingrediente_id`),
  KEY `IDX_97BF75CBA99E891` (`itempedido_id`),
  KEY `IDX_97BF75CB769E458D` (`ingrediente_id`),
  CONSTRAINT `FK_97BF75CB769E458D` FOREIGN KEY (`ingrediente_id`) REFERENCES `Ingrediente` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_97BF75CBA99E891` FOREIGN KEY (`itempedido_id`) REFERENCES `ItemPedido` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `itempedido_ingrediente`
--

LOCK TABLES `itempedido_ingrediente` WRITE;
/*!40000 ALTER TABLE `itempedido_ingrediente` DISABLE KEYS */;
INSERT INTO `itempedido_ingrediente` VALUES (117,2),(121,2),(169,2),(169,3),(171,3),(173,2),(173,3),(183,2),(215,2);
/*!40000 ALTER TABLE `itempedido_ingrediente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iva`
--

DROP TABLE IF EXISTS `iva`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iva` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa_id` int(11) DEFAULT NULL,
  `tasa` decimal(10,2) NOT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `gravado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_FB97A603521E1991` (`empresa_id`),
  CONSTRAINT `FK_FB97A603521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iva`
--

LOCK TABLES `iva` WRITE;
/*!40000 ALTER TABLE `iva` DISABLE KEYS */;
INSERT INTO `iva` VALUES (1,1,21.00,'Tasa de Iva 21% Gravado',1),(2,1,15.00,NULL,1);
/*!40000 ALTER TABLE `iva` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `libro_iva_compra`
--

DROP TABLE IF EXISTS `libro_iva_compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `libro_iva_compra` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proveedor_id` int(11) DEFAULT NULL,
  `compra_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `tipo` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `cuit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `razonSocial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `neto` decimal(10,3) DEFAULT NULL,
  `acrecent` decimal(10,3) DEFAULT NULL,
  `total` decimal(10,3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_89B2384F2E704D7` (`compra_id`),
  KEY `IDX_89B2384CB305D73` (`proveedor_id`),
  KEY `IDX_89B2384521E1991` (`empresa_id`),
  CONSTRAINT `FK_89B2384521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_89B2384CB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedor` (`id`),
  CONSTRAINT `FK_89B2384F2E704D7` FOREIGN KEY (`compra_id`) REFERENCES `compra` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `libro_iva_compra`
--

LOCK TABLES `libro_iva_compra` WRITE;
/*!40000 ALTER TABLE `libro_iva_compra` DISABLE KEYS */;
/*!40000 ALTER TABLE `libro_iva_compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lineatanda_ingrediente`
--

DROP TABLE IF EXISTS `lineatanda_ingrediente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lineatanda_ingrediente` (
  `lineatanda_id` int(11) NOT NULL,
  `ingrediente_id` int(11) NOT NULL,
  PRIMARY KEY (`lineatanda_id`,`ingrediente_id`),
  KEY `IDX_4E68FE3211BF7F8B` (`lineatanda_id`),
  KEY `IDX_4E68FE32769E458D` (`ingrediente_id`),
  CONSTRAINT `FK_4E68FE3211BF7F8B` FOREIGN KEY (`lineatanda_id`) REFERENCES `LineaTanda` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_4E68FE32769E458D` FOREIGN KEY (`ingrediente_id`) REFERENCES `Ingrediente` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lineatanda_ingrediente`
--

LOCK TABLES `lineatanda_ingrediente` WRITE;
/*!40000 ALTER TABLE `lineatanda_ingrediente` DISABLE KEYS */;
INSERT INTO `lineatanda_ingrediente` VALUES (52,2),(53,2),(55,2),(71,2),(71,3),(74,3),(76,2),(76,3),(82,2),(88,2);
/*!40000 ALTER TABLE `lineatanda_ingrediente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mensaje`
--

DROP TABLE IF EXISTS `mensaje`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mensaje` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `mensaje` longtext COLLATE utf8_unicode_ci,
  `leido` tinyint(1) NOT NULL,
  `nuevo` tinyint(1) NOT NULL,
  `tipo` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9B631D01DB38439E` (`usuario_id`),
  CONSTRAINT `FK_9B631D01DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensaje`
--

LOCK TABLES `mensaje` WRITE;
/*!40000 ALTER TABLE `mensaje` DISABLE KEYS */;
INSERT INTO `mensaje` VALUES (6,1,'Ya esta listo el pedido para el cliente Aguero, Sergio',1,0,1),(7,1,'Ya esta listo el pedido para el cliente Amarilla, Fernando',1,0,1),(8,1,'Ya esta listo el pedido para el cliente Amarilla, Fernando(Direccion: Posadas(Misiones) Bolivar 321)',1,0,1),(9,1,'Ya esta listo el pedido para el cliente Blanco, Carlos Ezequiel(Direccion: Posadas(Misiones) San Martin 3029)',1,0,1),(10,1,'Ya esta listo el pedido para el cliente Aquino, Ramona',1,0,1);
/*!40000 ALTER TABLE `mensaje` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mov_empleado`
--

DROP TABLE IF EXISTS `mov_empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mov_empleado` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cuenta` int(11) DEFAULT NULL,
  `monto` decimal(10,2) NOT NULL,
  `fecha` date NOT NULL,
  `fechaEmision` datetime NOT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `discr` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_E443D23431C7BFCF` (`cuenta`),
  CONSTRAINT `FK_E443D23431C7BFCF` FOREIGN KEY (`cuenta`) REFERENCES `cuenta_empleado` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mov_empleado`
--

LOCK TABLES `mov_empleado` WRITE;
/*!40000 ALTER TABLE `mov_empleado` DISABLE KEYS */;
INSERT INTO `mov_empleado` VALUES (1,1,1000.00,'2013-10-21','2013-10-21 19:00:33','Primer pago de sueldo','sueldoempleado');
/*!40000 ALTER TABLE `mov_empleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nota_pedido`
--

DROP TABLE IF EXISTS `nota_pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nota_pedido` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proveedor_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `estado` smallint(6) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_58744FE0CB305D73` (`proveedor_id`),
  KEY `IDX_58744FE0521E1991` (`empresa_id`),
  CONSTRAINT `FK_58744FE0521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_58744FE0CB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedor` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nota_pedido`
--

LOCK TABLES `nota_pedido` WRITE;
/*!40000 ALTER TABLE `nota_pedido` DISABLE KEYS */;
/*!40000 ALTER TABLE `nota_pedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pago`
--

DROP TABLE IF EXISTS `pago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pago` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `compra` int(11) DEFAULT NULL,
  `importe` decimal(10,3) DEFAULT NULL,
  `aclaracion` longtext COLLATE utf8_unicode_ci,
  `fecha` date DEFAULT NULL,
  `fechaEmision` datetime DEFAULT NULL,
  `facturaServicio` int(11) DEFAULT NULL,
  `tipoCobro_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_F4DF5F3E9EC131FF` (`compra`),
  KEY `IDX_F4DF5F3E53B38154` (`facturaServicio`),
  KEY `IDX_F4DF5F3EE414003F` (`tipoCobro_id`),
  CONSTRAINT `FK_F4DF5F3E53B38154` FOREIGN KEY (`facturaServicio`) REFERENCES `factura_servicio` (`id`),
  CONSTRAINT `FK_F4DF5F3E9EC131FF` FOREIGN KEY (`compra`) REFERENCES `compra` (`id`),
  CONSTRAINT `FK_F4DF5F3EE414003F` FOREIGN KEY (`tipoCobro_id`) REFERENCES `TipoCobro` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pago`
--

LOCK TABLES `pago` WRITE;
/*!40000 ALTER TABLE `pago` DISABLE KEYS */;
/*!40000 ALTER TABLE `pago` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `persona_empleado`
--

DROP TABLE IF EXISTS `persona_empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `persona_empleado` (
  `id` int(11) NOT NULL,
  `direccion_id` int(11) DEFAULT NULL,
  `cuenta` int(11) DEFAULT NULL,
  `imagen_id` int(11) DEFAULT NULL,
  `dni` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fechaNac` date NOT NULL,
  `fechaIngreso` date NOT NULL,
  `primerPago` date DEFAULT NULL,
  `sexo` tinyint(1) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_390AAB13D0A7BD7` (`direccion_id`),
  UNIQUE KEY `UNIQ_390AAB1331C7BFCF` (`cuenta`),
  UNIQUE KEY `UNIQ_390AAB13763C8AA7` (`imagen_id`),
  CONSTRAINT `FK_390AAB1331C7BFCF` FOREIGN KEY (`cuenta`) REFERENCES `cuenta_empleado` (`id`),
  CONSTRAINT `FK_390AAB13763C8AA7` FOREIGN KEY (`imagen_id`) REFERENCES `Image` (`id`),
  CONSTRAINT `FK_390AAB13BF396750` FOREIGN KEY (`id`) REFERENCES `Usuario` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_390AAB13D0A7BD7` FOREIGN KEY (`direccion_id`) REFERENCES `Direccion` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `persona_empleado`
--

LOCK TABLES `persona_empleado` WRITE;
/*!40000 ALTER TABLE `persona_empleado` DISABLE KEYS */;
INSERT INTO `persona_empleado` VALUES (2,7,1,10,'34366629','2013-10-01','2013-10-01',NULL,1,1),(3,32,2,24,'343666628','2013-11-01','2013-11-06','2013-12-21',1,1);
/*!40000 ALTER TABLE `persona_empleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedor`
--

DROP TABLE IF EXISTS `proveedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proveedor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `direccion_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `razonSocial` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `cuit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `responsable` tinyint(1) NOT NULL,
  `activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_16C068CE832CBC66` (`razonSocial`),
  UNIQUE KEY `UNIQ_16C068CED0A7BD7` (`direccion_id`),
  KEY `IDX_16C068CE521E1991` (`empresa_id`),
  CONSTRAINT `FK_16C068CE521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_16C068CED0A7BD7` FOREIGN KEY (`direccion_id`) REFERENCES `Direccion` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor`
--

LOCK TABLES `proveedor` WRITE;
/*!40000 ALTER TABLE `proveedor` DISABLE KEYS */;
INSERT INTO `proveedor` VALUES (1,6,1,'Total Distribuidora','20-34554244-3','total@total.com',0,1);
/*!40000 ALTER TABLE `proveedor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recargo_tipopedido`
--

DROP TABLE IF EXISTS `recargo_tipopedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recargo_tipopedido` (
  `recargo_id` int(11) NOT NULL,
  `tipopedido_id` int(11) NOT NULL,
  PRIMARY KEY (`recargo_id`,`tipopedido_id`),
  KEY `IDX_A54355E3E3DAE5D1` (`recargo_id`),
  KEY `IDX_A54355E3B0517A93` (`tipopedido_id`),
  CONSTRAINT `FK_A54355E3B0517A93` FOREIGN KEY (`tipopedido_id`) REFERENCES `TipoPedido` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_A54355E3E3DAE5D1` FOREIGN KEY (`recargo_id`) REFERENCES `Recargo` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recargo_tipopedido`
--

LOCK TABLES `recargo_tipopedido` WRITE;
/*!40000 ALTER TABLE `recargo_tipopedido` DISABLE KEYS */;
INSERT INTO `recargo_tipopedido` VALUES (1,3);
/*!40000 ALTER TABLE `recargo_tipopedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registroProduccion`
--

DROP TABLE IF EXISTS `registroProduccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registroProduccion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tasa_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `tipo` tinyint(1) DEFAULT NULL,
  `cantidad` decimal(10,2) DEFAULT NULL,
  `costo` decimal(10,2) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `productoProduccion` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_89F2E403EA73C921` (`productoProduccion`),
  KEY `IDX_89F2E403E20BE1E2` (`tasa_id`),
  KEY `IDX_89F2E403521E1991` (`empresa_id`),
  CONSTRAINT `FK_89F2E403521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`),
  CONSTRAINT `FK_89F2E403E20BE1E2` FOREIGN KEY (`tasa_id`) REFERENCES `tasa` (`id`),
  CONSTRAINT `FK_89F2E403EA73C921` FOREIGN KEY (`productoProduccion`) REFERENCES `ProductoProduccion` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registroProduccion`
--

LOCK TABLES `registroProduccion` WRITE;
/*!40000 ALTER TABLE `registroProduccion` DISABLE KEYS */;
/*!40000 ALTER TABLE `registroProduccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicio`
--

DROP TABLE IF EXISTS `servicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servicio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nombreEmpresa` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `cuit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `codigo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CB86F22A43AD9559` (`nombreEmpresa`),
  KEY `IDX_CB86F22A521E1991` (`empresa_id`),
  CONSTRAINT `FK_CB86F22A521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicio`
--

LOCK TABLES `servicio` WRITE;
/*!40000 ALTER TABLE `servicio` DISABLE KEYS */;
/*!40000 ALTER TABLE `servicio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasa`
--

DROP TABLE IF EXISTS `tasa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tasa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `um_id` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `abrev` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `valor` decimal(10,2) DEFAULT NULL,
  `pivote` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_B2AB323BA75CAB5E` (`um_id`),
  CONSTRAINT `FK_B2AB323BA75CAB5E` FOREIGN KEY (`um_id`) REFERENCES `unidad_medida` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasa`
--

LOCK TABLES `tasa` WRITE;
/*!40000 ALTER TABLE `tasa` DISABLE KEYS */;
INSERT INTO `tasa` VALUES (1,'467aea3c-38fb-1','Unidad','','Un',1.00,1),(2,'50a74d08-38fb-1','Gramo','','Gr',1.00,1),(3,'50a74d08-38fb-1','Kilogramo',NULL,'Kg',1000.00,0),(4,'467aea3c-38fb-1','Docena',NULL,'Doc',12.00,0);
/*!40000 ALTER TABLE `tasa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_pago`
--

DROP TABLE IF EXISTS `tipo_pago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_pago` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `atr1` longtext COLLATE utf8_unicode_ci,
  `atr2` longtext COLLATE utf8_unicode_ci,
  `atr3` longtext COLLATE utf8_unicode_ci,
  `atr4` longtext COLLATE utf8_unicode_ci,
  `atr5` longtext COLLATE utf8_unicode_ci,
  `tipo1` int(11) DEFAULT NULL,
  `tipo2` int(11) DEFAULT NULL,
  `tipo3` int(11) DEFAULT NULL,
  `tipo4` int(11) DEFAULT NULL,
  `tipo5` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_FEF0887B521E1991` (`empresa_id`),
  CONSTRAINT `FK_FEF0887B521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_pago`
--

LOCK TABLES `tipo_pago` WRITE;
/*!40000 ALTER TABLE `tipo_pago` DISABLE KEYS */;
/*!40000 ALTER TABLE `tipo_pago` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unidad_medida`
--

DROP TABLE IF EXISTS `unidad_medida`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `unidad_medida` (
  `id` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `IDX_7DA31363521E1991` (`empresa_id`),
  CONSTRAINT `FK_7DA31363521E1991` FOREIGN KEY (`empresa_id`) REFERENCES `Empresa` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unidad_medida`
--

LOCK TABLES `unidad_medida` WRITE;
/*!40000 ALTER TABLE `unidad_medida` DISABLE KEYS */;
INSERT INTO `unidad_medida` VALUES ('467aea3c-38fb-1',1,'Cantidad',NULL),('50a74d08-38fb-1',1,'Peso',NULL);
/*!40000 ALTER TABLE `unidad_medida` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-12-01 23:12:26
